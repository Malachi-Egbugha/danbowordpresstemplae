<?php 
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token , Authorization');
header('Content-type: application/json');

?>
<?php
/**
	* Template Name: Api User List

*/


if($_GET['user']=='all'){
	
$args = array('orderby' => 'display_name');
$wp_user_query = new WP_User_Query($args);
$authors = $wp_user_query->get_results();
$user = array();
foreach ($authors as $author) {
$author_info = get_userdata($author->ID);

$email=$author_info->user_email;
$fname=$author_info->first_name;
$lname=$author_info->last_name;
$role= $author_info->roles;

$nationality= $author_info->nationality;
$gender= $author_info->gender;
$last_grade_completed= $author_info->last_grade_completed;
$name_of_last_school_attended= $author_info->name_of_last_school_attended;
$grade_applied_for_in_danbo= $author_info->grade_applied_for_in_danbo;
$childs_first_language= $author_info->childs_first_language;
$difficulty= $author_info->difficulty;
$date_of_birth= $author_info->date_of_birth;
$application_id= $author_info->application_id;
$fathers_name= $author_info->fathers_name;
$mothers_name= $author_info->mothers_name;
$fathers_occupation= $author_info->fathers_occupation;
$mothers_occupation= $author_info->mothers_occupation;
$fathers_email= $author_info->fathers_email;
$mothers_email= $author_info->mothers_email;
$fatherss_phone_number= $author_info->fatherss_phone_number;
$mothers_phone_number= $author_info->mothers_phone_number;
$fathers_house_address= $author_info->fathers_house_address;
$mothers_house_address= $author_info->mothers_house_address;

$user[] = array("email" => $email); 
$user[] = array("first_name" => $fname); 
$user[] = array("last_name" => $lname); 
$user[] = array("roles" => $role);
$user[] = array("nationality" => $nationality);
$user[] = array("gender" => $gender);
$user[] = array("last_grade_completed" => $last_grade_completed);
$user[] = array("name_of_last_school_attended" => $name_of_last_school_attended);
$user[] = array("grade_applied_for_in_danbo" => $grade_applied_for_in_danbo);
$user[] = array("childs_first_language" => $childs_first_language);
$user[] = array("difficulty" => $difficulty);
$user[] = array("date_of_birth" => $date_of_birth);
$user[] = array("application_id" => $application_id);
$user[] = array("fathers_name" => $fathers_name);
$user[] = array("mothers_name" => $mothers_name);
$user[] = array("fathers_occupation" => $fathers_occupation);
$user[] = array("mothers_occupation" => $mothers_occupation);
$user[] = array("fathers_email" => $fathers_email);
$user[] = array("mothers_email" => $mothers_email);
$user[] = array("fatherss_phone_number" => $fatherss_phone_number);
$user[] = array("mothers_phone_number" => $mothers_phone_number);
$user[] = array("fathers_house_address" => $fathers_house_address);
$user[] = array("mothers_house_address" => $mothers_house_address);

}
$json = array("info" => $user);		
echo json_encode($json);
}




?>