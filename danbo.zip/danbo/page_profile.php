<?php
/**
 * Template Name: Profile
 */

get_header();
//$user = wp_get_current_user();
//$wp_user_object = new WP_User($user->ID);
//$roll = $wp_user_object->set_role('parent');
//echo '<pre>';
//print_r($wp_user_object);

//$user = wp_get_current_user();

   
// if (!is_user_logged_in()) {
   // exit;
// }

if($_SESSION['userid']==""){
	echo "<script type='text/javascript'>window.location.href='". home_url('/staff-login/') ."'</script>";echo "<script type='text/javascript'>window.location.href='". home_url('/student-login/') ."'</script>";	
}

$user_id = $_SESSION['userid'];
$user = get_userdata( $user_id );
$user_roles = $user->roles;


//global $current_user, $wp_roles;
 $error = array();    
/* If profile was saved, update profile. */
if ( $_POST['action'] == 'update-user' ) {

   
    if ( !empty( $_POST['first-name'] ) )
        update_user_meta( $user_id, 'first_name', esc_attr( $_POST['first-name'] ) );
    if ( !empty( $_POST['last-name'] ) )
        update_user_meta($user_id, 'last_name', esc_attr( $_POST['last-name'] ) );
    if ( !empty( $_POST['description'] ) )
        update_user_meta( $user_id, 'description', esc_attr( $_POST['description'] ) );
	
	if ( !empty( $_POST['student_phone_number'] ) )
        update_user_meta( $user_id, 'student_phone_number', esc_attr( $_POST['student_phone_number'] ) );

   if ( !empty( $_POST['student_address'] ) )
        update_user_meta($user_id, 'student_address', esc_attr( $_POST['student_address'] ) );
	
	if ( !empty( $_POST['student_class'] ) )
        update_user_meta($user_id, 'student_class', esc_attr( $_POST['student_class'] ) );

	//teacher Field

	if ( !empty( $_POST['teacher_phone_number'] ) )
        update_user_meta($user_id, 'teacher_phone_number', esc_attr( $_POST['teacher_phone_number'] ) );
	
	if ( !empty( $_POST['teacher_address'] ) )
        update_user_meta($user_id, 'teacher_address', esc_attr( $_POST['teacher_address'] ) );



   
$msg="Profile updated sucessfully !";

   /* Update user password. */
    if ( !empty($_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {
        if ( $_POST['pass1'] == $_POST['pass2'] )
            wp_update_user( array( 'ID' => $user_id, 'user_pass' => esc_attr( $_POST['pass1'] ) ) );
        else
            $error[] = __('The passwords you entered do not match.  Your password was not updated.', 'profile');
    }

   
    if ( !empty( $_POST['email'] ) ){
        if (!is_email(esc_attr( $_POST['email'] )))
            $error[] = __('The Email you entered is not valid.  please try again.', 'profile');
        elseif(email_exists(esc_attr( $_POST['email'] )) != $user_id )
            $error[] = __('This email is already used by another user.  try a different one.', 'profile');
        else{
            wp_update_user( array ('ID' =>$user_id, 'user_email' => esc_attr( $_POST['email'] )));
        }
    }
	
	
	
		if ( ! function_exists( 'wp_handle_upload' ) ) {

		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/media.php' );
      }  


		// if($_FILES['imagestyu']['name'] != ''){
          // $uploadedfile = $_FILES['imagestyu'];
          // $upload_overrides = array( 'test_form' => false );

          // $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );

          // $imageurl = "";
          // if ( $movefile && ! isset( $movefile['error'] ) ) {
             // $imageurl = $movefile['url'];
             // $file_upload_path = $imageurl;
          // }
      // }
	   // update_user_meta( $user_id, 'imagestyu', $file_upload_path);
		//update_post_meta($user_id, 'imagestyu', $file_upload_path);
	
	
	// $uploaddir = './uploads/large_image/'; 
// $file = $uploaddir . basename($_FILES['imagestyu']['name']); 
// $raw_file_name = $_FILES['imagestyu']['tmp_name'];
// if (move_uploaded_file($_FILES['imagestyu']['tmp_name'], $file)) { 
    // echo "success"; 
// } else {
    // echo "error";
// }
	
	
	$attachment_id = media_handle_upload( 'imagestyu', $user_id );
     
    if ( is_wp_error( $attachment_id ) ) {
       //There was an error uploading the image.
    } else {
      // echo "success"; 
	  $img= update_user_meta( $user_id, 'imagestyu', $attachment_id);
	  //var_dump($img);
    }
	
	
	
	

   if ( count($error) == 0 ) {
        //action hook for plugins and extra fields saving
        do_action('edit_user_profile_update', $user_id);
        wp_redirect( get_permalink().'?updated=true' ); 
		//exit;
    } 
   
   
}


 
 ?>
<main> 
  
  <!-- about -->
 
    
<?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			
			 <?php include('sidebar-students.php'); ?>
			
			
            <div class="col-lg-9">
              <div class="abarea">
                <h3>Edit Profile</h3>
           
                <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>
				 <p style="color:green"><?php echo $msg;?></p>
				<form name="form" method="post" enctype="multipart/form-data">
              <div class="row">
              
		<?php if ($user_roles[0]=='student') {
			$author_badge = get_field('imagestyu', 'user_'. $user_id );
			//$image=wp_get_attachment_image_src(get_post_thumbnail_id($author_badge),'full');
			//$image = wp_get_attachment_image_src( $author_badge, $size, $icon );

			$thumbnail = get_field('imagestyu',$user_id); 
			//var_dump($author_badge);
			?>	  
			  <div class="col-lg-12 col-md-6">
  
  <?php echo wp_get_attachment_image( $author_badge, array('70', '60'), "", array( "class" => "img-responsive" ) );  ?>
  <div class="form-group">
		<label for="username" class="text-info">Image</label><br>
		<input type="file" name="imagestyu" id="imagestyu" class="form-control">
	</div>
	</div>
	
		<?php } ?>
	
  <div class="col-lg-6 col-md-6"> 
  <div class="form-group">
    <label for="exampleInputtext">First Name</label>
    <input type="text" name="first-name" value="<?php the_author_meta( 'first_name', $user_id ); ?>" class="form-control" placeholder="First Name">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Last Name</label>
    <input type="text" name="last-name" value="<?php the_author_meta( 'last_name', $user_id ); ?>" class="form-control" placeholder="Last Name">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" disabled value="<?php the_author_meta( 'user_email', $user_id); ?>" class="form-control" placeholder="Email">
  </div>
  </div>
  
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" name="pass1"  class="form-control" placeholder="Password">
  </div>
  </div>
  
   <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">Confirm password</label>
    <input type="password" name="pass2" class="form-control" placeholder="Password">
  </div>
  </div>
  
  
  <?php if ($user_roles[0]=='student') {?>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Phone No.</label>
    <input type="text" name="student_phone_number" value="<?php the_author_meta( 'student_phone_number', $user_id); ?>"class="form-control" placeholder="Phone No.">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Address</label>
    <textarea class="form-control" name="student_address" placeholder="Address" rows="3"><?php the_author_meta( 'student_address', $user_id); ?></textarea>
  </div>
  </div>
  <?php } elseif($user_roles[0]=='teacher') { ?>
 
 <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Phone No.</label>
    <input type="text" name="teacher_phone_number" value="<?php the_author_meta( 'teacher_phone_number', $user_id ); ?>"class="form-control" placeholder="Phone No.">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Address</label>
    <textarea class="form-control" name="teacher_address" placeholder="Address" rows="3"><?php the_author_meta( 'teacher_address', $user_id ); ?></textarea>
  </div>
  </div>
  
  
  <?php } ?>
  
  
  
  <?php if ($user_roles[0]=='student') {
	  //the_author_meta( 'student_class', $user_id );
	  $all_meta_for_user = get_user_meta( $user_id );
		$class1 = $all_meta_for_user['student_class'][0];
		//var_dump($class1);
	  ?>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
	  <label for="sel1">Select Class:</label>
	  <select class="form-control" id="sel1" name="student_class">
		<option <?php if($class1 =='V' ) { echo 'selected="selected"';} ?> value="V">V</option>
		<option <?php if($class1 =='VI' ) { echo 'selected="selected"';} ?> value="VI">VI</option>
		<option <?php if($class1 =='VII' ){ echo 'selected="selected"';} ?> value="VII">VII</option>
		<option <?php if($class1 =='VIII' ) { echo 'selected="selected"';} ?> value="VIII">VIII</option>
		
		
		<option <?php if($class1 =='IX' ) { echo 'selected="selected"';} ?>value="IX">IX</option>
		<option <?php if($class1 =='X' ) { echo 'selected="selected"';} ?> value="X">X</option>
		<option <?php if($class1 =='XI' ) { echo 'selected="selected"';} ?> value="XI">XI</option>
		<option <?php if($class1 =='XII' ) { echo 'selected="selected"';} ?> value="XII">XII</option>
	  </select>
	</div>
  </div>
  <?php } ?>
  <button onclick="myFunction()" type="submit" name="updateuser" class="btn btn-default dsubmit">Update</button>
  <?php wp_nonce_field( 'update-user' ) ?>
  <input name="action" type="hidden" id="action" value="update-user" />
  
  </div>
</form>
				
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php   get_footer(); ?>
