<footer> 
  <!-- footer -->
  <div class="footer">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 col-md-8">
            <h4>Get in touch</h4>
            <div class="foot-a"><samp><i class="fa fa-map-marker" aria-hidden="true"></i> </samp><?php the_field('address','option'); ?> 
              <div class="clearfix"></div>
            </div>
            <div class="foot-a"><samp><i class="fa fa-phone" aria-hidden="true"></i> </samp><span><strong><?php the_field('phone','option'); ?></strong></span> <span><strong><?php the_field('phone_number','option'); ?> </strong></span>
              <div class="clearfix"></div>
            </div>
            <div class="foot-a"><samp><i class="fa fa-envelope-o" aria-hidden="true"></i> </samp><span><a href="mailto:<?php the_field('email_id','option'); ?> "><?php the_field('email_id','option'); ?> </a> <a href="mailto:<?php the_field('email_2','option'); ?> "><?php the_field('email_2','option'); ?> </a></span>
              <div class="clearfix"></div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <h4>Quick Links</h4>
            <?php  wp_nav_menu( array('theme_location' => 'footer' , 'menu_class' => '' ) ); ?>
			<!--<ul>
              <li class="active"><a href="<?php echo home_url('');?>">Home</a></li>
              <li><a href="<?php echo home_url('/about-us/');?>">About Us</a></li>
              <li><a href="<?php echo home_url('/kaduna-school/');?>">Our School</a></li>
              <li><a href="<?php echo home_url('/school-life/');?>">School Life</a></li>
              <li><a href="<?php echo home_url('/admission/');?>">Admissions</a></li>
            </ul>
            <ul>
              <li><a href="<?php echo home_url('/dis-portal/');?>">Dis Portal</a></li>
              <li><a href="<?php echo home_url('/community/');?>">Community</a></li>
              <li><a href="<?php echo home_url('/school-shop/');?>">School Shop</a></li>
              <li><a href="<?php echo home_url('/gallery/');?>">Gallery</a></li>
              <li><a href="<?php echo home_url('/blog/');?>">Blog</a></li>
            </ul>-->
          </div>
          <div class="col-lg-3 col-sm-6">
            <h4>Find us</h4>
            <div class="map">
              <iframe src="<?php the_field('google_maps','option'); ?> " width="100%" height="190px" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="social">
              <ul>
				  <?php if( have_rows('social','option') ): ?>
					<?php 
					while( have_rows('social','option') ): the_row(); 

					// vars
					$logo = get_sub_field('social_logo');
					$link = get_sub_field('social_link');

					?>
                <li><a href="<?php echo $link;?>" target="_blank"><i class="fa fa-<?php echo $logo;?>" aria-hidden="true"></i></a></li>
				  <?php endwhile; ?>
					<?php endif; ?>

              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copy">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-12">
            <h6><a href="<?php echo home_url(); ?>">Danbo International Schools ICT</a> © <?php echo date("Y"); ?> Design & Development by <a href="https://www.webtechnomind.com/" target="_blank">Webtechnomind IT Solutions.</a></h6>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end footer --> 
</footer>

<!-- Bootstrap core JavaScript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.min.js"></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/popper.min.js"></script> 
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap.min.js"></script> 

<script>
function thankyou(){
swal("Hello world!");
}
</script>
<script>
	jQuery(document).ready(function() {
        jQuery(".menu li").find("ul").parent().append("<span></span>");
       jQuery(".menuButton").click(function() {
           jQuery( ".menuButton" ).toggleClass( "arrow_change" );
		 	jQuery(".menuButton + ul").slideToggle(); 
		});
	   jQuery(".menu ul li span").click(function(){
           if(jQuery("span").parent().children("ul").is(":visible")){
               jQuery(this).parent().siblings().children("ul").slideUp();
           }
            jQuery(this).parent().children("ul").slideToggle();  
    });
    });
 
 jQuery(".myAccount span").click(function() {
           jQuery( ".myAccount span" ).toggleClass( "arrow_change" );
		 	jQuery(".myAccountDropdown").slideToggle(); 
		});
</script>

<!-- Gallery Isotop --> 
<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/isotope.pkgd.min.js"></script> 
<script>
  jQuery(document).ready(function($){
    
    var $grid = $('.grid').isotope({
      itemSelector: '.grid-item',
      percentPosition: true,
      masonry: {
       
        columnWidth: '.grid-item',
        gutter: 0
        }
  });

 
  var filterFns = {
   
    numberGreaterThan50: function() {
      var number = $(this).find('.number').text();
      return parseInt( number, 10 ) > 50;
    },
    
    ium: function() {
      var name = $(this).find('.name').text();
      return name.match( /ium$/ );
    }
  };

 
  $('#filters').on( 'click', 'button', function() {
    var filterValue = $( this ).attr('data-filter');
   
    filterValue = filterFns[ filterValue ] || filterValue;
    $grid.isotope({ filter: filterValue });
  });

  $('.galleryFilterBtn button').click(function(){
      $('.galleryFilterBtn button').removeClass("is-checked");
      $(this).addClass("is-checked");
  });
})
</script> 
<!-- End Gallery Isotop --> 

<script src="<?php echo get_template_directory_uri(); ?>/js/grid-gallery.min.js"></script> 
<script>
    gridGallery({
      selector: ".dark",
      darkMode: true
    });
    
    </script>


<!-- Our Partners js --> 
<script src="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.min.js"></script> 
<script>
$('.bxslider').bxSlider({
  autoHover: true,
  auto: true,
  slideWidth: 170,
  minSlides: 2,
  maxSlides: 6,
  controls: true,
  pager: true,
  speed: 500,
  captions: true,
  slideMargin: 0,
});

</script> 
<!-- Our Partners js end --> 

<!-- start banner slider --> 
<!--<script src="js/jquery.min.js"></script> --> 
<script src="<?php echo get_template_directory_uri(); ?>/js/responsiveslides.min.js"></script> 
<script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
  </script> 
<!--end banner slider --> 

<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/wow.js"></script> 
<script>
    new WOW().init();
  </script> 
<!--<script type="text/javascript" src="js/app.js"></script>--> 
<script src='https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js'></script> 
<script id="rendered-js">
      $(document).ready(function () {
  
  $(".fancybox").fancybox({
    openEffect: "none",
    closeEffect: "none" });

});
     
</script>






<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script> 
<script>
$(document).ready(function(){
    $("#testimonial-slider").owlCarousel({
        items:1,
        itemsDesktop:[1000,1],
        itemsDesktopSmall:[979,1],
        itemsTablet:[768,1],
        pagination:true,
        navigation:true,
        navigationText:["",""],
        slideSpeed:1000,
        autoPlay:true
    });
});

</script> 




<script>
// $(document).ready(function(){
  // $("#form1").submit(function(){
    // alert("Thank you for submitted form");
	
  // });
// });

$(document).ready(function() {
    $('#form1').submit(function() {
		$('.myModal2').show();
    });
});

</script>




<?php wp_footer(); ?>
</body>
</html>
