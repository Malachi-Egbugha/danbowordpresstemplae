<?php
/**
 * Template Name: Community
 */

get_header(); ?>
<main> 
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
 <?php
	while ( have_posts() ) : the_post();
	$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
?> 
  <!-- Student Council -->
  <div class="awelcome">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="aboutimg"><img src="<?php echo $image[0];?>"  alt=" "></div>
          </div>
          <div class="col-lg-6 pl-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="comm">
              <?php the_content(); ?>
			</div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Student Council --> 
<?php endwhile;  ?>  
  <!-- PTA -->
  <div class="sixth commty">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 pr-5 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="comm">
              <?php echo get_field('pta_content');?>
			 </div>
          </div>
          <div class="col-lg-6 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="sixthimg"><img src="<?php echo get_field('pta_image');?>"  alt=" "></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end PTA --> 
  
  <!-- Our Alumni -->
  <div class="alumni">
    <div class="container-fluid">
      <div class="maxw">
        <h3><?php echo get_field('our_alumni_title'); ?></h3>
        <div class="row">
          
		 
 <?php 
	$args = array( 'post_type' => 'our_alumni','orderby' => 'ID','order' => 'ASC','posts_per_page' => -1 );
	$loop = new WP_Query( $args );			 
	while ( $loop->have_posts() ) : $loop->the_post();					
	$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
	$getcontent=get_the_content();
	
	$image_id = get_post_thumbnail_id();
	$image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', TRUE);
	$image_title = get_the_title($image_id);
	
?>
<div class="col-lg-4 col-md-4 col-sm-6 wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">
<div class="ourin">
  <div class="our1img"><img src="<?php echo $imgurl;?>" alt=" "></div>
  <h4><?php the_title(); ?></h4>
  <p><?php echo $getcontent;?></p>
  <a href="#" class="visitweb">Read More</a>
  <div class="clearfix"></div>
</div>
</div>	
<?php endwhile; wp_reset_postdata(); ?>

		 
		  
		  
          
		  
		  
		  
		  
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Alumni --> 
  
  <!-- Our Join  -->
  <div class="join">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-3 col-md-4">
            <h3><?php echo get_field('join_with_us');?></h3>
          </div>
          <div class="col-lg-7 col-md-6">
            <p><?php echo get_field('join_with_us_content');?></p>
          </div>
          <div class="col-lg-2 col-md-2"> <a href="<?php echo get_field('join_with_us_link');?>" class="joinus">Join us</a> </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Join  --> 
  
</main>
<?php get_footer(); ?>
