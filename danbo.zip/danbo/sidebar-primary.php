<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
?>

<div class="col-lg-3">
  <div class="abright">
	<h4>Primary</h4>
	<ul>
	  <li class="<?php if(is_page('head-teachers-welcome-note')){ echo 'active';}?>">
		<a href="<?php echo home_url('/head-teachers-welcome-note/'); ?>">Welcome Message </a>
	  </li>
	  
	  <li class="<?php if(is_page('curriculum-overview')){ echo 'active';}?>">
		<a href="<?php echo home_url('/curriculum-overview/'); ?>">Curriculum Overview</a>
	  </li>
	  
	  <li class="<?php if(is_page('our-compulsory-skills-sets')){ echo 'active';}?>">
		<a href="<?php echo home_url('/our-compulsory-skills-sets/'); ?>">Primary Curriculum and Subjects</a>
	  </li>
	  <li class="<?php if(is_page('primary-assessment')){ echo 'active';}?>">
		<a href="<?php echo home_url('/primary-assessment/'); ?>">Assessment and Reporting</a>
	  </li>
	   <li class="<?php if(is_page('extra-curriculum-activities')){ echo 'active';}?>">
		<a href="<?php echo home_url('/extra-curriculum-activities/'); ?>">Co-curricular and Extra-curricular activities</a>
	  </li>
	  <li class="<?php if(is_page('our-core-values')){ echo 'active';}?>">
		<a href="<?php echo home_url('/our-core-values/'); ?>">Our Core Values</a>
	  </li>
	   <li class="<?php if(is_page('other-activities')){ echo 'active';}?>">
		<a href="<?php echo home_url('/other-activities/'); ?>">Other Activities</a>
	  </li>
	  
	  <li class="<?php if(is_page('events-special-day')){ echo 'active';}?>">
		<a href="<?php echo home_url('/events-special-day/'); ?>">Events / Special Days</a>
	  </li>
	   <li class="<?php if(is_page('facilities1')){ echo 'active';}?>">
		<a href="<?php echo home_url('/facilities1/'); ?>">Facilities</a>
	  </li>
	   <li class="<?php if(is_page('primary-admissions')){ echo 'active';}?>">
		<a href="<?php echo home_url('/primary-admissions/'); ?>">Admissions</a>
	  </li>
	  
	 
	  
	  </ul>
  </div>
</div>
