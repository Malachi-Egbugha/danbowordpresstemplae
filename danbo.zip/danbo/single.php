<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); ?>

<main> 
  
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
	
  	
  <!-- Our blog -->
  <div class="sblog">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-7 col-md-7 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
			  
			  
            <div class="blogin">
              <div class="blogr">
                <div class="blogimg"><img src="<?php echo $image[0];?>" alt=" "></div>
                <div class="deta"><span><?php echo get_the_date(); ?></span></div>
              </div>
              <h3><?php echo the_title(); ?></h3>
             <?php the_content();?>
            </div>
			 
           <?php if (is_single ()) comments_template (); ?>
          </div>
          <div class="col-lg-5 col-md-5 pl-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="md-form mt-0">
              <form role="search" method="get"  action="<?php echo esc_url( home_url( '/' ) ); ?>">
			 <input class="form-control search" value="<?php echo get_search_query(); ?>" name="s" type="search" placeholder="Search Here" aria-label="Search">
              <button class="btn serarb btn-rounded btn-sm my-0" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
           </form>
			 </div>
            <div class="rpost">
              <h4>Recent Post</h4>
				<?php
			$args = array( 'post_type' => 'post', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			
			while ( $loop->have_posts() ) : $loop->the_post(); global $product;
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>				
              <div class="postr">
                <div class="row">
                  <div class="col-lg-5">
                    <div class="postrimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
                  </div>
                  <div class="col-lg-7">
                    <h4><a href="<?php the_permalink();?>"><?php echo $title;?></a></h4>
                  </div>
                </div>
              </div>
				<?php  endwhile; wp_reset_postdata(); ?>

				
              <div class="clearfix"></div>
            </div>
            <div class="rpost">
              <h4>Tag</h4>
              <div class="tars">
                <?php the_tags( '<ul class="tags"><li class="tag">', '</li><li class="tag">', '</li></ul>' ); ?>
              </div>
              <div class="clearfix"></div>
            </div>
            <div class="rpost">
              <div class="tagimg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/tagimg.jpg);">
                <div class="callus">
                  <h5>Call Us</h5>
                  <p>Curabitur ac ante at sapien placerat ultrices id vitae purus. Nunc euismod lacus ut tortor scelerisque ornare.</p>
                  <a href="#" class="hare">Call Here</a> </div>
              </div>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our blog --> 
  
</main>
<?php endwhile;  ?>  
<?php get_footer(); ?>
