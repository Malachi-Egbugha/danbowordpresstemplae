<?php
/**
 * Template Name: Dis Portal
 */

get_header();

//Student Login
$msg='';
if(isset($_POST['submit']) && $_POST['submit']=='Login')
{

global $wpdb;
$username = $wpdb->escape($_REQUEST['username']);
$password = $wpdb->escape($_REQUEST['password']);

$creds = array();
$creds['user_login'] = $username;
$creds['user_password'] =$password;

$user = wp_signon( $creds, false );

if ( is_wp_error($user) ){
$err=$user->get_error_message();
$msg_student= "Username or password error try again!";
}
else{
//print_r($user);	

$user_meta=get_userdata($user->ID);

$user_roles=$user_meta->roles;
//print_r($user_roles);
if($user_roles[0]=='student'){
$_SESSION['userid']=$user->ID;
	
echo "<script type='text/javascript'>window.location.href='".home_url('/dashboard/')."' </script>";  

}

}

}



//Staff Login

$msg='';
if(isset($_POST['submit1']) && $_POST['submit1']=='Login')
{

global $wpdb;
$username = $wpdb->escape($_REQUEST['username']);
$password = $wpdb->escape($_REQUEST['password']);

$creds = array();
$creds['user_login'] = $username;
$creds['user_password'] =$password;

$user = wp_signon( $creds, false );

if ( is_wp_error($user) ){
$err=$user->get_error_message();
$msg_staff= "Username or password error try again!";
}
else{
//print_r($user);	

$user_meta=get_userdata($user->ID);

$user_roles=$user_meta->roles;
//print_r($user_roles);
if($user_roles[0]=='staff'){
$_SESSION['staff_id']=$user->ID;
	
echo "<script type='text/javascript'>window.location.href='".home_url('/staff-dashboard/')."' </script>";  

}

}

}





//Parent Login

$msg='';
if(isset($_POST['submit2']) && $_POST['submit2']=='Login')
{

global $wpdb;
$username = $wpdb->escape($_REQUEST['username2']);
$password = $wpdb->escape($_REQUEST['password2']);

$creds = array();
$creds['user_login'] = $username;
$creds['user_password'] =$password;

$user = wp_signon( $creds, false );

if ( is_wp_error($user) ){
$err=$user->get_error_message();
$msg_parent= "Username or password error try again!";
}
else{
//print_r($user);	

$user_meta=get_userdata($user->ID);

$user_roles=$user_meta->roles;
//print_r($user_roles);
if($user_roles[0]=='parent'){
$_SESSION['parent_id']=$user->ID;
	
echo "<script type='text/javascript'>window.location.href='".home_url('/parent-dashboard/')."' </script>";  

}

}

}


 ?>
<main> 
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
	<?php } else {?>
	<div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
	<?php } ?>
  <!-- end about --> 
  
  <!-- DIS Portal -->
  <div class="dis">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class=" wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s"><?php echo get_post_field('post_content',24);?></h3>
        <div class="row">
			<?php
					$args = array( 'post_type' => 'dis_portal', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
					$loop = new WP_Query( $args );
					$n = 0;
					while ( $loop->have_posts() ) : $loop->the_post(); global $product;
					$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
					$title=get_the_title();
					$getcontent=get_the_content();

				?>
			
          <div class="col-lg-4 col-md-4 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="distext">
              <div class="disimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
              <h4><?php $title;?></h4>
              <?php echo $getcontent;?>
              <a href="#" class="arrows"><img src="<?php echo get_template_directory_uri(); ?>/img/darrow.png" alt=" "></a>
              <div class="clearfix"></div>
            </div>
          </div>
			<?php $p++; endwhile; wp_reset_postdata(); ?>
			

			
			
        </div>
        <a href="<?php echo home_url('/student-access/');?>" class="mores">More Resource</a> </div>
    </div>
  </div>
  <!-- end DIS Portal --> 
  
  <!-- Staff Access -->
  <div class="frame acces">
    <div class="row">
      <div class="col-lg-5">
        <div class="framel">
          <h3 class=" wow fadeIn" data-wow-duration="2s" data-wow-delay=".5s">Staff Access</h3>
			<?php the_field('staff_access',24); ?>

          <a href="<?php echo home_url('/staff-access/');?>" class="morem">Read More</a>
          <div class="clearfix"></div>
        </div>
      </div>
      <div class="col-lg-7 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
        <div class="frame-img" style="background:url(<?php the_field('staff_access_image',24); ?>"></div>
      </div>
    </div>
  </div>
  <!-- end Staff Access --> 
  
  <!-- Parents login -->
  <div class="admission parents">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-5 mr-5" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo get_template_directory_uri(); ?>/img/admission1.jpg"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-5" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admiss">
           
			 <?php
				if ( $_SESSION['staff_id']!='' ) { ?>
   
				<a href="<?php echo home_url('/staff-dashboard/'); ?>"> Dashboard</a>
				<?php
				} else {
			  ?>
			    
			  <h3>Staff login</h3>
               <p style="color:red"><?php echo $msg_staff; ?></p>
			  <form method="post" action="">
                <div class="form-group">
                  <input type="email" class="form-control fild6"  name="username" placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control fild6" name="password" placeholder="Password">
                </div>
                <!--<button type="submit" class="btn btn-default submit">LOGIN</button>-->
				<input type="submit" name="submit1" class="btn btn-default submit" value="<?php _e('Login'); ?>"/>
                <button type="submit" class="btn btn-default forgot"><a href="<?php echo home_url('/my-account/lost-password/');?>"> Forgot your password? </a></button>
              </form>
			  
				<?php } ?>
			 

			 <div id="register-link" class="text-right">
				<a href="<?php echo home_url('/staff-register/'); ?>" class="text-info">Create a account ? Sign up</a>
			</div>
              <div class="clearfix"></div>
           
			
			
			
			
			</div>
			
			
			
			
			
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Parents login --> 
  
  
  
  
  <!-- Parents login -->
  <div class="admission parents">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-5 mr-5" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo get_template_directory_uri(); ?>/img/admission1.jpg"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-5" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admiss">
           
			  <?php
				if ( $_SESSION['parent_id']!='' ) { ?>
   
				<a href="<?php echo home_url('/parent-dashboard/'); ?>"> Dashboard</a>
				<?php
				} else {
			  ?>
			    
			  <h3>Parent login</h3>
               <p style="color:red"><?php echo $msg_parent; ?></p>
			  <form method="post" action="">
                <div class="form-group">
                  <input type="email" class="form-control fild6"  name="username2" placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control fild6" name="password2" placeholder="Password">
                </div>
                <!--<button type="submit" class="btn btn-default submit">LOGIN</button>-->
				<input type="submit" name="submit2" class="btn btn-default submit" value="<?php _e('Login'); ?>"/>
                <button type="submit" class="btn btn-default forgot"><a href="<?php echo home_url('/my-account/lost-password/');?>"> Forgot your password? </a></button>
              </form>
			  
				<?php } ?>
			 <div id="register-link" class="text-right">
				<a href="<?php echo home_url('/parents-register/'); ?>" class="text-info">Create a account ? Sign up</a>
			</div>
              <div class="clearfix"></div>
           
			
			
			
			
			</div>
			
			
			
			
			
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Parents login --> 

 
  <!-- Parents login -->
  <div class="admission parents">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-5 mr-5" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo get_template_directory_uri(); ?>/img/admission1.jpg"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-5" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admiss">
           
			  <?php
				if ( $_SESSION['userid']!='' ) { ?>
   
				<a href="<?php echo home_url('/dashboard/'); ?>"> Dashboard</a>
				<?php
				} else {
			  ?>
			    
			  <h3>Student login</h3>
               <p style="color:red"><?php echo $msg_student; ?></p>
			  <form method="post" action="">
                <div class="form-group">
                  <input type="email" class="form-control fild6"  name="username" placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control fild6" name="password" placeholder="Password">
                </div>
                <!--<button type="submit" class="btn btn-default submit">LOGIN</button>-->
				<input type="submit" name="submit" class="btn btn-default submit" value="<?php _e('Login'); ?>"/>
                <button type="submit" class="btn btn-default forgot"><a href="<?php echo home_url('/my-account/lost-password/');?>"> Forgot your password? </a></button>
              </form>
			  
				<?php } ?>

			 <div id="register-link" class="text-right">
				<a href="<?php echo home_url('/student-register/'); ?>" class="text-info">Create a account ? Sign up</a>
			</div>
              <div class="clearfix"></div>
           
			
			
			
			
			</div>
			
			
			
			
			
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Parents login --> 
  
  
  
</main>
<?php


get_footer(); ?>