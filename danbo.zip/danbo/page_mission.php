<?php
/**
 * Template Name: Mission
 */

get_header(); ?>
<main> 
  
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
             <?php include('sidebar-about.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3>Vision, Mission and Values</h3>
                
				  <?php echo get_post_field('post_content', 38);?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php get_footer(); ?>