<?php
/**
 * Template Name: Staff Profile
 */

get_header();


if($_SESSION['staff_id']==""){
	//exit;
echo "<script type='text/javascript'>window.location.href='". home_url('/staff-login/') ."'</script>";echo "<script type='text/javascript'>window.location.href='". home_url('/staff-login/') ."'</script>";	
}

$user_id = $_SESSION['staff_id'];
$user = get_userdata( $user_id );
$user_roles = $user->roles;


//global $current_user, $wp_roles;
 $error = array();    
/* If profile was saved, update profile. */
if ( $_POST['action'] == 'update-user' ) {

   
    if ( !empty( $_POST['first-name'] ) )
        update_user_meta( $user_id, 'first_name', esc_attr( $_POST['first-name'] ) );
    if ( !empty( $_POST['last-name'] ) )
        update_user_meta($user_id, 'last_name', esc_attr( $_POST['last-name'] ) );
    if ( !empty( $_POST['description'] ) )
        update_user_meta( $user_id, 'description', esc_attr( $_POST['description'] ) );
	
	if ( !empty( $_POST['student_phone_number'] ) )
        update_user_meta( $user_id, 'student_phone_number', esc_attr( $_POST['student_phone_number'] ) );

   if ( !empty( $_POST['student_address'] ) )
        update_user_meta($user_id, 'student_address', esc_attr( $_POST['student_address'] ) );
	
	if ( !empty( $_POST['student_class'] ) )
        update_user_meta($user_id, 'student_class', esc_attr( $_POST['student_class'] ) );

	//teacher Field

	if ( !empty( $_POST['teacher_phone_number'] ) )
        update_user_meta($user_id, 'teacher_phone_number', esc_attr( $_POST['teacher_phone_number'] ) );
	
	if ( !empty( $_POST['teacher_address'] ) )
        update_user_meta($user_id, 'teacher_address', esc_attr( $_POST['teacher_address'] ) );



   
$msg="Profile updated sucessfully !";

   /* Update user password. */
    if ( !empty($_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {
        if ( $_POST['pass1'] == $_POST['pass2'] )
            wp_update_user( array( 'ID' => $user_id, 'user_pass' => esc_attr( $_POST['pass1'] ) ) );
        else
            $error[] = __('The passwords you entered do not match.  Your password was not updated.', 'profile');
    }

   
    if ( !empty( $_POST['email'] ) ){
        if (!is_email(esc_attr( $_POST['email'] )))
            $error[] = __('The Email you entered is not valid.  please try again.', 'profile');
        elseif(email_exists(esc_attr( $_POST['email'] )) != $user_id )
            $error[] = __('This email is already used by another user.  try a different one.', 'profile');
        else{
            wp_update_user( array ('ID' =>$user_id, 'user_email' => esc_attr( $_POST['email'] )));
        }
    }
	
	
	
	

   if ( count($error) == 0 ) {
        //action hook for plugins and extra fields saving
        do_action('edit_user_profile_update', $user_id);
        wp_redirect( get_permalink().'?updated=true' ); 
		//exit;
    } 
   
   
}


 
 ?>
<main> 
  
  <!-- about -->
 
    
<?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			
		 <?php include('sidebar-Staff.php'); ?>
			
			
            <div class="col-lg-9">
              <div class="abarea">
                <h3>Edit Profile</h3>
           
                <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>
				 <p style="color:green"><?php echo $msg;?></p>
				<form name="form" method="post" enctype="multipart/form-data">
              <div class="row">
              
	
	
  <div class="col-lg-6 col-md-6"> 
  <div class="form-group">
    <label for="exampleInputtext">First Name</label>
    <input type="text" name="first-name" value="<?php the_author_meta( 'first_name', $user_id ); ?>" class="form-control" placeholder="First Name">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Last Name</label>
    <input type="text" name="last-name" value="<?php the_author_meta( 'last_name', $user_id ); ?>" class="form-control" placeholder="Last Name">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" disabled value="<?php the_author_meta( 'user_email', $user_id); ?>" class="form-control" placeholder="Email">
  </div>
  </div>
  
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" name="pass1"  class="form-control" placeholder="Password">
  </div>
  </div>
  
   <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">Confirm password</label>
    <input type="password" name="pass2" class="form-control" placeholder="Password">
  </div>
  </div>
  
  
  
  <button onclick="myFunction()" type="submit" name="updateuser" class="btn btn-default dsubmit">Update</button>
  <?php wp_nonce_field( 'update-user' ) ?>
  <input name="action" type="hidden" id="action" value="update-user" />
  
  </div>
</form>
				
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php   get_footer(); ?>
