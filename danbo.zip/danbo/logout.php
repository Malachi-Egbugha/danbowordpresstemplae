<?php
session_start();

/**
 * Template Name: logout 
 
 */
 
 unset($_SESSION['userid']);
 unset($_SESSION['staff_id']);
 header( 'Location:' . home_url());
?>