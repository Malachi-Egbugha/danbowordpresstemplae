<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); 



?>
<?php if( is_page('assessment-and-reporting') || is_page('admission-process') || is_page('events-special-days') || is_page('our-facilities') || is_page('school-times-schedule') || is_page('extra-curricular-activities') || is_page('welcome-message') || is_page('curriculum') || is_page('program') || is_page('co-curricular-activities') ){?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
        
		 ?>
		 <?php include('sidebar.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>

<?php } else if(is_page('sixth-form') || is_page('early-years') || is_page('danbo-boarding-school') || is_page('college') || is_page('sens') || is_page('primary') || is_page('secondary')) {?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
		 
         ?>
		 <?php include('SchoolLifesideber.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>

<?php } else if(is_page('where-are-our-graduates-alumni-now') || is_page('alumni') || is_page('student-council') || is_page('pta')) {?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebarcommunity.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>


<?php } else if(is_page('other-activities') || is_page('facilities1') || is_page('sports-and-clubs') || is_page('extra-curriculum-activities') || is_page('primary-assessment') || is_page('events-special-day') || is_page('our-core-values') || is_page('our-compulsory-skills-sets') || is_page('head-teachers-welcome-note') || is_page('primary-admissions') || is_page('curriculum-overview')){?> 
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar-primary.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php } else if(is_page(687) || is_page(685) || is_page(683)){?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar-secondary.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>

<?php } else if(is_page(696) || is_page(694) || is_page(692) || is_page(1058) || is_page(1060) || is_page(1063) || is_page(1065) || is_page(1067) || is_page(1069) || is_page(1071)){ ?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar-sens.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>


<?php } else if(is_page(878) || is_page(730) || is_page(725) || is_page(722) || is_page(719) || is_page(716) || is_page(701) || is_page(704) || is_page(710) || is_page(713)) {?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar-college.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>

<?php } else if(is_page(734) || is_page(736) || is_page(738) || is_page(1089) || is_page(1091) || is_page(1093) || is_page(1095) || is_page(1097) || is_page(1099) || is_page(1101)){ ?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar-danboboardingschool.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php } else if(is_page(784) || is_page(941) || is_page(777) || is_page(774) || is_page(771) || is_page(768) || is_page(765) || is_page(759) || is_page(756) || is_page(752) || is_page(750)){?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar-sixty.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php } else { ?>
<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		
            <div class="col-lg-12">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php } ?>
<?php get_footer(); ?>
<div class="modal admissionfrom clearfix" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content"> 
      
      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
      <!-- Modal body -->
      <div class="modal-body admiss">
        <div class="admiss">
          <h3>Begin Your Registration for the 2020/2021 entrance examination </h3>
         <?php echo $msg;?>
		  <form action="<?php echo get_page_link(388);?>" method="post" enctype="multipart/form-data">
		   <input type="hidden" name="register" value="Register">
            <div class="form-group fild2">
              <input type="text" class="form-control fild3" name="FirstName"  placeholder="First Name">
            </div>
            <div class="form-group fild2 fild4">
              <input type="text" class="form-control fild3" name="LastName" placeholder="Last Name">
            </div>
            <div class="form-group fild2">
              <input type="text" class="form-control fild3"  placeholder="Phone">
            </div>
            <div class="form-group fild2 fild4">
              <input type="email" class="form-control fild3" name="temail" placeholder="Email">
            </div>
            <!--<div class="form-group">
              <textarea class="form-control fild5" rows="3" placeholder="Message"></textarea>
            </div>-->
			
			<div class="form-group" style="display:none;" >
					<label for="password" class="text-info">APPID:</label><br>
					<input type="text" name="appid" value="<?php echo "DIS/APPID/2020/".rand(1000, 9999) . rand(1000, 9999);?>" id="password" class="form-control">
				</div>
				
				 <div class="form-group" style="display:none;">
					<label for="password" class="text-info">Password:</label><br>
					<input type="password" name="_password" value="<?php echo(rand());?>" id="password" class="form-control">
				</div>
            <button type="submit" class="btn btn-default submit">BEGIN REGISTRATION</button>
          </form>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- end The Modal -->