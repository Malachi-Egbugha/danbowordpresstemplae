<?php
/*
Template Name: Login
*/
get_header();

$msg='';
if(isset($_POST['submit'])) 
{
    global $wpdb;
 	$username = $wpdb->escape($_REQUEST['username']);
    $password = $wpdb->escape($_REQUEST['password']);
   
   		$creds = array();
		$creds['user_login'] = $username;
		$creds['user_password'] = $password;
		
		$user = wp_signon( $creds, false );
		
			if ( is_wp_error($user) ){
			$err=$user->get_error_message();
			//$msg='<h3 class="mesg">'.$err.'</h3>';
			$msg= "<h3 class='mesg'>Login Error!</h3>";
			}
			else
			header( 'Location:' . home_url());// this will redirect to Home Page		
}










?>
 <main>

    <!-- about -->
    <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<div class="aboutin">
      <div class="container-fluid">
	  <div class="maxw">
	  <div class="row">
	  <div class="col-lg-12">
	  <div class="abarea">
        <div class="row">
          
          <div id="login-column" class="col-lg-7">
            <div id="login-box" class="col-md-12">
              <?php //wp_login_form();

				
  global $current_user;
  get_currentuserinfo();
  $name= $current_user->first_name;
?>

			
			  
			  <?php
				if ( is_user_logged_in() ) {
					echo '<h3 class="text-center text-info">WelCome :'.$name.'</h3>';
				} else {
					 wp_login_form( array('redirect' => home_url('/parent-dashboard/')) );
				}
			?>
			  
			  
			  <?php// echo $msg; ?>
			  <!--<form id="login-form" class="form" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
                <h3 class="text-center text-info">Login</h3>
                <div class="form-group">
                  <label for="username" class="text-info">Username:</label><br>
                  <input type="text" name="username" id="username" class="form-control">
                </div>
                <div class="form-group">
                  <label for="password" class="text-info">Password:</label><br>
                  <input type="text" name="password" id="password" class="form-control">
                </div>
                <div class="form-group">
                  <label for="remember-me" class="text-info"><span><input id="remember-me" name="remember-me"
                        type="checkbox"></span><span>Remember me</span></label><br>
                  <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
                </div>
                <div id="register-link" class="text-right">
                  <a href="register.html" class="text-info">Register here</a>
                </div>
              </form>-->
            </div>
          </div>
        </div>
      </div>
	  </div>
	  </div>
	  </div>
	  </div>
	  </div>
    </div>
    <!-- end about -->



  </main>

<?php get_footer(); ?>