<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<div class="col-lg-3">
  <div class="abright">
	<h4>Staff Dashboard</h4>
	<ul>
	  <li class="<?php if(is_page('staff-profile')){ echo 'active';}?>"><a href="<?php echo home_url('/staff-profile/'); ?>">Profile</a></li>
	 <li class=""><a href="<?php echo get_page_link('973');?>">Logout</a> </li>
	</ul>
  </div>
</div>
