<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
?>

<div class="col-lg-3">
  <div class="abright">
	<h4>Dashboard</h4>
	<ul>
	  <li class="<?php if(is_page('parent-dashboard')){ echo 'active';}?>"><a href="<?php echo home_url('/parent-dashboard/'); ?>">Parents resources</a></li>
	  <li class="<?php if(is_page('parent-profile')){ echo 'active';}?>"><a href="<?php echo home_url('/parent-profile/'); ?>">Profile</a></li>

	 <li class="<?php if(is_page('parent-payment')){ echo 'active';}?>"><a href="<?php echo home_url('/parent-payment/'); ?>">Payment</a> </li>
	
	 <li class="<?php if(is_page('welcome-message')){ echo 'active';}?>"><a href="<?php echo wp_logout_url( home_url() ); ?>">Logout</a> </li>
	</ul>
  </div>
</div>
