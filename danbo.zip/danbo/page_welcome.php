<?php
/**
 * Template Name: Welcome

 */

get_header(); ?>

<main> 
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?> 
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
 <?php } else {?>   
<div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">	
<?php } ?>	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
		 <?php include('sidebar.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3><?php the_title();?></h3>
				<?php the_content(); ?>
			</div>
            </div>
			
		<?php endwhile;  ?>	
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>





















<?php get_footer(); ?>
