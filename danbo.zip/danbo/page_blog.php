<?php
/**
 * Template Name: Blog
 */

get_header(); ?>
<main> 
  
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
  <!-- Our blog -->
  <div class="sblog">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-7 col-md-7 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
			  <?php
			  $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
			$args = array( 
			'post_type' => 'post',
			'posts_per_page' => 2, 
			'order' => 'ASC',
			'orderby' => 'ID',
			'paged' => $paged,
			'product_cat' => ''
			);
			$loop = new WP_Query( $args );
			$n = 0;
			while ( $loop->have_posts() ) : $loop->the_post(); 
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
			  
            <div class="blogin">
              <div class="blogr">
                <div class="blogimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
                <div class="deta"><span><?php echo get_the_date(); ?></span></div>
              </div>
              <h3><a href="<?php the_permalink();?>"><?php echo $title;?></a></h3>
              <ul>
                <li><i class="fa fa-user-o" aria-hidden="true"></i><a href="#"> By <?php the_author();?></a></li>
                <li><i class="fa fa-tag" aria-hidden="true"></i><a href="#"><?php the_tags( '<ul class="tags"><li class="tag">', '</li><li class="tag">', '</li></ul>' ); ?></a></li>
                <li><i class="fa fa-comments-o" aria-hidden="true"></i><a href="#"><?php $commentscount = get_comments_number(); echo $commentscount; ?> Comments</a></li>
              </ul>
              <p><?php echo $getcontent;?></p>
              <div class="clearfix"></div>
            </div>
			  <?php $p++; endwhile; wp_reset_postdata(); ?> 

            <ul class="pagination">
              
			  <!--<li class="page-item active"><a class="page-link" href="#">01</a></li>
              <li class="page-item"><a class="page-link" href="#">02</a></li>
              <li class="page-item"><a class="page-link" href="#"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> </a></li>-->
            
			<?php 
                        $big = 999999999; // need an unlikely integer
                        $pages = paginate_links( array(
                                                'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                                                'format' => '?paged=%#%',
                                                'current' => max( 1, get_query_var('paged') ),
                                                'total' => $loop->max_num_pages,
                                                'prev_next' => true,
                                                'prev_text'          => __('<<'),
                                                'next_text'          => __('>>'),
                                                'type' => 'array'
                                            ) );
                        if( is_array( $pages ) ) {					
                            $i = 1;
                            foreach ( $pages as $page ) {
                                echo '<li>'.$page.'</li>';
                                $i++;
                            }
                        }
                    ?>
			
			</ul>
          </div>
          <div class="col-lg-5 col-md-5 pl-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="md-form mt-0">
             <form role="search" method="get"  action="<?php echo esc_url( home_url( '/' ) ); ?>">
			 <input class="form-control search" value="<?php echo get_search_query(); ?>" name="s" type="search" placeholder="Search Here" aria-label="Search">
              <button class="btn serarb btn-rounded btn-sm my-0" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
           </form>
		   </div>
            <div class="rpost">
              <h4>Recent Post</h4>
				<?php
			$args = array( 'post_type' => 'post', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			
			while ( $loop->have_posts() ) : $loop->the_post(); global $product;
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>				
              <div class="postr">
                <div class="row">
                  <div class="col-lg-5">
                    <div class="postrimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
                  </div>
                  <div class="col-lg-7">
                    <h4><a href="<?php the_permalink();?>"><?php echo $title;?></a></h4>
                  </div>
                </div>
              </div>
				<?php  endwhile; wp_reset_postdata(); ?>

				
              <div class="clearfix"></div>
            </div>
            <div class="rpost">
              <h4>Tag</h4>
              <div class="tars">
                <?php //the_tags( '<ul class="tags"><li class="tag">', '</li><li class="tag">', '</li></ul>' ); ?>
              
			  <ul class="tags">

<?php
    $tags = get_tags('post_tag');
	
//echo "<pre>";
	//print_r($tags);

	//var_dump($tags);
 
   if ( $tags ) :
     
   foreach ( $tags as $tag ) : ?>
  
          <li class="tag"><a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" title="<?php echo esc_attr( $tag->name ); ?>"><?php echo esc_html( $tag->name ); ?></a></li>
     
   <?php endforeach; ?>
  
  <?php endif; ?>

</ul>
			  </div>
              <div class="clearfix"></div>
            </div>
            <div class="rpost">
              <div class="tagimg" style="background:url(<?php echo get_field('call_us_image');?>);">
                <div class="callus">
                  <h5><?php echo get_field('call_us');?></h5>
                  <p><?php echo get_field('call_us_content');?></p>
                  <a href="<?php echo get_field('call_link');?>" class="hare">Call Here</a> </div>
              </div>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our blog --> 
  
</main>
<?php


get_footer(); ?>
