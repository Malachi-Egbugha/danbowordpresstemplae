<?php

class dbconn
	{
		public $db;
		function __construct()
		{
			$this->db = new mysqli("localhost","danbosch_school","danboschool1","danbosch_schooldb");
			if($this->db->connect_errno>0)
			{
			die("Sorry we are undergoing system maintanance we would be back shortly");
			}

		}

		public function login($pa, $username,   $tablename)
		{
			$pa = $this->db->real_escape_string($pa);
			$username=$this->db->real_escape_string($username);
			$qury=$this->db->query("SELECT * FROM ". $tablename ." WHERE password = '$pa' and username = '$username'");//select from student table
			
				if($qury->num_rows)
				{
				
					
						while($row=$qury->fetch_object())
						{
                            if($row->role == "user")
                            {
								
								$_SESSION['email']=$row->username;
                                $_SESSION['status']=$row->status;
                                $_SESSION['firstname']=$row->firstname;
                                $_SESSION['surname']=$row->surname;
								$_SESSION['role'] = $row->role;
								$_SESSION['userid'] = $row->userid;
                                header("Location: ../studentportal/"); // Redirect user to user portal  echo home_url('/portal/');

                            }
                            elseif($row->role == "admin")
                            {
                                $_SESSION['email']=$row->username;
                                $_SESSION['status']=$row->status;
                                $_SESSION['firstname']=$row->firstname;
                                $_SESSION['surname']=$row->surname;
								$_SESSION['role'] = $row->role;
								$_SESSION['userid'] = $row->userid;
								//echo $row->role;
                                header("Location: ../studentportal/"); // Redirect user to admin portal
                               


							}
							elseif($row->role == "staff")
                            {
                                $_SESSION['email']=$row->username;
                                $_SESSION['status']=$row->status;
                                $_SESSION['firstname']=$row->firstname;
                                $_SESSION['surname']=$row->surname;
								$_SESSION['role'] = $row->role;
								$_SESSION['userid'] = $row->userid;
                                header("Location: staff"); // Redirect user to admin portal


                            }
                            else
                            {
                                
                                header("Location: index.php"); // Redirect user to login page
							
                            }
                        }
				}
				else
				{
					echo $this->db->error;
					
          $_SESSION['message']= 1;
				}
		}
	

		//insert 7 data to users table
		public function insertsix($tablename, $firstname,$surname, $userid, $email, $role,$class, $password, $status )
		{
			$sql = "INSERT INTO ". $tablename . " (firstname,surname,userid,username,role,class,password,status) VALUES ('$firstname', '$surname','$userid','$email', '$role','$class','$password','$status')";
			if($this->db->query($sql))
			{
				$_SESSION['adminmessage']= 1;
			}
			else{
				echo $this->db->error;
			}
		}
		//select all from table passed as variable

		public function selectalldata($tablename)
		{
			
			$qury=$this->db->query("SELECT * FROM ". $tablename ."");//select from student table
			return $qury;


		}
		//update one data
		public function updateone($tablename, $id , $status)
		{
			$sql = "UPDATE ". $tablename ." SET status = '$status' WHERE id='$id'";
			if($this->db->query($sql))
			{
				//enter session for success;
			}
			else{
				echo $this->db->error;
			}

		}
		

	}
?>
