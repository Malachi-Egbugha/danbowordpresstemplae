<?php
class Admin extends Authentication{
    public $admin;
    public function __construct($admin,$authenticationvariable)
    {
        $this->admin = $admin;
        parent::__construct($authenticationvariable);

    }
    public function checkadmin()
    {
        if( $this->admin != "admin")
        {
            $_SESSION['message']= 4;
            header("Location: ../index.php");

        }
    }

}



class User extends Authentication{
    public $user;
    public function __construct($user,$authenticationvariable)
    {
        $this->user = $user;
        parent::__construct($authenticationvariable);

    }
    public function checkuser()
    {
        if( $this->user != "user")
        {
            $_SESSION['message']= 5;
            header("Location: ../portal/");

        }
    }

}



class Authentication{
    public $authenticationvariable;
    public function __construct($authenticationvariable)
    {
        
        $this->authenticationvariable = $authenticationvariable;

    }
    public function auth()
    {
        if(!isset($_SESSION['status']))
        {
            $_SESSION['message']= 3;
            header("Location: ../index.php");

        }
        elseif($this->authenticationvariable == "inactive")
        {
            $_SESSION['message']= 2;
            header("Location: ../index.php");

        }
        
    }
}


 
?>