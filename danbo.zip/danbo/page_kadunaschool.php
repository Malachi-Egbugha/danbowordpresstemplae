<?php
/**
 * Template Name: Kaduna School
 */

get_header(); ?>
<main> 
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
	<?php } else {?>
	<div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
	<?php } ?>
 <?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
	
  	
  <!-- Our Welcome -->
  <div class="awelcome kaduna">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="aboutimg"><img src="<?php echo $image[0];?>"  alt=" "></div>
          </div>
          <div class="col-lg-6 pl-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <?php the_content();?>
		 </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Welcome --> 
  <?php endwhile;  ?> 
  <!-- Our Section -->
  <div class="section">
    <div class="container-fluid">
      <div class="maxw">
        <h3><?php echo get_field('our_section');?></h3>
        <div class="row">
          
		  <?php
					$args = array( 'post_type' => 'our_section', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
					$loop = new WP_Query( $args );
					
					while ( $loop->have_posts() ) : $loop->the_post(); 
					$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
					$title=get_the_title();
					$getcontent=get_the_content();
					$Link=get_field('our_section_link');
				?>
			
          <div class="col-lg-4 col-md-4 col-sm-6">
            <div class="ourin">
              <div class="our1img"><img src="<?php echo $imgurl;?>" alt=" "></div>
              <h4><?php the_title(); ?></h4>
              <p><?php echo $getcontent;?></p>
              <a href="<?php echo $Link;?>" class="visitweb">Visit Website</a>
              <div class="clearfix"></div>
            </div>
          </div>
			<?php  endwhile; wp_reset_postdata(); ?>
		  
		  
		  
		  
		  
		  
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Section --> 
  
  <!-- Our Admission -->
  <div class="admissin">
    <div class="row">
      <div class="col-lg-5 col-md-6 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
        <div class="addin">
          <h3><?php echo get_field('admission_title'); ?></h3>
          <p><?php echo get_field('admission_content'); ?></p>
          <a href="<?php echo get_field('admission_link'); ?>" class="enroll">Enroll</a>
          <div class="clearfix"></div>
        </div>
      </div>
      <div class="col-lg-7 col-md-6">
        <div class="addimg" style="background:url(<?php echo get_field('admission_image'); ?>);"></div>
      </div>
    </div>
  </div>
  <!-- end Our Admission --> 
  
  <!-- Our School at a Glance -->
  <div class="glancen">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s"><?php echo get_field('our_school_at_a_glance');?></h3>
        <div class="grid galleryGrid row no-gutters">
         
		 <?php
					$args = array( 'post_type' => 'galleries', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
					$loop = new WP_Query( $args );
					$n=0;
					while ( $loop->have_posts() ) : $loop->the_post(); 
					$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
					$title=get_the_title();
					$getcontent=get_the_content();

				?>
			<?php if($n==0){?>
           <div class="col-md-4 grid-item images">
		   <div class="item"> 
			<img src="<?php echo $imgurl;?>" alt="" class="img-fluid"> 
			<a class="lightBox fancybox" rel="ligthbox" href="<?php echo $imgurl;?>"> <i class="fa fa-search"></i> </a> </div>
          </div>
            <?php } else {  ?>
			<div class="col-md-4 grid-item videos">
            <div class="item" style="height: 293px;"> <img src="<?php echo $imgurl;?>" alt="" class="img-fluid">
			<a class="lightBox fancybox" rel="ligthbox" href="<?php echo $imgurl;?>"> <i class="fa fa-search"></i> </a> </div>
          </div>
			<?php } ?>
			
			<?php $n++; if($n==2){$n=0;} endwhile; wp_reset_postdata(); ?>
		 
		 
		
         

		<!-- <div class="col-md-4 grid-item videos">
            <div class="item" style="height: 293px;"> <img src="<?php echo get_template_directory_uri(); ?>/img/glanceimg1.jpg" alt="" class="img-fluid"> <a class="lightBox fancybox" rel="ligthbox" href="<?php echo get_template_directory_uri(); ?>/img/glanceimg1.jpg"> <i class="fa fa-search"></i> </a> </div>
          </div>
          <div class="col-md-4 grid-item images">
            <div class="item"> <img src="<?php echo get_template_directory_uri(); ?>/img/glanceimg4.jpg" alt="" class="img-fluid"> <a class="lightBox fancybox" rel="ligthbox" href="<?php echo get_template_directory_uri(); ?>/img/glanceimg4.jpg"> <i class="fa fa-search"></i> </a> </div>
          </div>
          <div class="col-md-4 grid-item images">
            <div class="item"> <img src="<?php echo get_template_directory_uri(); ?>/img/glanceimg2.jpg" alt="" class="img-fluid"> <a class="lightBox fancybox" rel="ligthbox" href="<?php echo get_template_directory_uri(); ?>/img/glanceimg2.jpg"> <i class="fa fa-search"></i> </a> </div>
          </div>
          <div class="col-md-4 grid-item videos">
            <div class="item"> <img src="<?php echo get_template_directory_uri(); ?>/img/glanceimg3.jpg" alt="" class="img-fluid"> <a class="lightBox fancybox" rel="ligthbox" href="<?php echo get_template_directory_uri(); ?>/img/glanceimg3.jpg"> <i class="fa fa-search"></i> </a> </div>
          </div>
         
		 <div class="col-md-4 grid-item videos">
            <div class="item"> <img src="<?php echo get_template_directory_uri(); ?>/img/glanceimg5.jpg" alt="" class="img-fluid"> <a class="lightBox fancybox" rel="ligthbox" href="<?php echo get_template_directory_uri(); ?>/img/glanceimg5.jpg"> <i class="fa fa-search"></i> </a> </div>
          </div>-->
		  
		  
		  
        </div>
      </div>
    </div>
  </div>
  <!-- end Our School at a Glance --> 
  
</main>















<?php get_footer(); ?>