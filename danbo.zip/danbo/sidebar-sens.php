<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
?>

<div class="col-lg-3">
  <div class="abright">
	<h4>Sens</h4>
	<ul>		
	  <li class="<?php if(is_page(692)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(692); ?>"><?php echo "Welcome Message"; ?></a>
	  </li>
	  
	  <li class="<?php if(is_page(694)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(694); ?>"><?php echo "Curriculum Overview and Subjects"; ?></a>
	  </li>
	  
	  <li class="<?php if(is_page(1058)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1058); ?>"><?php echo "Co-curricular and Extra-curricular activities"; ?></a>
	  </li>	
	  
	  <li class="<?php if(is_page(696)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(696); ?>"><?php echo "Why Choose DSENS? "; ?></a>
	  </li>  
	  
	  <li class="<?php if(is_page(1063)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1063); ?>"><?php echo "Assessment and Reporting"; ?></a>
	  </li>
	  
	  <li class="<?php if(is_page(1065)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1065); ?>"><?php echo "School Times/Schedules "; ?></a>
	  </li>
	  <li class="<?php if(is_page(1069)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1069); ?>"><?php echo "Events/Special Days"; ?></a>
	  </li>
	  <li class="<?php if(is_page(1067)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1067); ?>"><?php echo "Facilities"; ?></a>
	  </li>
	  <li class="<?php if(is_page(1071)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1071); ?>"><?php echo "Admissions"; ?></a>
	  </li>
	  <!--
	    
	  <li class="<?php if(is_page(1060)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1060); ?>"><?php echo get_the_title(1060); ?></a>
	  </li>
	  -->

	  
	  
	  </ul>
  </div>
</div>
