<?php
/**
 * Template Name: Parent Profile
 */

get_header();
//$user = wp_get_current_user();
//$wp_user_object = new WP_User($user->ID);
//$roll = $wp_user_object->set_role('parent');
//echo '<pre>';
//print_r($wp_user_object);

//$user = wp_get_current_user();

   
if (!is_user_logged_in() || current_user_can('student') || current_user_can('teacher') ) {
   exit;
}




global $current_user, $wp_roles;
 $error = array();    
/* If profile was saved, update profile. */
if ( $_POST['action'] == 'update-user' ) {

   
    if ( !empty( $_POST['first-name'] ) )
        update_user_meta( $current_user->ID, 'first_name', esc_attr( $_POST['first-name'] ) );
    if ( !empty( $_POST['last-name'] ) )
        update_user_meta($current_user->ID, 'last_name', esc_attr( $_POST['last-name'] ) );
    if ( !empty( $_POST['description'] ) )
        update_user_meta( $current_user->ID, 'description', esc_attr( $_POST['description'] ) );
	
	if ( !empty( $_POST['phone_no'] ) )
        update_user_meta( $current_user->ID, 'phone_no', esc_attr( $_POST['phone_no'] ) );

   if ( !empty( $_POST['address'] ) )
        update_user_meta( $current_user->ID, 'address', esc_attr( $_POST['address'] ) );

   
$msg="Profile updated sucessfully !";

   /* Update user password. */
    if ( !empty($_POST['pass1'] ) && !empty( $_POST['pass2'] ) ) {
        if ( $_POST['pass1'] == $_POST['pass2'] )
            wp_update_user( array( 'ID' => $current_user->ID, 'user_pass' => esc_attr( $_POST['pass1'] ) ) );
        else
            $error[] = __('The passwords you entered do not match.  Your password was not updated.', 'profile');
    }

   
    if ( !empty( $_POST['email'] ) ){
        if (!is_email(esc_attr( $_POST['email'] )))
            $error[] = __('The Email you entered is not valid.  please try again.', 'profile');
        elseif(email_exists(esc_attr( $_POST['email'] )) != $current_user->id )
            $error[] = __('This email is already used by another user.  try a different one.', 'profile');
        else{
            wp_update_user( array ('ID' => $current_user->ID, 'user_email' => esc_attr( $_POST['email'] )));
        }
    }
	
	

   if ( count($error) == 0 ) {
        //action hook for plugins and extra fields saving
        do_action('edit_user_profile_update', $current_user->ID);
        wp_redirect( get_permalink().'?updated=true' ); 
		//exit;
    } 
   
   
}


 
 ?>
<main> 
  
  <!-- about -->
 
    
<?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			
			 <?php include('sidebar-parent.php'); ?>
			
			
            <div class="col-lg-9">
              <div class="abarea">
                <h3>Edit Profile</h3>
           
                <?php if ( count($error) > 0 ) echo '<p class="error">' . implode("<br />", $error) . '</p>'; ?>
				 <p style="color:green"><?php echo $msg;?></p>
				<form name="form" method="post" enctype="multipart/form-data">
              <div class="row">
              <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">First Name</label>
    <input type="text" name="first-name" value="<?php the_author_meta( 'first_name', $current_user->ID ); ?>" class="form-control" placeholder="First Name">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Last Name</label>
    <input type="text" name="last-name" value="<?php the_author_meta( 'last_name', $current_user->ID ); ?>" class="form-control" placeholder="Last Name">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputEmail1">Email</label>
    <input type="email" name="email" disabled value="<?php the_author_meta( 'user_email', $current_user->ID ); ?>" class="form-control" placeholder="Email">
  </div>
  </div>
  
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">New Password</label>
    <input type="password" name="pass1" value="<?php echo $current_user->user_pass;?>" class="form-control" placeholder="Password">
  </div>
  </div>
  
   <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputPassword1">Confirm password</label>
    <input type="password" name="pass2" value="<?php echo $current_user->user_pass;?>" class="form-control" placeholder="Password">
  </div>
  </div>
  
  
  
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Phone No.</label>
    <input type="text" name="phone_no" value="<?php the_author_meta( 'phone_no', $current_user->ID ); ?>"class="form-control" placeholder="Phone No.">
  </div>
  </div>
  <div class="col-lg-6 col-md-6">
  <div class="form-group">
    <label for="exampleInputtext">Address</label>
    <textarea class="form-control" name="address" placeholder="Address" rows="3"><?php the_author_meta( 'address', $current_user->ID ); ?></textarea>
  </div>
  </div>
  
  <button onclick="myFunction()" type="submit" name="updateuser" class="btn btn-default dsubmit">Update</button>
  <?php wp_nonce_field( 'update-user' ) ?>
  <input name="action" type="hidden" id="action" value="update-user" />
  
  </div>
</form>
				
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php   get_footer(); ?>
<script>
(document).ready(function () { (’#paint’).show(1000); // 10 seconds
});

function myFunction() {
  
  //window.location.reload(true);
  //setTimeout(window.location.reload(), 29000);
  // window.setTimeout(function(){

        //Move to a new location or you can do something else
       // window.location.reload();

    // }, 3000);
	
	// window.onload = function(){
   // setInterval(function(){
       // alert("Hello");
   // }, 10000);
// };
	
	
	
	
}
</script>