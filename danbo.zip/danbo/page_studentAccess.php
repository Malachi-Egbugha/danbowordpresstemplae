<?php
/*
Template Name: Student Access
*/
get_header();




?>




<?php
if ( !is_user_logged_in() ) {
   echo "<script type='text/javascript'>window.location.href='". home_url('/student-login/') ."'</script>";
} 
?>


 <main>
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
  <!-- DIS Portal -->
  <div class="dis app">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class=" wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">Feature your APP here</h3>
        <div class="row">
            <?php
$args = array( 'post_type' => 'your_app', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
$loop = new WP_Query( $args );
$p = 0;
while ( $loop->have_posts() ) : $loop->the_post(); global $product;
$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
$title=get_the_title();
$getcontent=get_the_content();

?>
          <div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="distext">
              <div class="disimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
              <h4><?php echo $title;?></h4>
              <p><?php echo $getcontent;?> </p>
              <a href="#" class="arrows"><img src="<?php echo get_template_directory_uri(); ?>/img/darrow.png" alt=" "></a>
              <div class="clearfix"></div>
            </div>
          </div>
          <?php $p++; endwhile; wp_reset_postdata(); ?>
        
        </div>
      </div>
    </div>
  </div>
  <!-- end DIS Portal --> 
  
  <!-- DIS Portal -->
  <div class="dis app">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class=" wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s"> School Resources for Students</h3>
        <div class="row">
            <?php
$args = array( 'post_type' => 'school_resources', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
$loop = new WP_Query( $args );
$p = 0;
while ( $loop->have_posts() ) : $loop->the_post(); global $product;
$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
$title=get_the_title();
$getcontent=get_the_content();

?>
            
          <div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="appresour">
              <h4><?php echo $title;?></h4>
              <span><i class="fa fa-book" aria-hidden="true"></i> </span>
              <p><?php echo $getcontent;?></p>
              <a href="<?php echo get_field('pdf_download'); ?>" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>
          </div>
          <?php $p++; endwhile; wp_reset_postdata(); ?>
          
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class II Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class III Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class IV Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class V Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class VI Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class VII Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          <!--<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">-->
          <!--  <div class="appresour">-->
          <!--    <h4>Class VIII Resources</h4>-->
          <!--    <span><i class="fa fa-book" aria-hidden="true"></i> </span>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>-->
          <!--    <a href="#" target="_blank">Resources Download <i class="fa fa-download" aria-hidden="true"></i> </a> </div>-->
          <!--</div>-->
          
          
        </div>
      </div>
    </div>
  </div>
  <!-- end DIS Portal --> 
  <!-- 
  <div class="admission parents">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-5 mr-2 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo get_template_directory_uri(); ?>/img/admission1.jpg"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-2 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admiss">
              <h3>Student login</h3>
               <?php //wp_login_form();

				
  global $current_user;
  get_currentuserinfo();
  $name= $current_user->first_name;
?>

			
			  
			  <?php
				if ( is_user_logged_in() ) {
					echo '<h3 class="text-center text-info">WelCome :'.$name.'</h3>';
				} else {
					wp_login_form();
				}
			?>
			  <form>
                <div class="form-group">
                  <input type="email" class="form-control fild6"  placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control fild6"  placeholder="Password">
                </div>
                <button type="submit" class="btn btn-default submit">LOGIN</button>
                <button type="submit" class="btn btn-default forgot">Forgot your password?</button>
              </form>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>-->
 
 
</main>
<?php get_footer(); ?>