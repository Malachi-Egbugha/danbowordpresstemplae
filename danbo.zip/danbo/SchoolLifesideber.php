<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<div class="col-lg-3">
  <div class="abright">
	<h4>School Life</h4>
	<ul>
	 	  <li class="<?php if(is_page('early-years')){ echo 'active';}?>"><a href="<?php echo home_url('/early-years/'); ?>">Early Years </a></li>
	  <li class="<?php if(is_page('primary')){ echo 'active';}?>"><a href="<?php echo home_url('/primary/'); ?>">Primary </a></li>
	  <li class="<?php if(is_page('secondary')){ echo 'active';}?>"><a href="<?php echo home_url('/secondary/'); ?>">Secondary</a> </li>
	  <li class="<?php if(is_page('sens')){ echo 'active';}?>"><a href="<?php echo home_url('/sens/'); ?>">SENS</a> </li>
	  <li class="<?php if(is_page('college')){ echo 'active';}?>"><a href="<?php echo home_url('/college/'); ?>">College</a> </li>
	  <li class="<?php if(is_page('danbo-boarding-school')){ echo 'active';}?>"><a href="<?php echo home_url('/danbo-boarding-school/'); ?>">Danbo Boarding school</a> </li>
	  <li class="<?php if(is_page('sixth-form')){ echo 'active';}?>"><a href="<?php echo home_url('/sixth-form/'); ?>">Sixth Form</a> </li>
	  
	</ul>
  </div>
</div>