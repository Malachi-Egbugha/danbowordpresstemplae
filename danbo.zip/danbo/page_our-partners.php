<?php
/**
 * Template Name: Our Partners
 */

get_header(); ?>
<main> 
  
  <!-- about -->
 
    
<?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			
			 <?php include('sidebar-about.php'); ?>
			
			
            <div class="col-lg-9">
              <div class="abarea">
                <h3>Our Partners</h3>
                <div class="row">
                 

				
				  
				 <?php
			$args = array( 'post_type' => 'our_partners', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$n = 0;
			while ( $loop->have_posts() ) : $loop->the_post(); 
			
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
           
			  <div class="col-lg-3 mb-4">
                    <div class="partn-img"><img src="<?php echo $imgurl;?>" alt=" "></div>
                  </div>
			 
			 <?php $p++; endwhile; wp_reset_postdata(); ?> 
				  
				  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php get_footer(); ?>
