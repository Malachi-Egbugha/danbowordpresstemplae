<?php
/**
 * Template Name: Portal
 */
session_start();
error_reporting(0);
include("includes/model.php");
$conn = new dbconn();
$tablename= "kadunaportal";
//kadunaportal
if(isset($_POST['submit']))
{
$username=$_POST["email"];
$pa=sha1($_POST["password"]);
//$pa=$_POST["password"];
$conn->login($pa, $username,   $tablename);
}
get_header();

?>

<!--Header-->
	<div id="header" class="header" style="background:url(<?php echo get_template_directory_uri(); ?>/img/login.jpg);background-position:center;
background-repeat: no-repeat;
background-size:cover;
color: #0000FF;">
	<div class="container">
	<div class="row" style="">
	<div class="col-lg-6 col-md-6" >
	<h1>STUDENT PORTAL</h1>
	</div>
	<!--------right side of login----------------->
	<div class="col-lg-6 col-md-6">
	<div class="card panel-primary">
  <div class="card-header">Login</div>
  <div class="card-body">
  <div class="col-sm-1">
  </div>
  <div class="col-sm-10">
  <div id="result" > 
  
  </div>
      <form class="form-horizontal"  action="<?php echo home_url('/portal/');?>" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Username</label>
    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter Email">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
 
  
  <input type="submit" name="submit" value="Login" class="btn btn-danger"/>
</form>
</div>
 <div class="col-sm-1">
  </div>
  </div>
</div>
	</div>
	</div>
	</div>
	</div>
	<!----------- end header---------->

<?php
get_footer(); 
?>