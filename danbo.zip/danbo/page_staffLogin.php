<?php
/*
Template Name: Staff Login
*/
get_header();
$msg='';
if(isset($_POST['submit']) && $_POST['submit']=='Login')
{

global $wpdb;
$username = $wpdb->escape($_REQUEST['username']);
$password = $wpdb->escape($_REQUEST['password']);

$creds = array();
$creds['user_login'] = $username;
$creds['user_password'] =$password;

$user = wp_signon( $creds, false );

if ( is_wp_error($user) ){
$err=$user->get_error_message();
$msg= "Username or password error try again!";
}
else{
//print_r($user);	

$user_meta=get_userdata($user->ID);

$user_roles=$user_meta->roles;
//print_r($user_roles);
if($user_roles[0]=='staff'){
$_SESSION['staff_id']=$user->ID;
	
echo "<script type='text/javascript'>window.location.href='".home_url('/staff-dashboard/')."'</script>";  

}

//header( 'Location:' . home_url().'blog');// this will redirect to Home Page	
//wp_redirect( 'https://example.com/some/page' );  					
//exit();
}

}

?>
 <main>

    <!-- about -->
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
	
<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
	
  	
	
 <!-- Parents login -->
  <div class="admission parents">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-5 mr-2 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo $image[0];?>"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-2 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
           <?php the_content();?> 
			<div class="admiss">
              <h3>Staff login</h3>
			  
             
			  <?php
				if ( $_SESSION['staff_id']!='' ) { ?>
   
				<a href="<?php echo home_url('/staff-dashboard/'); ?>"> Dashboard</a>
				<?php
				} else {
			  ?>
			    
			
               <p style="color:red"><?php echo $msg; ?></p>
			  <form method="post" action="">
                <div class="form-group">
                  <input type="email" class="form-control fild6"  name="username" placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control fild6" name="password" placeholder="Password">
                </div>
                <!--<button type="submit" class="btn btn-default submit">LOGIN</button>-->
				<input type="submit" name="submit" class="btn btn-default submit" value="<?php _e('Login'); ?>"/>
                <button type="submit" class="btn btn-default forgot">Forgot your password?</button>
              </form>
			  
				<?php } ?>
				
				<div id="register-link" class="text-right">
				<a href="<?php echo home_url('/staff-register/'); ?>" class="text-info">Create a account ? Sign up</a>
			</div>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Parents login --> 
 
<?php endwhile;  ?>	

  </main>

<?php get_footer(); ?>