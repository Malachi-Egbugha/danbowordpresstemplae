<?php
/**
 * Template Name: School Shop
 */

get_header(); ?>
<main> 
  
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
  <!-- School Shop -->
  <div class="wshop">
    <div class="container-fluid">
      <div class="maxw">
        <div id="filters" class="galleryFilterBtn button-group">
          <button class="btn is-checked" data-filter="*">All</button>
           <?php 
			$wcatTerms = get_terms('product_cat', array('hide_empty' => 0, 'number' => 6,'parent' =>0)); 
			foreach($wcatTerms as $wcatTerm) :
		  ?>
		  
		  <button class="btn" data-filter=".<?php echo $wcatTerm->slug; ?>"><?php echo $wcatTerm->name; ?></button>
		  
		   <?php endforeach ;  ?>
        </div>
        <div class="grid galleryGrid row no-gutters clearfix">
          
		  
		  <?php 
				$wcatTerms1 = get_terms('product_cat', array('hide_empty' => 0, 'number' => 6, 'order' =>'asc', 'parent' =>0));
				foreach($wcatTerms1 as $wcatTerm1) : 
			?>
			<?php
                    $args = array(
                        'post_type' => 'product',
                        'order' => 'ASC',
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'product_cat',
                                'field' => 'slug',
                                'terms' => $wcatTerm1->slug,
                            )
                        ),
                        'posts_per_page' => -1
                    );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post(); global $product;
                    $imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
                    $title=get_the_title($loop->post->ID);
					$getcontent=get_the_content();
                ?>
		  
		  
		  
		  <div class="col-lg-3 col-md-4 col-sm-6 col-12 grid-item <?php echo $wcatTerm1->slug; ?>">
            <div class="item">
              <div class="kid"> <a href="<?php the_permalink(); ?>" class="carts"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a>
                <div class="kidimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
                <h4><?php echo $title;?><span><?php echo $product->get_price_html();?></span></h4>
                <h5>Size: XS, S, L, XL</h5>
                <p><?php echo $getcontent;?></p>
              </div>
            </div>
          </div>
		  
		  
           <?php endwhile; wp_reset_postdata(); ?> 
			
			<?php endforeach;  ?>   
		  
        </div>
      </div>
    </div>
  </div>
  <!-- end School Shop --> 
  
</main>
<?php get_footer(); ?>