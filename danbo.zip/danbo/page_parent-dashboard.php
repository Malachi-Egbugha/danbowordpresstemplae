<?php
/**
 * Template Name: Parent Dashboard
 */

get_header();

if($_SESSION['parent_id']==""){
	echo "<script type='text/javascript'>window.location.href='". home_url('/parents-login/') ."'</script>";echo "<script type='text/javascript'>window.location.href='". home_url('/student-login/') ."'</script>";	
}
//$user = wp_get_current_user();
$user_id = $_SESSION['parent_id'];
//echo '<pre>';
//print_r($user);
//echo get_field('user_id', 'user_'.$user_id.'');

//$postid = $wpdb->get_results("SELECT user_id FROM $wpdb->postmeta WHERE (meta_key = 'user_id' AND meta_value = '".$user_id."')");
//$user_id = $postid[0]->user_id;
//print_r($user_id); 

if( isset($_POST['submit']) ){

    //update_field('firstname', $_POST['FirstName'], 'user_'.$user_id.'');
 
	update_user_meta( $user_id, 'firstname', $_POST['FirstName']);
	update_user_meta( $user_id, 'surname', $_POST['surname']);
	update_user_meta( $user_id, 'middle_name', $_POST['MiddleName']);
	update_user_meta( $user_id, 'nationality', $_POST['nationality']);
	update_user_meta( $user_id, 'gender', $_POST['gender']);
	update_user_meta( $user_id, 'last_grade_completed', $_POST['last_grade_completed']);
	update_user_meta( $user_id, 'grade_applied_for_in_danbo', $_POST['grade_applied_for_in_danbo']);
	update_user_meta( $user_id, 'childs_first_language', $_POST['childs_first_language']);
	update_user_meta( $user_id, 'name_of_last_school_attended', $_POST['name_of_last_school_attended']);
	
	update_user_meta( $user_id, 'difficulty', $_POST['difficulty']);
	update_user_meta( $user_id, 'address', $_POST['address']);
	update_user_meta( $user_id, 'date_of_birth', $_POST['date_of_birth']);
	//update_user_meta( $user_id, 'application_id', $_POST['application_id']);
	update_user_meta( $user_id, 'fathers_name', $_POST['fathers_name']);
	update_user_meta( $user_id, 'mothers_name', $_POST['mothers_name']);
	update_user_meta( $user_id, 'fathers_occupation', $_POST['fathers_occupation']);
	update_user_meta( $user_id, 'mothers_occupation', $_POST['mothers_occupation']);
	update_user_meta( $user_id, 'fathers_email', $_POST['fathers_email']);
	update_user_meta( $user_id, 'mothers_email', $_POST['mothers_email']);
	update_user_meta( $user_id, 'fatherss_phone_number', $_POST['fatherss_phone_number']);
	update_user_meta( $user_id, 'mothers_phone_number', $_POST['mothers_phone_number']);
	update_user_meta( $user_id, 'fathers_house_address', $_POST['fathers_house_address']);
	update_user_meta( $user_id, 'mothers_house_address', $_POST['mothers_house_address']);
	//Image Upload Query
	
	if (!function_exists('wp_generate_attachment_metadata'))
	{
    require_once(ABSPATH . "wp-admin" . '/includes/image.php');
    require_once(ABSPATH . "wp-admin" . '/includes/file.php');
    require_once(ABSPATH . "wp-admin" . '/includes/media.php');
	}
	
	
	$attachment_id = media_handle_upload( 'student_image', $user_id );
     
    if ( is_wp_error( $attachment_id ) ) {
       //There was an error uploading the image.
    } else {
      // echo "success"; 
	  $img= update_user_meta( $user_id, 'student_image', $attachment_id);
	  //var_dump($img);
    }

   
	$cpt_id = '<p class="success">Prefereneces Updated<p>';

}
      
	// $nameoflastschoolattended = the_author_meta( $user_id,'name_of_last_school_attended'); 
	// $firstname = get_post_meta( $user_id, 'firstname', true );
	// $surname = get_post_meta( $user_id, 'surname', true );
	// $middleName = get_post_meta( $user_id, 'middle_name', true );
	// $nationality = get_post_meta( $user_id, 'nationality', true );
	// $gender = get_post_meta( $user_id, 'gender', true );
	// $lastgradecompleted = get_post_meta( $user_id, 'last_grade_completed', true );
	// $gradeappliedforindanbo = get_post_meta( $user_id, 'grade_applied_for_in_danbo', true );
	// $language = get_post_meta( $user_id, 'childs_first_language', true );
	// $difficulty = get_post_meta( $user_id, 'difficulty', true );
	// $address = get_post_meta( $user_id, 'address', true );
	// $dateofbirth = get_post_meta( $user_id, 'date_of_birth', true );
	// $applicationid = get_post_meta( $user_id, 'application_id', true );
	// $fathersName = get_post_meta( $user_id, 'fathers_name', true );
	// $mothersname = get_post_meta( $user_id, 'mothers_name', true );
	// $fathersoccupation = get_post_meta( $user_id, 'fathers_occupation', true );
	// $mothersoccupation = get_post_meta( $user_id, 'mothers_occupation', true );
	// $fathers_email = get_post_meta( $user_id, 'fathers_email', true );
	// $mothers_email = get_post_meta( $user_id, 'mothers_email', true );
	// $fatherss_phone_number = get_post_meta( $user_id, 'fatherss_phone_number', true );
	// $mothers_phone_number = get_post_meta( $user_id, 'mothers_phone_number', true );
	// $fathers_house_address = get_post_meta( $user_id, 'fathers_house_address', true );
	// $mothers_house_address = get_post_meta( $user_id, 'mothers_house_address', true );

	// $imgurl = get_the_post_thumbnail_url($user_id, 'full' );

 ?>
<main> 
  
  <!-- about -->
 
    
<?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			
			 <?php include('sidebar-parent.php'); ?>
			
			
            <div class="col-lg-9">
              <div class="abarea">
              
			  
			   <p style="color:#11bb7c;"><?php echo $cpt_id;?></p>
			   <form name="form" action="" method="post" enctype="multipart/form-data">
				<input type="hidden" name="action" value="business_form">
                   <h3 class="text-center text-info">Student Fill Up</h3>
				 <div class="row">
                    
					
					
					<div class="col-lg-4">
                      <div class="form-group">
                        <label for="First Name"><span>*</span> First Name:</label>
                        <input value="<?php the_author_meta( 'firstname', $user_id); ?>" type="text" class="form-control fild10" name="FirstName" placeholder="First Name">
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Surname"><span>*</span> Surname:</label>
                        <input value="<?php the_author_meta( 'surname', $user_id); ?>" type="text" class="form-control fild10" name="surname" placeholder="Surname">
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Middle Name"> Middle Name:</label>
                        <input value="<?php the_author_meta( 'MiddleName', $user_id); ?>" type="text" class="form-control fild10" name="MiddleName" placeholder="Middle Name">
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Nationality"><span>*</span> Nationality:</label>
						<?php
							$all_meta_for_user = get_user_meta( $user_id );
							$nationality = $all_meta_for_user['nationality'][0];
							$gender = $all_meta_for_user['gender'][0];
							$lastgradecompleted = $all_meta_for_user['last_grade_completed'][0];
							$gradeappliedforindanbo = $all_meta_for_user['grade_applied_for_in_danbo'][0];
							$difficulty = $all_meta_for_user['difficulty'][0];
						?>
                        <select class="form-control fild10" name="nationality">
                          <option  value="">Select  an option </option>
                          <option <?php if($nationality == 'Afganistan'){ echo 'selected="selected"';} ?> value="Afganistan">Afghanistan</option>
                          <option <?php if($nationality == 'Albania'){ echo 'selected="selected"';} ?> value="Albania">Albania</option>
                          <option <?php if($nationality == 'Algeria'){ echo 'selected="selected"';} ?> value="Algeria">Algeria</option>
                          <option <?php if($nationality == 'American Samoa'){ echo 'selected="selected"';} ?> value="American Samoa">American Samoa</option>
                          <option <?php if($nationality == 'Andorra'){ echo 'selected="selected"';} ?> value="Andorra">Andorra</option>
                          <option <?php if($nationality == 'Angola'){ echo 'selected="selected"';} ?> value="Angola">Angola</option>
                          <option <?php if($nationality == 'Anguilla'){ echo 'selected="selected"';} ?> value="Anguilla">Anguilla</option>
                          <option <?php if($nationality == 'Antigua &amp; Barbuda'){ echo 'selected="selected"';} ?> value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
                          <option <?php if($nationality == 'Argentina'){ echo 'selected="selected"';} ?> value="Argentina">Argentina</option>
                          <option <?php if($nationality == 'Armenia'){ echo 'selected="selected"';} ?> value="Armenia">Armenia</option>
                          <option <?php if($nationality == 'Aruba'){ echo 'selected="selected"';} ?> value="Aruba">Aruba</option>
                          <option <?php if($nationality == 'Australia'){ echo 'selected="selected"';} ?> value="Australia">Australia</option>
                          <option <?php if($nationality == 'Austria'){ echo 'selected="selected"';} ?> value="Austria">Austria</option>
                          <option <?php if($nationality == 'Azerbaijan'){ echo 'selected="selected"';} ?> value="Azerbaijan">Azerbaijan</option>
                          <option <?php if($nationality == 'Bahamas'){ echo 'selected="selected"';} ?> value="Bahamas">Bahamas</option>
                          <option <?php if($nationality == 'Bahrain'){ echo 'selected="selected"';} ?> value="Bahrain">Bahrain</option>
                          <option <?php if($nationality == 'Bangladesh'){ echo 'selected="selected"';} ?> value="Bangladesh">Bangladesh</option>
                          <option <?php if($nationality == 'Barbados'){ echo 'selected="selected"';} ?> value="Barbados">Barbados</option>
                          <option <?php if($nationality == 'Belarus'){ echo 'selected="selected"';} ?> value="Belarus">Belarus</option>
                          <option <?php if($nationality == 'Belgium'){ echo 'selected="selected"';} ?> value="Belgium">Belgium</option>
                          <option <?php if($nationality == 'Belize'){ echo 'selected="selected"';} ?> value="Belize">Belize</option>
                          <option <?php if($nationality == 'Benin'){ echo 'selected="selected"';} ?> value="Benin">Benin</option>
                          <option <?php if($nationality == 'Bermuda'){ echo 'selected="selected"';} ?> value="Bermuda">Bermuda</option>
                          <option <?php if($nationality == 'Bhutan'){ echo 'selected="selected"';} ?> value="Bhutan">Bhutan</option>
                          <option <?php if($nationality == 'Bolivia'){ echo 'selected="selected"';} ?> value="Bolivia">Bolivia</option>
                          <option <?php if($nationality == 'Bonaire'){ echo 'selected="selected"';} ?> value="Bonaire">Bonaire</option>
                          <option <?php if($nationality == 'Bosnia &amp; Herzegovina'){ echo 'selected="selected"';} ?> value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
                          <option <?php if($nationality == 'Botswana'){ echo 'selected="selected"';} ?> value="Botswana">Botswana</option>
                          <option <?php if($nationality == 'Brazil'){ echo 'selected="selected"';} ?> value="Brazil">Brazil</option>
                          <option <?php if($nationality == 'British Indian Ocean Ter'){ echo 'selected="selected"';} ?> value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                          <option <?php if($nationality == 'Brunei'){ echo 'selected="selected"';} ?> value="Brunei">Brunei</option>
                          <option <?php if($nationality == 'Bulgaria'){ echo 'selected="selected"';} ?> value="Bulgaria">Bulgaria</option>
                          <option <?php if($nationality == 'Burkina Faso'){ echo 'selected="selected"';} ?> value="Burkina Faso">Burkina Faso</option>
                          <option <?php if($nationality == 'Burundi'){ echo 'selected="selected"';} ?> value="Burundi">Burundi</option>
                          <option <?php if($nationality == 'Cambodia'){ echo 'selected="selected"';} ?> value="Cambodia">Cambodia</option>
                          <option <?php if($nationality == 'Cameroon'){ echo 'selected="selected"';} ?> value="Cameroon">Cameroon</option>
                          <option <?php if($nationality == 'Canada'){ echo 'selected="selected"';} ?> value="Canada">Canada</option>
                          <option <?php if($nationality == 'Canary Islands'){ echo 'selected="selected"';} ?> value="Canary Islands">Canary Islands</option>
                          <option <?php if($nationality == 'Cape Verde'){ echo 'selected="selected"';} ?> value="Cape Verde">Cape Verde</option>
                          <option <?php if($nationality == 'Cayman Islands'){ echo 'selected="selected"';} ?> value="Cayman Islands">Cayman Islands</option>
                          <option <?php if($nationality == 'Central African Republic'){ echo 'selected="selected"';} ?> value="Central African Republic">Central African Republic</option>
                          <option <?php if($nationality == 'Chad'){ echo 'selected="selected"';} ?> value="Chad">Chad</option>
                          <option <?php if($nationality == 'Channel Islands'){ echo 'selected="selected"';} ?> value="Channel Islands">Channel Islands</option>
                          <option <?php if($nationality == 'Chile'){ echo 'selected="selected"';} ?> value="Chile">Chile</option>
                          <option <?php if($nationality == 'China'){ echo 'selected="selected"';} ?> value="China">China</option>
                          <option <?php if($nationality == 'Christmas Island'){ echo 'selected="selected"';} ?> value="Christmas Island">Christmas Island</option>
                          <option <?php if($nationality == 'Cocos Island'){ echo 'selected="selected"';} ?> value="Cocos Island">Cocos Island</option>
                          <option <?php if($nationality == 'Colombia'){ echo 'selected="selected"';} ?> value="Colombia">Colombia</option>
                          <option <?php if($nationality == 'Comoros'){ echo 'selected="selected"';} ?> value="Comoros">Comoros</option>
                          <option <?php if($nationality == 'Congo'){ echo 'selected="selected"';} ?> value="Congo">Congo</option>
                          <option <?php if($nationality == 'Cook Islands'){ echo 'selected="selected"';} ?> value="Cook Islands">Cook Islands</option>
                          <option <?php if($nationality == 'Costa Rica'){ echo 'selected="selected"';} ?> value="Costa Rica">Costa Rica</option>
                          <option <?php if($nationality == 'Cote DIvoire'){ echo 'selected="selected"';} ?> value="Cote DIvoire">Cote D'Ivoire</option>
                          <option <?php if($nationality == 'Croatia'){ echo 'selected="selected"';} ?> value="Croatia">Croatia</option>
                          <option <?php if($nationality == 'Cuba'){ echo 'selected="selected"';} ?> value="Cuba">Cuba</option>
                          <option <?php if($nationality == 'Curaco'){ echo 'selected="selected"';} ?> value="Curaco">Curacao</option>
                          <option <?php if($nationality == 'Cyprus'){ echo 'selected="selected"';} ?> value="Cyprus">Cyprus</option>
                          <option <?php if($nationality == 'Czech Republic'){ echo 'selected="selected"';} ?> value="Czech Republic">Czech Republic</option>
                          <option <?php if($nationality == 'Denmark'){ echo 'selected="selected"';} ?> value="Denmark">Denmark</option>
                          <option <?php if($nationality == 'Djibouti'){ echo 'selected="selected"';} ?> value="Djibouti">Djibouti</option>
                          <option <?php if($nationality == 'Dominica'){ echo 'selected="selected"';} ?> value="Dominica">Dominica</option>
                          <option <?php if($nationality == 'Dominican Republic'){ echo 'selected="selected"';} ?> value="Dominican Republic">Dominican Republic</option>
                          <option <?php if($nationality == 'East Timor'){ echo 'selected="selected"';} ?> value="East Timor">East Timor</option>
                          <option <?php if($nationality == 'Ecuador'){ echo 'selected="selected"';} ?> value="Ecuador">Ecuador</option>
                          <option <?php if($nationality == 'Egypt'){ echo 'selected="selected"';} ?> value="Egypt">Egypt</option>
                          <option <?php if($nationality == 'El Salvador'){ echo 'selected="selected"';} ?> value="El Salvador">El Salvador</option>
                          <option <?php if($nationality == 'Equatorial Guinea'){ echo 'selected="selected"';} ?> value="Equatorial Guinea">Equatorial Guinea</option>
                          <option <?php if($nationality == 'Eritrea'){ echo 'selected="selected"';} ?> value="Eritrea">Eritrea</option>
                          <option <?php if($nationality == 'Estonia'){ echo 'selected="selected"';} ?> value="Estonia">Estonia</option>
                          <option <?php if($nationality == 'Ethiopia'){ echo 'selected="selected"';} ?> value="Ethiopia">Ethiopia</option>
                          <option <?php if($nationality == 'Falkland Islands'){ echo 'selected="selected"';} ?> value="Falkland Islands">Falkland Islands</option>
                          <option <?php if($nationality == 'Faroe Islands'){ echo 'selected="selected"';} ?> value="Faroe Islands">Faroe Islands</option>
                          <option <?php if($nationality == 'Fiji'){ echo 'selected="selected"';} ?> value="Fiji">Fiji</option>
                          <option <?php if($nationality == 'Finland'){ echo 'selected="selected"';} ?> value="Finland">Finland</option>
                          <option <?php if($nationality == 'France'){ echo 'selected="selected"';} ?> value="France">France</option>
                          <option <?php if($nationality == 'French Guiana'){ echo 'selected="selected"';} ?> value="French Guiana">French Guiana</option>
                          <option <?php if($nationality == 'French Polynesia'){ echo 'selected="selected"';} ?> value="French Polynesia">French Polynesia</option>
                          <option <?php if($nationality == 'French Southern Ter'){ echo 'selected="selected"';} ?> value="French Southern Ter">French Southern Ter</option>
                          <option <?php if($nationality == 'Gabon'){ echo 'selected="selected"';} ?> value="Gabon">Gabon</option>
                          <option <?php if($nationality == 'Gambia'){ echo 'selected="selected"';} ?> value="Gambia">Gambia</option>
                          <option <?php if($nationality == 'Georgia'){ echo 'selected="selected"';} ?> value="Georgia">Georgia</option>
                          <option <?php if($nationality == 'Germany'){ echo 'selected="selected"';} ?> value="Germany">Germany</option>
                          <option <?php if($nationality == 'Ghana'){ echo 'selected="selected"';} ?> value="Ghana">Ghana</option>
                          <option <?php if($nationality == 'Gibraltar'){ echo 'selected="selected"';} ?> value="Gibraltar">Gibraltar</option>
                          <option <?php if($nationality == 'Great Britain'){ echo 'selected="selected"';} ?> value="Great Britain">Great Britain</option>
                          <option <?php if($nationality == 'Greece'){ echo 'selected="selected"';} ?> value="Greece">Greece</option>
                          <option <?php if($nationality == 'Greenland'){ echo 'selected="selected"';} ?> value="Greenland">Greenland</option>
                          <option <?php if($nationality == 'Grenada'){ echo 'selected="selected"';} ?> value="Grenada">Grenada</option>
                          <option <?php if($nationality == 'Guadeloupe'){ echo 'selected="selected"';} ?> value="Guadeloupe">Guadeloupe</option>
                          <option <?php if($nationality == 'Guam'){ echo 'selected="selected"';} ?> value="Guam">Guam</option>
                          <option <?php if($nationality == 'Guatemala'){ echo 'selected="selected"';} ?> value="Guatemala">Guatemala</option>
                          <option <?php if($nationality == 'Guinea'){ echo 'selected="selected"';} ?> value="Guinea">Guinea</option>
                          <option <?php if($nationality == 'Guyana'){ echo 'selected="selected"';} ?> value="Guyana">Guyana</option>
                          <option <?php if($nationality == 'Haiti'){ echo 'selected="selected"';} ?> value="Haiti">Haiti</option>
                          <option <?php if($nationality == 'Hawaii'){ echo 'selected="selected"';} ?> value="Hawaii">Hawaii</option>
                          <option <?php if($nationality == 'Honduras'){ echo 'selected="selected"';} ?> value="Honduras">Honduras</option>
                          <option <?php if($nationality == 'Hong Kong'){ echo 'selected="selected"';} ?> value="Hong Kong">Hong Kong</option>
                          <option <?php if($nationality == 'Hungary'){ echo 'selected="selected"';} ?> value="Hungary">Hungary</option>
                          <option <?php if($nationality == 'Iceland'){ echo 'selected="selected"';} ?> value="Iceland">Iceland</option>
                          <option <?php if($nationality == 'India'){ echo 'selected="selected"';} ?> value="India">India</option>
                          <option <?php if($nationality == 'Indonesia'){ echo 'selected="selected"';} ?> value="Indonesia">Indonesia</option>
                          <option <?php if($nationality == 'Iran'){ echo 'selected="selected"';} ?> value="Iran">Iran</option>
                          <option <?php if($nationality == 'Iraq'){ echo 'selected="selected"';} ?> value="Iraq">Iraq</option>
                          <option <?php if($nationality == 'Ireland'){ echo 'selected="selected"';} ?> value="Ireland">Ireland</option>
                          <option <?php if($nationality == 'Isle of Man'){ echo 'selected="selected"';} ?> value="Isle of Man">Isle of Man</option>
                          <option <?php if($nationality == 'Israel'){ echo 'selected="selected"';} ?> value="Israel">Israel</option>
                          <option <?php if($nationality == 'Italy'){ echo 'selected="selected"';} ?> value="Italy">Italy</option>
                          <option <?php if($nationality == 'Jamaica'){ echo 'selected="selected"';} ?> value="Jamaica">Jamaica</option>
                          <option <?php if($nationality == 'Japan'){ echo 'selected="selected"';} ?> value="Japan">Japan</option>
                          <option <?php if($nationality == 'Jordan'){ echo 'selected="selected"';} ?> value="Jordan">Jordan</option>
                          <option <?php if($nationality == 'Kazakhstan'){ echo 'selected="selected"';} ?> value="Kazakhstan">Kazakhstan</option>
                          <option <?php if($nationality == 'Kenya'){ echo 'selected="selected"';} ?> value="Kenya">Kenya</option>
                          <option <?php if($nationality == 'Kiribati'){ echo 'selected="selected"';} ?> value="Kiribati">Kiribati</option>
                          <option <?php if($nationality == 'Korea North'){ echo 'selected="selected"';} ?> value="Korea North">Korea North</option>
                          <option <?php if($nationality == 'Korea Sout'){ echo 'selected="selected"';} ?> value="Korea Sout">Korea South</option>
                          <option <?php if($nationality == 'Kuwait'){ echo 'selected="selected"';} ?> value="Kuwait">Kuwait</option>
                          <option <?php if($nationality == 'Kyrgyzstan'){ echo 'selected="selected"';} ?> value="Kyrgyzstan">Kyrgyzstan</option>
                          <option <?php if($nationality == 'Laos'){ echo 'selected="selected"';} ?> value="Laos">Laos</option>
                          <option <?php if($nationality == 'Latvia'){ echo 'selected="selected"';} ?> value="Latvia">Latvia</option>
                          <option <?php if($nationality == 'Lebanon'){ echo 'selected="selected"';} ?> value="Lebanon">Lebanon</option>
                          <option <?php if($nationality == 'Lesotho'){ echo 'selected="selected"';} ?> value="Lesotho">Lesotho</option>
                          <option <?php if($nationality == 'Liberia'){ echo 'selected="selected"';} ?> value="Liberia">Liberia</option>
                          <option <?php if($nationality == 'Libya'){ echo 'selected="selected"';} ?> value="Libya">Libya</option>
                          <option <?php if($nationality == 'Liechtenstein'){ echo 'selected="selected"';} ?> value="Liechtenstein">Liechtenstein</option>
                          <option <?php if($nationality == 'Lithuania'){ echo 'selected="selected"';} ?> value="Lithuania">Lithuania</option>
                          <option <?php if($nationality == 'Luxembourg'){ echo 'selected="selected"';} ?> value="Luxembourg">Luxembourg</option>
                          <option <?php if($nationality == 'Macau'){ echo 'selected="selected"';} ?> value="Macau">Macau</option>
                          <option <?php if($nationality == 'Macedonia'){ echo 'selected="selected"';} ?> value="Macedonia">Macedonia</option>
                          <option <?php if($nationality == 'Madagascar'){ echo 'selected="selected"';} ?> value="Madagascar">Madagascar</option>
                          <option <?php if($nationality == 'Malaysia'){ echo 'selected="selected"';} ?> value="Malaysia">Malaysia</option>
                          <option <?php if($nationality == 'Malawi'){ echo 'selected="selected"';} ?> value="Malawi">Malawi</option>
                          <option <?php if($nationality == 'Maldives'){ echo 'selected="selected"';} ?> value="Maldives">Maldives</option>
                          <option <?php if($nationality == 'Mali'){ echo 'selected="selected"';} ?> value="Mali">Mali</option>
                          <option <?php if($nationality == 'Malta'){ echo 'selected="selected"';} ?> value="Malta">Malta</option>
                          <option <?php if($nationality == 'Marshall Islands'){ echo 'selected="selected"';} ?> value="Marshall Islands">Marshall Islands</option>
                          <option <?php if($nationality == 'Martinique'){ echo 'selected="selected"';} ?> value="Martinique">Martinique</option>
                          <option <?php if($nationality == 'Mauritania'){ echo 'selected="selected"';} ?> value="Mauritania">Mauritania</option>
                          <option <?php if($nationality == 'Mauritius'){ echo 'selected="selected"';} ?> value="Mauritius">Mauritius</option>
                          <option <?php if($nationality == 'Mayotte'){ echo 'selected="selected"';} ?> value="Mayotte">Mayotte</option>
                          <option <?php if($nationality == 'Mexico'){ echo 'selected="selected"';} ?> value="Mexico">Mexico</option>
                          <option <?php if($nationality == 'Midway Islands'){ echo 'selected="selected"';} ?> value="Midway Islands">Midway Islands</option>
                          <option <?php if($nationality == 'Moldova'){ echo 'selected="selected"';} ?> value="Moldova">Moldova</option>
                          <option <?php if($nationality == 'Monaco'){ echo 'selected="selected"';} ?> value="Monaco">Monaco</option>
                          <option <?php if($nationality == 'Mongolia'){ echo 'selected="selected"';} ?> value="Mongolia">Mongolia</option>
                          <option <?php if($nationality == 'Montserrat'){ echo 'selected="selected"';} ?> value="Montserrat">Montserrat</option>
                          <option <?php if($nationality == 'Morocco'){ echo 'selected="selected"';} ?> value="Morocco">Morocco</option>
                          <option <?php if($nationality == 'Mozambique'){ echo 'selected="selected"';} ?> value="Mozambique">Mozambique</option>
                          <option <?php if($nationality == 'Myanmar'){ echo 'selected="selected"';} ?> value="Myanmar">Myanmar</option>
                          <option <?php if($nationality == 'Nambia'){ echo 'selected="selected"';} ?> value="Nambia">Nambia</option>
                          <option <?php if($nationality == 'Nauru'){ echo 'selected="selected"';} ?> value="Nauru">Nauru</option>
                          <option <?php if($nationality == 'Nepal'){ echo 'selected="selected"';} ?> value="Nepal">Nepal</option>
                          <option <?php if($nationality == 'Netherland Antilles'){ echo 'selected="selected"';} ?> value="Netherland Antilles">Netherland Antilles</option>
                          <option <?php if($nationality == 'Netherlands'){ echo 'selected="selected"';} ?> value="Netherlands">Netherlands (Holland, Europe)</option>
                          <option <?php if($nationality == 'Nevis'){ echo 'selected="selected"';} ?> value="Nevis">Nevis</option>
                          <option <?php if($nationality == 'New Caledonia'){ echo 'selected="selected"';} ?> value="New Caledonia">New Caledonia</option>
                          <option <?php if($nationality == 'New Zealand'){ echo 'selected="selected"';} ?> value="New Zealand">New Zealand</option>
                          <option <?php if($nationality == 'Nicaragua'){ echo 'selected="selected"';} ?> value="Nicaragua">Nicaragua</option>
                          <option <?php if($nationality == 'Niger'){ echo 'selected="selected"';} ?> value="Niger">Niger</option>
                          <option <?php if($nationality == 'Nigeria'){ echo 'selected="selected"';} ?> value="Nigeria">Nigeria</option>
                          <option <?php if($nationality == 'Niue'){ echo 'selected="selected"';} ?> value="Niue">Niue</option>
                          <option <?php if($nationality == 'Norfolk Island'){ echo 'selected="selected"';} ?> value="Norfolk Island">Norfolk Island</option>
                          <option <?php if($nationality == 'Norway'){ echo 'selected="selected"';} ?> value="Norway">Norway</option>
                          <option <?php if($nationality == 'Oman'){ echo 'selected="selected"';} ?> value="Oman">Oman</option>
                          <option <?php if($nationality == 'Pakistan'){ echo 'selected="selected"';} ?> value="Pakistan">Pakistan</option>
                          <option <?php if($nationality == 'Palau Island'){ echo 'selected="selected"';} ?> value="Palau Island">Palau Island</option>
                          <option <?php if($nationality == 'Palestine'){ echo 'selected="selected"';} ?>value="Palestine">Palestine</option>
                          <option <?php if($nationality == 'Panama'){ echo 'selected="selected"';} ?> value="Panama">Panama</option>
                          <option <?php if($nationality == 'Papua New Guinea'){ echo 'selected="selected"';} ?> value="Papua New Guinea">Papua New Guinea</option>
                          <option <?php if($nationality == 'Paraguay'){ echo 'selected="selected"';} ?> value="Paraguay">Paraguay</option>
                          <option <?php if($nationality == 'Peru'){ echo 'selected="selected"';} ?> value="Peru">Peru</option>
                          <option <?php if($nationality == 'Phillipines'){ echo 'selected="selected"';} ?> value="Phillipines">Philippines</option>
                          <option <?php if($nationality == 'Pitcairn Island'){ echo 'selected="selected"';} ?> value="Pitcairn Island">Pitcairn Island</option>
                          <option <?php if($nationality == 'Poland'){ echo 'selected="selected"';} ?> value="Poland">Poland</option>
                          <option <?php if($nationality == 'Portugal'){ echo 'selected="selected"';} ?> value="Portugal">Portugal</option>
                          <option <?php if($nationality == 'Puerto Rico'){ echo 'selected="selected"';} ?> value="Puerto Rico">Puerto Rico</option>
                          <option <?php if($nationality == 'Qatar'){ echo 'selected="selected"';} ?> value="Qatar">Qatar</option>
                          <option <?php if($nationality == 'Republic of Montenegro'){ echo 'selected="selected"';} ?> value="Republic of Montenegro">Republic of Montenegro</option>
                          <option <?php if($nationality == 'Republic of Serbia'){ echo 'selected="selected"';} ?> value="Republic of Serbia">Republic of Serbia</option>
                          <option <?php if($nationality == 'Reunion'){ echo 'selected="selected"';} ?> value="Reunion">Reunion</option>
                          <option <?php if($nationality == 'Romania'){ echo 'selected="selected"';} ?> value="Romania">Romania</option>
                          <option <?php if($nationality == 'Russia'){ echo 'selected="selected"';} ?> value="Russia">Russia</option>
                          <option <?php if($nationality == 'Rwanda'){ echo 'selected="selected"';} ?> value="Rwanda">Rwanda</option>
                          <option <?php if($nationality == 'St Barthelemy'){ echo 'selected="selected"';} ?> value="St Barthelemy">St Barthelemy</option>
                          <option <?php if($nationality == 'St Eustatius'){ echo 'selected="selected"';} ?> value="St Eustatius">St Eustatius</option>
                          <option <?php if($nationality == 'St Helena'){ echo 'selected="selected"';} ?> value="St Helena">St Helena</option>
                          <option <?php if($nationality == 'St Kitts-Nevis'){ echo 'selected="selected"';} ?> value="St Kitts-Nevis">St Kitts-Nevis</option>
                          <option <?php if($nationality == 'St Lucia'){ echo 'selected="selected"';} ?> value="St Lucia">St Lucia</option>
                          <option <?php if($nationality == 'St Maarten'){ echo 'selected="selected"';} ?> value="St Maarten">St Maarten</option>
                          <option <?php if($nationality == 'St Pierre &amp; Miquelon'){ echo 'selected="selected"';} ?> value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
                          <option <?php if($nationality == 'St Vincent &amp; Grenadines'){ echo 'selected="selected"';} ?> value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
                          <option <?php if($nationality == 'Saipan'){ echo 'selected="selected"';} ?> value="Saipan">Saipan</option>
                          <option <?php if($nationality == 'Samoa'){ echo 'selected="selected"';} ?> value="Samoa">Samoa</option>
                          <option <?php if($nationality == 'Samoa American'){ echo 'selected="selected"';} ?> value="Samoa American">Samoa American</option>
                          <option <?php if($nationality == 'San Marino'){ echo 'selected="selected"';} ?> value="San Marino">San Marino</option>
                          <option <?php if($nationality == 'Sao Tome &amp; Principe'){ echo 'selected="selected"';} ?> value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
                          <option <?php if($nationality == 'Saudi Arabia'){ echo 'selected="selected"';} ?> value="Saudi Arabia">Saudi Arabia</option>
                          <option <?php if($nationality == 'Senegal'){ echo 'selected="selected"';} ?> value="Senegal">Senegal</option>
                          <option <?php if($nationality == 'Serbia'){ echo 'selected="selected"';} ?> value="Serbia">Serbia</option>
                          <option <?php if($nationality == 'Seychelles'){ echo 'selected="selected"';} ?> value="Seychelles">Seychelles</option>
                          <option <?php if($nationality == 'Sierra Leone'){ echo 'selected="selected"';} ?> value="Sierra Leone">Sierra Leone</option>
                          <option <?php if($nationality == 'Singapore'){ echo 'selected="selected"';} ?> value="Singapore">Singapore</option>
                          <option <?php if($nationality == 'Slovakia'){ echo 'selected="selected"';} ?> value="Slovakia">Slovakia</option>
                          <option <?php if($nationality == 'Slovenia'){ echo 'selected="selected"';} ?> value="Slovenia">Slovenia</option>
                          <option <?php if($nationality == 'Solomon Islands'){ echo 'selected="selected"';} ?> value="Solomon Islands">Solomon Islands</option>
                          <option <?php if($nationality == 'Somalia'){ echo 'selected="selected"';} ?> value="Somalia">Somalia</option>
                          <option <?php if($nationality == 'South Africa'){ echo 'selected="selected"';} ?> value="South Africa">South Africa</option>
                          <option <?php if($nationality == 'Spain'){ echo 'selected="selected"';} ?> value="Spain">Spain</option>
                          <option <?php if($nationality == 'Sri Lanka'){ echo 'selected="selected"';} ?> value="Sri Lanka">Sri Lanka</option>
                          <option <?php if($nationality == 'Sudan'){ echo 'selected="selected"';} ?> value="Sudan">Sudan</option>
                          <option <?php if($nationality == 'Suriname'){ echo 'selected="selected"';} ?> value="Suriname">Suriname</option>
                          <option <?php if($nationality == 'Swaziland'){ echo 'selected="selected"';} ?> value="Swaziland">Swaziland</option>
                          <option <?php if($nationality == 'Sweden'){ echo 'selected="selected"';} ?> value="Sweden">Sweden</option>
                          <option <?php if($nationality == 'Switzerland'){ echo 'selected="selected"';} ?>value="Switzerland">Switzerland</option>
                          <option <?php if($nationality == 'Syria'){ echo 'selected="selected"';} ?> value="Syria">Syria</option>
                          <option <?php if($nationality == 'Tahiti'){ echo 'selected="selected"';} ?> value="Tahiti">Tahiti</option>
                          <option <?php if($nationality == 'Taiwan'){ echo 'selected="selected"';} ?> value="Taiwan">Taiwan</option>
                          <option <?php if($nationality == 'Tajikistan'){ echo 'selected="selected"';} ?> value="Tajikistan">Tajikistan</option>
                          <option <?php if($nationality == 'Tanzania'){ echo 'selected="selected"';} ?> value="Tanzania">Tanzania</option>
                          <option <?php if($nationality == 'Thailand'){ echo 'selected="selected"';} ?> value="Thailand">Thailand</option>
                          <option <?php if($nationality == 'Togo'){ echo 'selected="selected"';} ?> value="Togo">Togo</option>
                          <option <?php if($nationality == 'Tokelau'){ echo 'selected="selected"';} ?> value="Tokelau">Tokelau</option>
                          <option <?php if($nationality == 'Tonga'){ echo 'selected="selected"';} ?> value="Tonga">Tonga</option>
                          <option <?php if($nationality == 'Trinidad &amp; Tobago'){ echo 'selected="selected"';} ?> value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
                          <option <?php if($nationality == 'Tunisia'){ echo 'selected="selected"';} ?> value="Tunisia">Tunisia</option>
                          <option <?php if($nationality == 'Turkey'){ echo 'selected="selected"';} ?> value="Turkey">Turkey</option>
                          <option <?php if($nationality == 'Turkmenistan'){ echo 'selected="selected"';} ?> value="Turkmenistan">Turkmenistan</option>
                          <option <?php if($nationality == 'Turks &amp; Caicos Is'){ echo 'selected="selected"';} ?> value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
                          <option <?php if($nationality == 'Tuvalu'){ echo 'selected="selected"';} ?> value="Tuvalu">Tuvalu</option>
                          <option <?php if($nationality == 'Uganda'){ echo 'selected="selected"';} ?> value="Uganda">Uganda</option>
                          <option <?php if($nationality == 'Ukraine'){ echo 'selected="selected"';} ?> value="Ukraine">Ukraine</option>
                          <option <?php if($nationality == 'United Arab Erimates'){ echo 'selected="selected"';} ?> value="United Arab Erimates">United Arab Emirates</option>
                          <option <?php if($nationality == 'United Kingdom'){ echo 'selected="selected"';} ?> value="United Kingdom">United Kingdom</option>
                          <option <?php if($nationality == 'United States of America'){ echo 'selected="selected"';} ?> value="United States of America">United States of America</option>
                          <option <?php if($nationality == 'Uraguay'){ echo 'selected="selected"';} ?> value="Uraguay">Uruguay</option>
                          <option <?php if($nationality == 'Uzbekistan'){ echo 'selected="selected"';} ?> value="Uzbekistan">Uzbekistan</option>
                          <option <?php if($nationality == 'Vanuatu'){ echo 'selected="selected"';} ?> value="Vanuatu">Vanuatu</option>
                          <option <?php if($nationality == 'Vatican City State'){ echo 'selected="selected"';} ?> value="Vatican City State">Vatican City State</option>
                          <option <?php if($nationality == 'Venezuela'){ echo 'selected="selected"';} ?> value="Venezuela">Venezuela</option>
                          <option <?php if($nationality == 'Vietnam'){ echo 'selected="selected"';} ?> value="Vietnam">Vietnam</option>
                          <option <?php if($nationality == 'Virgin Islands (Brit)'){ echo 'selected="selected"';} ?> value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                          <option <?php if($nationality == 'Virgin Islands (USA)'){ echo 'selected="selected"';} ?> value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                          <option <?php if($nationality == 'Wake Island'){ echo 'selected="selected"';} ?> value="Wake Island">Wake Island</option>
                          <option <?php if($nationality == 'Wallis &amp; Futana Is'){ echo 'selected="selected"';} ?> value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
                          <option <?php if($nationality == 'Yemen'){ echo 'selected="selected"';} ?> value="Yemen">Yemen</option>
                          <option <?php if($nationality == 'Zaire'){ echo 'selected="selected"';} ?> value="Zaire">Zaire</option>
                          <option <?php if($nationality == 'Zambia'){ echo 'selected="selected"';} ?> value="Zambia">Zambia</option>
                          <option <?php if($nationality == 'Zimbabwe'){ echo 'selected="selected"';} ?> value="Zimbabwe">Zimbabwe</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Gender"><span>*</span> Gender:</label>
                        <select class="form-control fild10" name="gender">
                          <option value="">Select  an option </option>
                          <option <?php if($gender == 'Male'){ echo 'selected="selected"';} ?> value="Male">Male</option>
                          <option <?php if($gender == 'Female'){ echo 'selected="selected"';} ?> value="Female">Female</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Last Grade Completed"><span>*</span> Last Grade Completed:</label>
                        <select class="form-control fild10" name="last_grade_completed">
                          <option value="">Select  an option </option>
                          <option <?php if($lastgradecompleted == 'playgroup'){ echo 'selected="selected"';} ?> value="playgroup" class="option">Playgroup</option>
                          <option <?php if($lastgradecompleted == 'nursery1/preschool'){ echo 'selected="selected"';} ?> value="nursery1/preschool" class="option">Nursery1/Preschool</option>
                          <option <?php if($lastgradecompleted == 'nursery2/pre-kindergarten'){ echo 'selected="selected"';} ?> value="nursery2/pre-kindergarten" class="option">Nursery1/Pre-kindergarten</option>
                          <option <?php if($lastgradecompleted == 'class1/kindergarten'){ echo 'selected="selected"';} ?> value="class1/kindergarten" class="option">Class1/KindergartenSvg</option>
                          <option <?php if($lastgradecompleted == 'class2/grade1'){ echo 'selected="selected"';} ?> value="class2/grade1" class="option">Class2/Grade1</option>
                          <option <?php if($lastgradecompleted == 'class3/grade2'){ echo 'selected="selected"';} ?> value="class3/grade2" class="option">Class3/Grade2</option>
                          <option <?php if($lastgradecompleted == 'class4/grade3'){ echo 'selected="selected"';} ?> value="class4/grade3" class="option">Class4/Grade3</option>
                          <option <?php if($lastgradecompleted == 'class5/grade4'){ echo 'selected="selected"';} ?> value="class5/grade4" class="option">Class5/Grade4</option>
                          <option <?php if($lastgradecompleted == 'class6/grade5'){ echo 'selected="selected"';} ?> value="class6/grade5" class="option">Class6/Grade5</option>
                          <option <?php if($lastgradecompleted == 'jss1/grade6'){ echo 'selected="selected"';} ?> value="jss1/grade6" class="option">JSS1/Grade6</option>
                          <option <?php if($lastgradecompleted == 'jss2/grade7'){ echo 'selected="selected"';} ?> value="jss2/grade7" class="option">JSS2/Grade7</option>
                          <option <?php if($lastgradecompleted == 'jss3/grade8'){ echo 'selected="selected"';} ?> value="jss3/grade8" class="option">JSS3/Grade8</option>
                          <option <?php if($lastgradecompleted == 'sss1/grade9'){ echo 'selected="selected"';} ?> value="sss1/grade9" class="option">SSS1/Grade9</option>
                          <option <?php if($lastgradecompleted == 'sss2/grade10'){ echo 'selected="selected"';} ?> value="sss2/grade10" class="option">SSS2/Grade10</option>
                          <option <?php if($lastgradecompleted == 'sss3/grade11'){ echo 'selected="selected"';} ?> value="sss3/grade11" class="option">SSS3/Grade11</option>
                          <option <?php if($lastgradecompleted == 'a-level/grade12'){ echo 'selected="selected"';} ?> value="a-level/grade12" class="option">Alevel/Grade12</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Name of Last School Attended"><span>*</span> Name of Last School Attended:</label>
                        <input value="<?php the_author_meta( 'name_of_last_school_attended', $user_id); ?>" type="text" name="name_of_last_school_attended" class="form-control fild10" placeholder="Name of Last School Attended">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Grade applied for in Danbo"><span>*</span> Grade applied for in Danbo:</label>
                        <select class="form-control fild10" name="grade_applied_for_in_danbo">
                          <option value="">Select  an option </option>
                          <option <?php if($gradeappliedforindanbo == 'playgroup'){ echo 'selected="selected"';} ?> value="playgroup" class="option">Playgroup</option>
                          <option <?php if($gradeappliedforindanbo == 'nursery1/preschool'){ echo 'selected="selected"';} ?> value="nursery1/preschool" class="option">Nursery1/Preschool</option>
                          <option <?php if($gradeappliedforindanbo == 'nursery2/pre-kindergarten'){ echo 'selected="selected"';} ?> value="nursery2/pre-kindergarten" class="option">Nursery1/Pre-kindergarten</option>
                          <option <?php if($gradeappliedforindanbo == 'class1/kindergarten'){ echo 'selected="selected"';} ?> value="class1/kindergarten" class="option">Class1/KindergartenSvg</option>
                          <option <?php if($gradeappliedforindanbo == 'class2/grade1'){ echo 'selected="selected"';} ?> value="class2/grade1" class="option">Class2/Grade1</option>
                          <option <?php if($gradeappliedforindanbo == 'class3/grade2'){ echo 'selected="selected"';} ?> value="class3/grade2" class="option">Class3/Grade2</option>
                          <option <?php if($gradeappliedforindanbo == 'class4/grade3'){ echo 'selected="selected"';} ?> value="class4/grade3" class="option">Class4/Grade3</option>
                          <option <?php if($gradeappliedforindanbo == 'class5/grade4'){ echo 'selected="selected"';} ?> value="class5/grade4" class="option">Class5/Grade4</option>
                          <option <?php if($gradeappliedforindanbo == 'class6/grade5'){ echo 'selected="selected"';} ?> value="class6/grade5" class="option">Class6/Grade5</option>
                          <option <?php if($gradeappliedforindanbo == 'jss1/grade6'){ echo 'selected="selected"';} ?> value="jss1/grade6" class="option">JSS1/Grade6</option>
                          <option <?php if($gradeappliedforindanbo == 'jss2/grade7'){ echo 'selected="selected"';} ?> value="jss2/grade7" class="option">JSS2/Grade7</option>
                          <option <?php if($gradeappliedforindanbo == 'jss3/grade8'){ echo 'selected="selected"';} ?> value="jss3/grade8" class="option">JSS3/Grade8</option>
                          <option <?php if($gradeappliedforindanbo == 'sss1/grade9'){ echo 'selected="selected"';} ?> value="sss1/grade9" class="option">SSS1/Grade9</option>
                          <option <?php if($gradeappliedforindanbo == 'sss2/grade10'){ echo 'selected="selected"';} ?> value="sss2/grade10" class="option">SSS2/Grade10</option>
                          <option <?php if($gradeappliedforindanbo == 'sss3/grade11'){ echo 'selected="selected"';} ?> value="sss3/grade11" class="option">SSS3/Grade11</option>
                          <option <?php if($gradeappliedforindanbo == 'a-level/grade12'){ echo 'selected="selected"';} ?> value="a-level/grade12" class="option">Alevel/Grade12</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Child's First language"><span>*</span> Child's First language:</label>
                        <input value="<?php the_author_meta( 'childs_first_language', $user_id); ?>" type="text" class="form-control fild10" name="childs_first_language" placeholder="Child's First language">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Does your child have any disability"><span>*</span> Does your child have any disability?</label>
                        <input <?php if($difficulty == 'Yes'){ echo 'checked';} ?> type="radio" name="difficulty" value="Yes"  required>
                        Yes <br>
                        <input <?php if($difficulty == 'No'){ echo 'checked';} ?> type="radio" name="difficulty" value="No" required>
                        No </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Address"><span>*</span> Address:</label>
                        <textarea  name="address" class="form-control" rows="2" required>
            <?php the_author_meta( 'address', $user_id); ?></textarea>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Date of Birth"><span>*</span> Date of Birth:</label>
                        <input value="<?php the_author_meta( 'date_of_birth', $user_id); ?>" type="date" name="date_of_birth" class="form-control fild10">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1"> Application ID:</label>
                        <input value="<?php the_author_meta( 'application_id', $user_id); ?>" disabled type="text" name="application_id" class="form-control fild10">
                      </div>
                    </div>
                    <div class="col-lg-6">
					<?php
						$author_badge = get_field('student_image', 'user_'. $user_id );
					?>
					
					<img src="<?php echo $author_badge;?>" width="60" height="60" />
                      <div class="form-group">
                        <label for="exampleInputFile"><span>*</span>Photo Upload</label>
                        <input type="file" name="student_image" id="exampleInputFile">
                      </div>
                    </div>
                    <h4>Parent's Information</h4>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's Name"><span>*</span> Father's Name:</label>
                        <input value="<?php the_author_meta( 'fathers_name', $user_id); ?>" type="text" class="form-control fild10" name="fathers_name" placeholder="Father's Name">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Name"><span>*</span> Mother's Name:</label>
                        <input value="<?php the_author_meta( 'mothers_name', $user_id); ?>" type="text" class="form-control fild10" name="mothers_name" placeholder="Mother's Name">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's Occupation"><span>*</span> Father's Occupation:</label>
                        <input value="<?php the_author_meta( 'fathers_occupation', $user_id); ?>" type="text" class="form-control fild10" name="fathers_occupation" placeholder="Father's Occupation">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Occupation"><span>*</span> Mother's Occupation:</label>
                        <input value="<?php the_author_meta( 'mothers_occupation', $user_id); ?>" type="text" class="form-control fild10" name="mothers_occupation" placeholder="Mother's Occupation">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's Email"><span>*</span> Father's Email:</label>
                        <input value="<?php the_author_meta( 'fathers_email', $user_id); ?>" type="email" class="form-control fild10" name="fathers_email" placeholder="Father's Email">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Email"><span>*</span> Mother's Email:</label>
                        <input value="<?php the_author_meta( 'mothers_email', $user_id); ?>" type="email" class="form-control fild10" name="mothers_email" placeholder="Mother's Email">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Fathers's Phone Number"><span>*</span> Fathers's Phone Number:</label>
                        <input value="<?php the_author_meta( 'fatherss_phone_number', $user_id); ?>"  type="text" class="form-control fild10" name="fatherss_phone_number" placeholder="Fathers's Phone Number">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Phone Number"><span>*</span> Mother's Phone Number:</label>
                        <input value="<?php the_author_meta( 'mothers_phone_number', $user_id); ?>" type="text" class="form-control fild10" name="mothers_phone_number" placeholder="Mother's Phone Number">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's House Address"><span>*</span> Father's House Address:</label>
                        <textarea rows="2" cols="1" name="fathers_house_address" class="form-control" placeholder="House Number, Street Address, State " required>
<?php the_author_meta( 'fathers_house_address', $user_id); ?></textarea>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's House Address"><span>*</span> Mother's House Address:</label>
                        <textarea rows="2" cols="1" name="mothers_house_address" class="form-control" placeholder="House Number, Street Address, State " required>
     <?php the_author_meta( 'mothers_house_address', $user_id); ?>  </textarea>
                      </div>
                    </div>
                    <button type="submit" name="submit" class="btn btn-default review">submit</button>
                  </div>
                </form>
                
				
				
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php get_footer(); ?>
