<?php
/**
 * Template Name: Home
 */

get_header(); ?>
 <!-- Banner -->
  <div class="banner">
    <div class="slider">
      <div class="callbacks_container">
        <ul class="rslides" id="slider">
			<?php
			$args = array( 'post_type' => 'slider', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$n = 0;
			while ( $loop->have_posts() ) : $loop->the_post(); 
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
			
          <li> <img src="<?php echo $imgurl;?>" alt=" ">
            <div class="btext">
              <h1><?php echo $title;?></h1>
              <a href="#" class="know">KNOW MORE <i class="fa fa-caret-right" aria-hidden="true"></i> </a> </div>
          </li>
			<?php $p++; endwhile; wp_reset_postdata(); ?> 

        </ul>
      </div>
    </div>
  </div>
  <!-- end Banner --> 
  
  <!-- Our covid news 
  <div class="covid">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <h3>Our covid news</h3>
          </div>
          <div class="col-lg-7 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".7s">
            <?php the_field('our_covid_news',2); ?> 
          </div>
          <div class="col-lg-1 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".9s"> 
		  <a href="<?php echo home_url('/our-covid/'); ?>" class="warrow"><img src="<?php echo get_template_directory_uri(); ?>/img/arrow.png" alt=" "></a> </div>
        </div>
      </div>
    </div>
  </div>
 end Our covid news --> 
  
  <!-- Welcome -->
  <div class="welcome">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">Welcome To Danbo International School</h3>
        <p class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_field('international_school',2); ?> </p>
        <div class="wel-img wow zoomIn" data-wow-duration="2s" data-wow-delay=".5s"><img src="<?php the_field('international_school_image',2); ?> " alt=" "></div>
      </div>
    </div>
  </div>
  <!-- end Welcome --> 
  
  <!-- Our Values -->
  <div class="values">
    <div class="row">
      <div class="col-lg-7">
        <div class="ourl">
          <h3>Our Values</h3>
          <?php the_field('our_values',2); ?> 
        </div>
      </div>
      <div class="col-lg-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
        <div class="valu-img" style="background:url(<?php the_field('our_values_image',2); ?> "></div>
      </div>
    </div>
  </div>
  <!-- end Our Values --> 
  
  <!-- Independent Thinkers -->
  <div class="thinkr">
    <div class="container-fluid">
      <ul>
        <li class=" wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s"><samp><img src="<?php echo get_template_directory_uri(); ?>/img/Independent.png" alt=" "></samp><span>Independent</span><span>Thinkers</span></li>
        <li class=" wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.0s"><samp><img src="<?php echo get_template_directory_uri(); ?>/img/Respectful.png" alt=" "></samp><span>Respectful</span><span>To All</span></li>
        <li class=" wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.5s"><samp><img src="<?php echo get_template_directory_uri(); ?>/img/Accountability.png" alt=" "></samp><span>Accountability</span><span>& Responsibility</span></li>
        <li class=" wow fadeInLeft" data-wow-duration="2s" data-wow-delay="2.0s"><samp><img src="<?php echo get_template_directory_uri(); ?>/img/Discipline.png" alt=" "></samp><span>Discipline</span><span>& Knowledge</span></li>
        <li class=" wow fadeInLeft" data-wow-duration="2s" data-wow-delay="2.5s"><samp><img src="<?php echo get_template_directory_uri(); ?>/img/Excellence.png" alt=" "></samp><span>Excellence</span><span>& Leadership</span></li>
      </ul>
    </div>
  </div>
  <!-- end Independent Thinkers --> 
  
  <!-- Why Choose -->
  <div class="choose">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">Why Choose Us?</h3>
		  <?php
			$args = array( 'post_type' => 'why_choose_us', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$p = 1;
			while ( $loop->have_posts() ) : $loop->the_post(); global $product;
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
		  
       
		<style>
		.choose .exper-<?php echo $p; ?>{ background:url(<?php echo $imgurl;?>) no-repeat 0px 0px; transition:all .3s ease-in-out;}

.choose .exper:hover .exper-<?php echo $p; ?>{ background:url(<?php echo $imgurl;?>) no-repeat; transition:all .3s ease-in-out;}
		</style>
		
		 <div class="exper wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.5s">
          <div class="exper-<?php echo $p; ?>"></div>
          <h4><?php echo $title;?></h4>
          <p><?php echo $getcontent;?></p>
        </div>
		 <?php $p++; endwhile; wp_reset_postdata(); ?> 
		  

		  
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <!-- end Why Choose --> 
  
  <!-- Our Partners -->
  <div class="partner">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">Our Partners</h3>
        <div class="clogo">
          <div class="bxslider logosImgs">
			  <?php
			$args = array( 'post_type' => 'our_partners', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$n = 0;
			while ( $loop->have_posts() ) : $loop->the_post(); 
			
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
            <div class="partn-img"><img src="<?php echo $imgurl;?>" alt=" "></div>
			 <?php $p++; endwhile; wp_reset_postdata(); ?> 
			  
			  
			  </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Partners --> 
  
</main>
<?php get_footer(); ?>

<!-- start banner slider --> 
<script src="<?php echo get_template_directory_uri(); ?>/js/responsiveslides.min.js"></script> 
<script>
    $(function () {
      $("#slider").responsiveSlides({
      	auto: true,
      	speed: 500,
        namespace: "callbacks",
        pager: true,
      });
    });
</script> 
<!--end banner slider --> 
