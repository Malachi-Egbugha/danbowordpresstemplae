<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

<div class="col-lg-3">
  <div class="abright">
	<h4>Community</h4>
	<ul>
	  <li class="<?php if(is_page('student-council')){ echo 'active';}?>"><a href="<?php echo home_url('/student-council/'); ?>">Student Council</a></li>
	  <li class="<?php if(is_page('pta')){ echo 'active';}?>"><a href="<?php echo home_url('/pta/'); ?>">PTA</a> </li>
	  <li class="<?php if(is_page('alumni')){ echo 'active';}?>"><a href="<?php echo home_url('/alumni/'); ?>">Alumni</a> </li>
	  <li class="<?php if(is_page('where-are-our-graduates-alumni-now')){ echo 'active';}?>"><a href="<?php echo home_url('/where-are-our-graduates-alumni-now/'); ?>">Where are our Graduates & Alumni now?</a> </li>
	</ul>
  </div>
</div>