<?php session_start();?>
<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage 
 * @since Danbo 1.0
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<link rel="shortcut icon" type="image/x-icon" href="<?php echo get_template_directory_uri(); ?>/img/1593323589.ico">
	<title>Welcome To Danbo International School</title>
	<!-- Bootstrap core CSS -->
	<link href="<?php echo get_template_directory_uri(); ?>/css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css'>
	<link href="<?php echo get_template_directory_uri(); ?>/css/fonts.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/animate.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/bxslider/4.2.12/jquery.bxslider.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">

	<link href="<?php echo get_template_directory_uri(); ?>/css/skstyle.css" rel="stylesheet">
	<link href="<?php echo get_template_directory_uri(); ?>/css/mystyle.css" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<header> 
  
  <!-- top -->
  <div class="top">
    <div class="container-fluid">
      <div class="maxw">
        <div class="logo"> <a class="navbar-brand" href="<?php echo home_url(); ?>"><img src="<?php the_field('header_logo','option'); ?>" alt=" "></a><samp><span>D<var>anbo</var> I<var>nternational</var> S<var>chool</var> </span></samp> </div>
        <div class="social wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
          <ul>
			  <?php if( have_rows('social','option') ): ?>
					<?php 
					while( have_rows('social','option') ): the_row(); 

					// vars
					$logo = get_sub_field('social_logo');
					$link = get_sub_field('social_link');

					?>
                <li><a href="<?php echo $link;?>" target="_blank"><i class="fa fa-<?php echo $logo;?>" aria-hidden="true"></i></a></li>
				  <?php endwhile; ?>
					<?php endif; ?>
<!--             <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
            <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li> -->
          </ul>
        </div>
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <!-- end top --> 
  
  <!-- nav -->
  <nav class="navbar navbar-expand-md navbar-dark topmenu">
    <div class="container-fluid clearfix">
      <div class="maxw clearfix">
        <div class="header_box">
          <div class="menu">
            
			
<!--<div class="menuButton"> <span></span> <span></span> <span></span> </div>-->
 <?php  wp_nav_menu( array('theme_location' => 'primary' , 'menu_class' => 'navbar-nav mr-auto' ) ); ?>           
			
			<!-- <ul class="navbar-nav mr-auto">
            


			<li class="nav-item active"><a class="nav-link" href="index.html">Home</a></li>
              <li class="nav-item"><a class="nav-link" href="aboutus.html">About Us</a>
                <ul class="drop sub">
                  <li><a href="#">Founders/ED note</a></li>
                  <li><a href="history.html">History</a> </li>
                  <li><a href="mission.html">Vision, Mission & Our Values </a> </li>
                  <li><a href="quality-assurance-statement.html">Our promise to you - QA Statement</a> </li>
                  <li><a href="faq.html">Frequently asked questions</a> </li>
                  <li><a href="whychoose.html">Why choose us</a> </li>
                  <li><a href="ourpartners.html">Our partners</a> </li>
                  <li><a href="e-learning.html">E-Learning</a> </li>
                  <li><a href="contact.html">Contact us</a> </li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="kadunaschool.html">Our School</a>
                <ul class="drop sub">
                  <li><a href="kadunaschool.html">Danbo International School Kaduna</a></li>
                  <li><a href="abujaschool.html">Danbo International School Abuja </a></li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="schoollife.html">School Life</a>
                <ul class="drop sub">
                  <li><a href="earlyyear.html">Early Years</a>
                    <ul class="drop sub">
                      <li><a href="welcomemessage.html">Welcome Message</a></li>
                      <li><a href="curriculum.html">Curriculum</a></li>
                      <li><a href="program.html">Program(s) I.E JSS & SSC</a> </li>
                      <li><a href="co-curricular-activities.html">Co Curricular activities</a> </li>
                      <li><a href="extra-curricular-activities.html">Extra Curricular activities</a> </li>
                      <li><a href="assessment-reporting.html">Assessment and reporting</a> </li>
                      <li><a href="schooltimes.html">School  Times/Schedule</a> </li>
                      <li><a href="facilities.html">Facilities</a> </li>
                      <li><a href="specialday.html">Events/Special days</a> </li>
                      <li><a href="admission-process.html">Admissions</a> </li>
                    </ul>
                  </li>
                  <li><a href="primary.html">Primary </a></li>
                  <li><a href="secondary.html">Secondary</a> </li>
                  <li><a href="sens.html">SENS</a> </li>
                  <li><a href="college.html">College</a> </li>
                  <li><a href="dboardschool.html">Danbo Boarding school</a> </li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="admission.html">Admissions</a>
                <ul class="drop sub">
                  <li><a href="admission-policy.html">Admission Policy</a></li>
                  <li><a href="admission.html#applynow">Apply Now</a> </li>
                  <li><a href="admission.html#applynow">Online Placement Assessment</a> </li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="disportal.html">Dis Portal</a>
                <ul class="drop sub">
                  <li><a href="student-access.html">Student Access</a></li>
                  <li><a href="parent-login.html">Parent Login/Payment </a></li>
                  <li><a href="staff-access.html">Staff Access</a> </li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="community.html">Community</a>
                <ul class="drop sub">
                  <li><a href="student-council.html">Student Council</a></li>
                  <li><a href="pta.html">PTA</a></li>
                  <li><a href="alumni.html">Alumni</a> </li>
                  <li><a href="#">Where are our Graduates & Alumni now?</a> </li>
                </ul>
              </li>
              <li class="nav-item"><a class="nav-link" href="schoolshop.html">School Shop</a></li>
              <li class="nav-item"><a class="nav-link" href="gallery.html">Gallery</a></li>
              <li class="nav-item"><a class="nav-link" href="blog.html">Blog</a></li>
            </ul>-->
          </div>
        </div>
      </div>
    </div>
  </nav>
  <!-- end nav --> 
  
</header>