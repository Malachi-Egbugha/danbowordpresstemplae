<?php
/**
 * Template Name: Our Covid
 */

get_header(); ?>
<main> 
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?>
	
  
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            <div class="col-lg-12 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
              <div class="abarea">
                <h3>Our Covid</h3>
                <div class="ourpro">
                 
				 
<?php the_content();?>

			   </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  	<?php endwhile;  ?>	
</main>
<?php get_footer(); ?>
