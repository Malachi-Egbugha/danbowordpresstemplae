<?php
/**
 * Template Name: School Life
 */

get_header(); 



?>
<main> 
  
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
  <!-- Our Primary School -->
  <div class="primary pschool">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-4 col-md-5 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
           <nav>
              <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist"> 
			  
			  
			 
			  
	<?php if( have_rows('admission_section') ): ?>
    <?php 
		$p=0;
		while( have_rows('admission_section') ): the_row(); 
        $title = get_sub_field('admission_title');
		$content = get_sub_field('admission_content');
     ?>
        <a class="nav-item nav-link <?php if($p==0){echo 'active';}?>" id="nav-<?php echo $p; ?>-tab" data-toggle="tab" href="#nav-<?php echo $p; ?>" role="tab" aria-controls="nav-<?php echo $p; ?>" aria-selected="<?php if($p==0){echo 'true'; }else {echo 'false';}?>"> <?php echo $title;?><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
    <?php $p++; endwhile; ?> 
	<?php endif; ?>
			  

			 </div>
            </nav>
          </div>
          <div class="col-lg-8 col-md-7 pl-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
            <?php if( have_rows('admission_section') ): ?>
    <?php 
		$pp=0;
		while( have_rows('admission_section') ): the_row(); 
        $title = get_sub_field('admission_title');
		$content = get_sub_field('admission_content');
     ?>
       <div class="tab-pane fade show <?php if($pp==0){echo 'active';}?>" id="nav-<?php echo $pp; ?>" role="tabpanel" aria-labelledby="nav-<?php echo $pp; ?>-tab">
		<h4><?php echo $title;?></h4>
		<?php echo $content;?>
		</div>
    <?php $pp++; endwhile; ?> 
	<?php endif; ?>
			
			  
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Primary School --> 
  <?php
	while ( have_posts() ) : the_post();
	$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
?>
  <!-- Curriculum Programs -->
  <div class="curricul">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 col-md-6 pr-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="progra">
             
			 <?php the_content(); ?>
            
			</div>
          </div>
          <div class="col-lg-6 col-md-6 pl-4 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="asw">
              
			  <div class="schoolimg"><img src="<?php echo $image[0];?>" alt=" "></div>
              <?php echo get_field('editorschoollife');?>
           
		   </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Curriculum Programs --> 
<?php endwhile;  ?> 
  <!-- School  Times -->
  <div class="stime">
    <div class="container-fluid">
      <div class="maxw">
        <h3><?php echo get_field('school__times');?></h3>
        <div class="table-responsive">
          <table>
            <tr class="tme">
              
	<?php if( have_rows('school_times') ): ?>
    <?php 
		while( have_rows('school_times') ): the_row(); 
        $title = get_sub_field('school_days');
		
     ?>
			  <td><?php echo $title;?></td>
        <?php  endwhile; ?> 
	<?php endif; ?>      
            </tr>
            
			
              
           
			
	<?php if( have_rows('school_times') ): ?>
    <?php 
		while( have_rows('school_times') ): the_row(); 
        $title = get_sub_field('school_days');
		
     ?>
	 
	 
			<tr>
        
					
	<?php if( have_rows('school_timing') ): ?>
    <?php 
		while( have_rows('school_timing') ): the_row(); 
        $sub = get_sub_field('subject_time');
		$subTime = get_sub_field('subject_times');
		
     ?>
	 
	 
			 <td class="mat"><?php echo $sub;?><span><?php echo $subTime;?></span></td>
        
		
		
		<?php  endwhile; ?> 
	<?php endif; ?>  
		
		 </tr>	
		
		<?php  endwhile; ?> 
	<?php endif; ?>  
		
			
          </table>
        </div>
      </div>
    </div>
  </div>
  <!-- end School  Times --> 
  
  <!-- Why Choose -->
  <div class="choose facilite">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s"><?php echo get_field('facilities_title');?></h3>
        
		<?php
			$args = array( 'post_type' => 'facilities', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$p = 1;
			while ( $loop->have_posts() ) : $loop->the_post(); global $product;
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
		  
       
		<style>
		.choose .exper-<?php echo $p; ?>{ background:url(<?php echo $imgurl;?>) no-repeat 0px 0px; transition:all .3s ease-in-out;}

.choose .exper:hover .exper-<?php echo $p; ?>{ background:url(<?php echo $imgurl;?>) no-repeat; transition:all .3s ease-in-out;}
		</style>
		
		 <div class="exper wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.5s">
          <div class="exper-<?php echo $p; ?>"></div>
          <h4><?php echo $title;?></h4>
          <p><?php echo $getcontent;?></p>
        </div>
		 <?php $p++; endwhile; wp_reset_postdata(); ?> 
        
		
		
		
      </div>
    </div>
    <div class="clearfix"></div>
  </div>
  <!-- end Why Choose --> 
  
   <?php include('applyNowSide.php');?>
  
</main>

<?php get_footer(); ?>
