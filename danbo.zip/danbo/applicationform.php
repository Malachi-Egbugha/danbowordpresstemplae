<?php
/**
 * Template Name: Application Form
 */
session_start();
get_header();

$fName=$_POST['FirstName1'];
$lName=$_POST['LastName'];
$pNumber=$_POST['phone_no'];
$pemail=$_POST['temail'];
$appid=$_POST['appid'];
$pass=$_POST['appid'];



//$userID = $_GET['id'];
//$full_name = $_POST['FirstName'] . $_POST['surname'];

if(isset( $_POST['action'] ) && $_POST['action']=='business_form') 
{
$exists = email_exists($pemail);
if ( !$exists ) {
   
   $userdata = array(
		'first_name'  => $_POST['fname'],
		'user_email'  => $_POST['pemail'],
		'user_login'  => $_POST['pemail'],
		'user_pass'   => $_POST['ppass'],
		'last_name'   => $_POST['lname'],
		'role'	 	  => 'parent'
		
	);
		
	$user_id = wp_insert_user( $userdata ) ;
   
	//add_user_meta( $user_id, 'application_id',$_POST['appid']);
  
    if ( ! function_exists( 'wp_handle_upload' ) ) {

		require_once( ABSPATH . 'wp-admin/includes/image.php' );
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
		require_once( ABSPATH . 'wp-admin/includes/media.php' );
      }  
	  
	  
	$attachment_id = media_handle_upload( 'imagestyu', $user_id);
     
    if ( is_wp_error( $attachment_id ) ) {
       //There was an error uploading the image.
    } else {
      //echo "success"; 
	   add_user_meta($user_id, 'student_image', $attachment_id);
    }  
		
	add_user_meta($user_id,'firstname', $_POST['FirstName']);
	add_user_meta($user_id,'surname', $_POST['surname']);
	add_user_meta($user_id,'middle_name', $_POST['MiddleName']);
	add_user_meta($user_id,'nationality', $_POST['nationality']);
	add_user_meta($user_id,'gender', $_POST['gender']);
	add_user_meta($user_id,'last_grade_completed', $_POST['last_grade_completed']);
	add_user_meta($user_id,'name_of_last_school_attended', $_POST['name_of_last_school_attended']);
	add_user_meta($user_id,'grade_applied_for_in_danbo', $_POST['grade_applied_for_in_danbo']);
	add_user_meta($user_id,'childs_first_language', $_POST['childs_first_language']);
	add_user_meta($user_id,'difficulty', $_POST['difficulty']);
	add_user_meta($user_id,'address', $_POST['address']);
	add_user_meta($user_id,'date_of_birth', $_POST['date_of_birth']);
	//add_user_meta($user_id,'field_5f46622659c22', $_SESSION['reg_status']);
	add_user_meta($user_id,'application_id',$_POST['appid'] );
	//Father Field
	add_user_meta($user_id,'fathers_name', $_POST['fathers_name']);
	add_user_meta($user_id,'mothers_name', $_POST['mothers_name']);
	add_user_meta($user_id,'fathers_occupation', $_POST['fathers_occupation']);
	add_user_meta($user_id,'mothers_occupation', $_POST['mothers_occupation']);
	add_user_meta($user_id,'fathers_email', $_POST['fathers_email']);
	add_user_meta($user_id,'mothers_email', $_POST['mothers_email']);
	add_user_meta($user_id,'fatherss_phone_number', $_POST['fatherss_phone_number']);
	add_user_meta($user_id,'mothers_phone_number', $_POST['mothers_phone_number']);
	add_user_meta($user_id,'fathers_house_address', $_POST['fathers_house_address']);
	add_user_meta($user_id,'mothers_house_address', $_POST['mothers_house_address']);
	//add_user_meta($user_id,'student_image', $_POST['mothers_house_address']);
  
	$msg= 'Thank you for applying to Danbo International School';
	echo '<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
			 <script type="text/JavaScript"> 


			
swal({
  text: "Thank you for your interest in Danbo International Schools",
});

			 </script>';
	//mail
	$to = $_POST['fathers_email'];
				$subject = "Fill up Application Form";
				$message = '
					<html>
					<head>
						<title>Danbo International School</title>
					</head>
					<body>
					<div style="text-align:center;font-weight:600;font-size:26px;padding:10px 0;border-bottom:solid 3px #eeeeee;">
						<img src="https://danboschools.com/wp-content/uploads/2020/08/logo.png" alt="logo" title="" /></div>
							<div style="clear:both;"></div>
					</div>
					<div>
					Dear '.$_POST['fname'].' '. $_POST['lname'].', 
 
<p>Thank you for applying to Danbo International School (DIS)</p>
 
<p>DIS was established in 1981 for students aged 1 to 18 and is now widely recognized
for academic excellence and achievement. Our highly-qualified teachers embrace the school’s core values of independent thinking, diversity, respect, accountability and responsibility. These values are infused into everyday life at the school.</p>
 
 
 
<p> The next step of the application process is to formally assess ' .$_POST['FirstName'] .' for a indicate' . $_POST['grade_applied_for_in_danbo'].'starting Term 1 of the academic year 2020/2021. Our placements assessments can be taken online, however, before we can arrange this, please submit the following:</p> 
<ol style="ol.f {list-style-type: decimal;}">
<li>	a copy of '.$_POST['FirstName'].'birth certificate.</li>
<li>	a copy of one parent’s regulatory ID.</li>
<li>	copy of '.$_POST['FirstName'].' most recent school report </li>
<li>	name and email address of '.$_POST['FirstName'].' current teacher or Head of School – we will be contacting them for a confidential reference. </li>
<li>	a recent photograph of '.$_POST['FirstName'].', with a plain white background for ID card (digital only) </li>
<li>	application fee payment of N5,000 per student <a href="http://theitvibe.com/work/DanboInternationalSchool/pay-now/">(Pay Now)</a> </li>
</ol> 
 
<p> PLEASE NOTE: all required documents and the application fee must be submitted within one week of your initial on-line application. If any application is incomplete after one week, we will be unable to arrange an assessment and your application may be cancelled.</p>

<p> We would like to also highlight that we will try our best to place your child but positions at the school are in high demand with waiting lists often in place therefore placement is determined by availability at the time of application. </p>

<p> If you would like more information, please do not hesitate to contact me at your convenience. </p>
  

					
					</div>
					<!--
					<table>
						<tr>
							<th>Pay Now Link:</th>
							<td><a href="http://theitvibe.com/work/DanboInternationalSchool/pay-now/">Pay Now</a></td>
						</tr>
						
					</table>
					-->
					<div>
					Kindest regards,<br>
					Admission Team <br>
					Danbo International School

					</div>
					</body>
					</html>
					';
				// Always set content-type when sending HTML email
				$headers[] = "MIME-Version: 1.0" . "\r\n";
				$headers[]= "Content-type:text/html;charset=UTF-8" . "\r\n";
				// More headers
				$headers[]= 'From: <info@danboschoolsabuja.com>' . "\r\n";
				$headers[]= 'Bcc: <info@danboschoolsabuja.com>' . "\\r\ ";
				if(wp_mail($to,$subject,$message,$headers)){
				$msg = 'Thank you for applying to Danbo International School (DIS)';
				}


}else {
	$msg= "<h4 class='mesg'>That E-mail doesn't belong to any registered users on this site</h4>";	
}

}





 ?>
<main> 
  
  <!-- about -->
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
    <div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            <div class="col-lg-12">
              <div class="appfrom">
                <h3>Danbo International Schools (DIS) Application Form</h3>
                <p>Important Notice: This application form is intended only for DIS admission process. Please ensure that the information provided is complete, true and accurate. Once you have completed this form, kindly submit it by clicking on the submit button. A confirmatory email and your copy of the completed application form will be sent to the supplied email address.</p>
                <h4>Child's Information</h4>
                <div class="allmark pb-2">Note all fields marked * are compulsory</div>
               <p style="color:#11bb7c;"><?php echo $msg;?></p>
			   <form name="form" action="" method="post" enctype="multipart/form-data">
			   <input type="hidden" name="fname" value="<?php echo $fName;?>">
			   <input type="hidden" name="lname" value="<?php echo $lName;?>">
			   <input type="hidden" name="pnumber" value="<?php echo $pNumber;?>">
			   <input type="hidden" name="pemail" value="<?php echo $pemail;?>">
			   <input type="hidden" name="ppass" value="<?php echo $pass;?>">
			   <input type="hidden" name="appid" value="<?php echo $appid;?>">
			   
			   
				<input type="hidden" name="action" value="business_form">
                  <div class="row">
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="First Name"><span>*</span> First Name:</label>
                        <input type="text" class="form-control fild10" name="FirstName" placeholder="First Name">
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Surname"><span>*</span> Surname:</label>
                        <input type="text" class="form-control fild10" name="surname" placeholder="Surname">
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Middle Name"> Middle Name:</label>
                        <input type="text" class="form-control fild10" name="MiddleName" placeholder="Middle Name">
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Nationality"><span>*</span> Nationality:</label>
                        <select class="form-control fild10" name="nationality">
                          <option value="">Select  an option </option>
                          <option value="Afganistan">Afghanistan</option>
                          <option value="Albania">Albania</option>
                          <option value="Algeria">Algeria</option>
                          <option value="American Samoa">American Samoa</option>
                          <option value="Andorra">Andorra</option>
                          <option value="Angola">Angola</option>
                          <option value="Anguilla">Anguilla</option>
                          <option value="Antigua &amp; Barbuda">Antigua &amp; Barbuda</option>
                          <option value="Argentina">Argentina</option>
                          <option value="Armenia">Armenia</option>
                          <option value="Aruba">Aruba</option>
                          <option value="Australia">Australia</option>
                          <option value="Austria">Austria</option>
                          <option value="Azerbaijan">Azerbaijan</option>
                          <option value="Bahamas">Bahamas</option>
                          <option value="Bahrain">Bahrain</option>
                          <option value="Bangladesh">Bangladesh</option>
                          <option value="Barbados">Barbados</option>
                          <option value="Belarus">Belarus</option>
                          <option value="Belgium">Belgium</option>
                          <option value="Belize">Belize</option>
                          <option value="Benin">Benin</option>
                          <option value="Bermuda">Bermuda</option>
                          <option value="Bhutan">Bhutan</option>
                          <option value="Bolivia">Bolivia</option>
                          <option value="Bonaire">Bonaire</option>
                          <option value="Bosnia &amp; Herzegovina">Bosnia &amp; Herzegovina</option>
                          <option value="Botswana">Botswana</option>
                          <option value="Brazil">Brazil</option>
                          <option value="British Indian Ocean Ter">British Indian Ocean Ter</option>
                          <option value="Brunei">Brunei</option>
                          <option value="Bulgaria">Bulgaria</option>
                          <option value="Burkina Faso">Burkina Faso</option>
                          <option value="Burundi">Burundi</option>
                          <option value="Cambodia">Cambodia</option>
                          <option value="Cameroon">Cameroon</option>
                          <option value="Canada">Canada</option>
                          <option value="Canary Islands">Canary Islands</option>
                          <option value="Cape Verde">Cape Verde</option>
                          <option value="Cayman Islands">Cayman Islands</option>
                          <option value="Central African Republic">Central African Republic</option>
                          <option value="Chad">Chad</option>
                          <option value="Channel Islands">Channel Islands</option>
                          <option value="Chile">Chile</option>
                          <option value="China">China</option>
                          <option value="Christmas Island">Christmas Island</option>
                          <option value="Cocos Island">Cocos Island</option>
                          <option value="Colombia">Colombia</option>
                          <option value="Comoros">Comoros</option>
                          <option value="Congo">Congo</option>
                          <option value="Cook Islands">Cook Islands</option>
                          <option value="Costa Rica">Costa Rica</option>
                          <option value="Cote DIvoire">Cote D'Ivoire</option>
                          <option value="Croatia">Croatia</option>
                          <option value="Cuba">Cuba</option>
                          <option value="Curaco">Curacao</option>
                          <option value="Cyprus">Cyprus</option>
                          <option value="Czech Republic">Czech Republic</option>
                          <option value="Denmark">Denmark</option>
                          <option value="Djibouti">Djibouti</option>
                          <option value="Dominica">Dominica</option>
                          <option value="Dominican Republic">Dominican Republic</option>
                          <option value="East Timor">East Timor</option>
                          <option value="Ecuador">Ecuador</option>
                          <option value="Egypt">Egypt</option>
                          <option value="El Salvador">El Salvador</option>
                          <option value="Equatorial Guinea">Equatorial Guinea</option>
                          <option value="Eritrea">Eritrea</option>
                          <option value="Estonia">Estonia</option>
                          <option value="Ethiopia">Ethiopia</option>
                          <option value="Falkland Islands">Falkland Islands</option>
                          <option value="Faroe Islands">Faroe Islands</option>
                          <option value="Fiji">Fiji</option>
                          <option value="Finland">Finland</option>
                          <option value="France">France</option>
                          <option value="French Guiana">French Guiana</option>
                          <option value="French Polynesia">French Polynesia</option>
                          <option value="French Southern Ter">French Southern Ter</option>
                          <option value="Gabon">Gabon</option>
                          <option value="Gambia">Gambia</option>
                          <option value="Georgia">Georgia</option>
                          <option value="Germany">Germany</option>
                          <option value="Ghana">Ghana</option>
                          <option value="Gibraltar">Gibraltar</option>
                          <option value="Great Britain">Great Britain</option>
                          <option value="Greece">Greece</option>
                          <option value="Greenland">Greenland</option>
                          <option value="Grenada">Grenada</option>
                          <option value="Guadeloupe">Guadeloupe</option>
                          <option value="Guam">Guam</option>
                          <option value="Guatemala">Guatemala</option>
                          <option value="Guinea">Guinea</option>
                          <option value="Guyana">Guyana</option>
                          <option value="Haiti">Haiti</option>
                          <option value="Hawaii">Hawaii</option>
                          <option value="Honduras">Honduras</option>
                          <option value="Hong Kong">Hong Kong</option>
                          <option value="Hungary">Hungary</option>
                          <option value="Iceland">Iceland</option>
                          <option value="India">India</option>
                          <option value="Indonesia">Indonesia</option>
                          <option value="Iran">Iran</option>
                          <option value="Iraq">Iraq</option>
                          <option value="Ireland">Ireland</option>
                          <option value="Isle of Man">Isle of Man</option>
                          <option value="Israel">Israel</option>
                          <option value="Italy">Italy</option>
                          <option value="Jamaica">Jamaica</option>
                          <option value="Japan">Japan</option>
                          <option value="Jordan">Jordan</option>
                          <option value="Kazakhstan">Kazakhstan</option>
                          <option value="Kenya">Kenya</option>
                          <option value="Kiribati">Kiribati</option>
                          <option value="Korea North">Korea North</option>
                          <option value="Korea Sout">Korea South</option>
                          <option value="Kuwait">Kuwait</option>
                          <option value="Kyrgyzstan">Kyrgyzstan</option>
                          <option value="Laos">Laos</option>
                          <option value="Latvia">Latvia</option>
                          <option value="Lebanon">Lebanon</option>
                          <option value="Lesotho">Lesotho</option>
                          <option value="Liberia">Liberia</option>
                          <option value="Libya">Libya</option>
                          <option value="Liechtenstein">Liechtenstein</option>
                          <option value="Lithuania">Lithuania</option>
                          <option value="Luxembourg">Luxembourg</option>
                          <option value="Macau">Macau</option>
                          <option value="Macedonia">Macedonia</option>
                          <option value="Madagascar">Madagascar</option>
                          <option value="Malaysia">Malaysia</option>
                          <option value="Malawi">Malawi</option>
                          <option value="Maldives">Maldives</option>
                          <option value="Mali">Mali</option>
                          <option value="Malta">Malta</option>
                          <option value="Marshall Islands">Marshall Islands</option>
                          <option value="Martinique">Martinique</option>
                          <option value="Mauritania">Mauritania</option>
                          <option value="Mauritius">Mauritius</option>
                          <option value="Mayotte">Mayotte</option>
                          <option value="Mexico">Mexico</option>
                          <option value="Midway Islands">Midway Islands</option>
                          <option value="Moldova">Moldova</option>
                          <option value="Monaco">Monaco</option>
                          <option value="Mongolia">Mongolia</option>
                          <option value="Montserrat">Montserrat</option>
                          <option value="Morocco">Morocco</option>
                          <option value="Mozambique">Mozambique</option>
                          <option value="Myanmar">Myanmar</option>
                          <option value="Nambia">Nambia</option>
                          <option value="Nauru">Nauru</option>
                          <option value="Nepal">Nepal</option>
                          <option value="Netherland Antilles">Netherland Antilles</option>
                          <option value="Netherlands">Netherlands (Holland, Europe)</option>
                          <option value="Nevis">Nevis</option>
                          <option value="New Caledonia">New Caledonia</option>
                          <option value="New Zealand">New Zealand</option>
                          <option value="Nicaragua">Nicaragua</option>
                          <option value="Niger">Niger</option>
                          <option value="Nigeria">Nigeria</option>
                          <option value="Niue">Niue</option>
                          <option value="Norfolk Island">Norfolk Island</option>
                          <option value="Norway">Norway</option>
                          <option value="Oman">Oman</option>
                          <option value="Pakistan">Pakistan</option>
                          <option value="Palau Island">Palau Island</option>
                          <option value="Palestine">Palestine</option>
                          <option value="Panama">Panama</option>
                          <option value="Papua New Guinea">Papua New Guinea</option>
                          <option value="Paraguay">Paraguay</option>
                          <option value="Peru">Peru</option>
                          <option value="Phillipines">Philippines</option>
                          <option value="Pitcairn Island">Pitcairn Island</option>
                          <option value="Poland">Poland</option>
                          <option value="Portugal">Portugal</option>
                          <option value="Puerto Rico">Puerto Rico</option>
                          <option value="Qatar">Qatar</option>
                          <option value="Republic of Montenegro">Republic of Montenegro</option>
                          <option value="Republic of Serbia">Republic of Serbia</option>
                          <option value="Reunion">Reunion</option>
                          <option value="Romania">Romania</option>
                          <option value="Russia">Russia</option>
                          <option value="Rwanda">Rwanda</option>
                          <option value="St Barthelemy">St Barthelemy</option>
                          <option value="St Eustatius">St Eustatius</option>
                          <option value="St Helena">St Helena</option>
                          <option value="St Kitts-Nevis">St Kitts-Nevis</option>
                          <option value="St Lucia">St Lucia</option>
                          <option value="St Maarten">St Maarten</option>
                          <option value="St Pierre &amp; Miquelon">St Pierre &amp; Miquelon</option>
                          <option value="St Vincent &amp; Grenadines">St Vincent &amp; Grenadines</option>
                          <option value="Saipan">Saipan</option>
                          <option value="Samoa">Samoa</option>
                          <option value="Samoa American">Samoa American</option>
                          <option value="San Marino">San Marino</option>
                          <option value="Sao Tome &amp; Principe">Sao Tome &amp; Principe</option>
                          <option value="Saudi Arabia">Saudi Arabia</option>
                          <option value="Senegal">Senegal</option>
                          <option value="Serbia">Serbia</option>
                          <option value="Seychelles">Seychelles</option>
                          <option value="Sierra Leone">Sierra Leone</option>
                          <option value="Singapore">Singapore</option>
                          <option value="Slovakia">Slovakia</option>
                          <option value="Slovenia">Slovenia</option>
                          <option value="Solomon Islands">Solomon Islands</option>
                          <option value="Somalia">Somalia</option>
                          <option value="South Africa">South Africa</option>
                          <option value="Spain">Spain</option>
                          <option value="Sri Lanka">Sri Lanka</option>
                          <option value="Sudan">Sudan</option>
                          <option value="Suriname">Suriname</option>
                          <option value="Swaziland">Swaziland</option>
                          <option value="Sweden">Sweden</option>
                          <option value="Switzerland">Switzerland</option>
                          <option value="Syria">Syria</option>
                          <option value="Tahiti">Tahiti</option>
                          <option value="Taiwan">Taiwan</option>
                          <option value="Tajikistan">Tajikistan</option>
                          <option value="Tanzania">Tanzania</option>
                          <option value="Thailand">Thailand</option>
                          <option value="Togo">Togo</option>
                          <option value="Tokelau">Tokelau</option>
                          <option value="Tonga">Tonga</option>
                          <option value="Trinidad &amp; Tobago">Trinidad &amp; Tobago</option>
                          <option value="Tunisia">Tunisia</option>
                          <option value="Turkey">Turkey</option>
                          <option value="Turkmenistan">Turkmenistan</option>
                          <option value="Turks &amp; Caicos Is">Turks &amp; Caicos Is</option>
                          <option value="Tuvalu">Tuvalu</option>
                          <option value="Uganda">Uganda</option>
                          <option value="Ukraine">Ukraine</option>
                          <option value="United Arab Erimates">United Arab Emirates</option>
                          <option value="United Kingdom">United Kingdom</option>
                          <option value="United States of America">United States of America</option>
                          <option value="Uraguay">Uruguay</option>
                          <option value="Uzbekistan">Uzbekistan</option>
                          <option value="Vanuatu">Vanuatu</option>
                          <option value="Vatican City State">Vatican City State</option>
                          <option value="Venezuela">Venezuela</option>
                          <option value="Vietnam">Vietnam</option>
                          <option value="Virgin Islands (Brit)">Virgin Islands (Brit)</option>
                          <option value="Virgin Islands (USA)">Virgin Islands (USA)</option>
                          <option value="Wake Island">Wake Island</option>
                          <option value="Wallis &amp; Futana Is">Wallis &amp; Futana Is</option>
                          <option value="Yemen">Yemen</option>
                          <option value="Zaire">Zaire</option>
                          <option value="Zambia">Zambia</option>
                          <option value="Zimbabwe">Zimbabwe</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Gender"><span>*</span> Gender:</label>
                        <select class="form-control fild10" name="gender">
                          <option value="">Select  an option </option>
                          <option value="Male">Male</option>
                          <option value="Female">Female</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-4">
                      <div class="form-group">
                        <label for="Last Grade Completed"><span>*</span> Last Grade Completed:</label>
                        <select class="form-control fild10" name="last_grade_completed">
                          <option value="">Select  an option </option>
                          <option value="playgroup" class="option">Playgroup</option>
                          <option value="nursery1/preschool" class="option">Nursery1/Preschool</option>
                          <option value="nursery2/pre-kindergarten" class="option">Nursery1/Pre-kindergarten</option>
                          <option value="class1/kindergarten" class="option">Class1/KindergartenSvg</option>
                          <option value="class2/grade1" class="option">Class2/Grade1</option>
                          <option value="class3/grade2" class="option">Class3/Grade2</option>
                          <option value="class4/grade3" class="option">Class4/Grade3</option>
                          <option value="class5/grade4" class="option">Class5/Grade4</option>
                          <option value="class6/grade5" class="option">Class6/Grade5</option>
                          <option value="jss1/grade6" class="option">JSS1/Grade6</option>
                          <option value="jss2/grade7" class="option">JSS2/Grade7</option>
                          <option value="jss3/grade8" class="option">JSS3/Grade8</option>
                          <option value="sss1/grade9" class="option">SSS1/Grade9</option>
                          <option value="sss2/grade10" class="option">SSS2/Grade10</option>
                          <option value="sss3/grade11" class="option">SSS3/Grade11</option>
                          <option value="a-level/grade12" class="option">Alevel/Grade12</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Name of Last School Attended"><span>*</span> Name of Last School Attended:</label>
                        <input type="text" name="name_of_last_school_attended" class="form-control fild10" placeholder="Name of Last School Attended">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Grade applied for in Danbo"><span>*</span> Grade applied for in Danbo:</label>
                        <select class="form-control fild10" name="grade_applied_for_in_danbo">
                          <option value="">Select  an option </option>
                          <option value="playgroup" class="option">Playgroup</option>
                          <option value="nursery1/preschool" class="option">Nursery1/Preschool</option>
                          <option value="nursery2/pre-kindergarten" class="option">Nursery1/Pre-kindergarten</option>
                          <option value="class1/kindergarten" class="option">Class1/KindergartenSvg</option>
                          <option value="class2/grade1" class="option">Class2/Grade1</option>
                          <option value="class3/grade2" class="option">Class3/Grade2</option>
                          <option value="class4/grade3" class="option">Class4/Grade3</option>
                          <option value="class5/grade4" class="option">Class5/Grade4</option>
                          <option value="class6/grade5" class="option">Class6/Grade5</option>
                          <option value="jss1/grade6" class="option">JSS1/Grade6</option>
                          <option value="jss2/grade7" class="option">JSS2/Grade7</option>
                          <option value="jss3/grade8" class="option">JSS3/Grade8</option>
                          <option value="sss1/grade9" class="option">SSS1/Grade9</option>
                          <option value="sss2/grade10" class="option">SSS2/Grade10</option>
                          <option value="sss3/grade11" class="option">SSS3/Grade11</option>
                          <option value="a-level/grade12" class="option">Alevel/Grade12</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Child's First language"><span>*</span> Child's First language:</label>
                        <input type="text" class="form-control fild10" name="childs_first_language" placeholder="Child's First language">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Does your child have any disability"><span>*</span> Does your child have any disability?</label>
                        <input type="radio" name="difficulty" value="Yes"  required>
                        Yes <br>
                        <input type="radio" name="difficulty" value="No" required>
                        No </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Address"><span>*</span> Address:</label>
                        <textarea  name="address" class="form-control" rows="2" required>
            </textarea>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Date of Birth"><span>*</span> Date of Birth:</label>
                        <input type="date" name="date_of_birth" class="form-control fild10">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1"> Application ID:</label>
                        <input disabled type="text" name="application_id" value="<?php echo $appid;?>" class="form-control fild10">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="exampleInputFile"><span>*</span>Photo Upload</label>
                        <input type="file" required name="imagestyu" id="imagestyu">
                      </div>
                    </div>
                    <h4>Parent's Information</h4>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's Name"><span>*</span> Father's Name:</label>
                        <input type="text" required class="form-control fild10" name="fathers_name" placeholder="Father's Name">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Name"><span>*</span> Mother's Name:</label>
                        <input type="text" class="form-control fild10" name="mothers_name" placeholder="Mother's Name">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's Occupation"><span>*</span> Father's Occupation:</label>
                        <input type="text" class="form-control fild10" name="fathers_occupation" placeholder="Father's Occupation">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Occupation"><span>*</span> Mother's Occupation:</label>
                        <input type="text" class="form-control fild10" name="mothers_occupation" placeholder="Mother's Occupation">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's Email"><span>*</span> Father's Email:</label>
                        <input type="email" required class="form-control fild10" name="fathers_email" placeholder="Father's Email">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Email"><span>*</span> Mother's Email:</label>
                        <input type="email" required class="form-control fild10" name="mothers_email" placeholder="Mother's Email">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Fathers's Phone Number"><span>*</span> Fathers's Phone Number:</label>
                        <input type="text" required class="form-control fild10" name="fatherss_phone_number" placeholder="Fathers's Phone Number">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's Phone Number"><span>*</span> Mother's Phone Number:</label>
                        <input type="text" class="form-control fild10" name="mothers_phone_number" placeholder="Mother's Phone Number">
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Father's House Address"><span>*</span> Father's House Address:</label>
                        <textarea rows="2" cols="1" name="fathers_house_address" class="form-control" placeholder="House Number, Street Address, State " required>
        </textarea>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="Mother's House Address"><span>*</span> Mother's House Address:</label>
                        <textarea rows="2" cols="1" name="mothers_house_address" class="form-control" placeholder="House Number, Street Address, State " required>
            </textarea>
                      </div>
                    </div>
                    <button type="submit" class="btn btn-default review">submit</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php get_footer(); ?>