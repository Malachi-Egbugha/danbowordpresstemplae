<?php
/**
 * Template Name: Teacher Register
 */

get_header(); 

$msg='';

//$reg_status = 'as';
$_SESSION['reg_status'] = "";
if(isset($_POST['register']) && $_POST['register']=='Register') {
	global $wpdb;
	$name = $wpdb->escape($_REQUEST['FirstName']);
	$lastname = $wpdb->escape($_REQUEST['LastName']);
	$email = $wpdb->escape($_REQUEST['temail']);
	
	$password = $wpdb->escape($_REQUEST['_password']);
	$exists = email_exists( $email );
	if ( !$exists ) {
		$userdata = array(
			'first_name'  =>  $name,
    		'user_email'  =>  $email,
			'user_login'  =>  $email,
    		'user_pass'   =>  $password,
			'last_name'   =>  $lastname,
			'role'	 	  => 'teacher'
			
		);
		
		$user_id = wp_insert_user( $userdata ) ;
		//On success
		if ( ! is_wp_error( $user_id ) ) {
			 $_SESSION['reg_status'] = "success";
   		 $msg= "<h4 class='mesg'>Registration Successfull </h4>";	
		header( 'Location:' . home_url('/my-account/'));
		
		}


	}else{
		 $msg= "<h4 class='mesg'>That E-mail doesn't belong to any registered users on this site</h4>";	
	}

		
//wp_redirect('/my-account/');		
}


















?>
<style>
.mesg{color: #31316b;margin-left: 89px;}
</style>





<main>
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
   <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
	<?php } else {?>
	 <div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>
        <!-- about -->
       <div class="aboutin">
            <div class="container-fluid">
			<div class="maxw">
			<div class="row">
			<div class="col-lg-12">
			<div class="abarea teach-login">
                <div class="row">
                    
                    <div id="login-column" class="col-md-7">
                        <div id="login-box" class="col-md-12">
                            <?php echo $msg;?>
						 
				<form action="" method="post" enctype="multipart/form-data" class="form">   
			   <input type="hidden" name="register" value="Register">
                                <h3 class="text-center text-info">Parent Register</h3>
                                <div class="form-group">
                                    <label for="username" class="text-info">First Name:</label><br>
                                    <input type="text" name="FirstName" id="username" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="dob" class="text-info">Last Name:</label><br>
                                    <input type="text" name="LastName" id="dob" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="email" class="text-info">Email Address:</label><br>
                                    <input type="email" name="temail" id="email" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="password" class="text-info">Password:</label><br>
                                    <input type="password" name="_password" id="password" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="btn btn-info btn-md" value="Register">
                                </div>
                                <div id="register-link" class="text-right">
                                    <a href="<?php echo home_url('/login/'); ?>" class="text-info">Already have account ? Log in</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
			</div>
			</div>
			</div>
			</div>
        </div>
		</div>
        <!-- end about -->



    </main>























<?php


get_footer(); ?>