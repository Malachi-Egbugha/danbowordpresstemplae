<?php
/**
 * Template Name: Student_Portal
 */

session_start();
error_reporting(0);
require_once("includes/auth.php"); 
$check = new User($_SESSION['role'],$_SESSION['status']);
$check->auth();
$check-> checkuser();
get_header();

?>
<div class="container" style="margin-top: 10px;margin-bottom:10px">
<div class="row portal">
  <div class="col-sm-2">
    <div class="card">
  <a href="https://classroom.google.com" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/class.png" alt="Card image cap"></a>
 
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://zoom.us/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/zoom.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://hangouts.google.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/hangout1.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://danbocollege.fedena.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/fedena.png" alt="Card image cap"></a>
 
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="http://danboschools.com/sixthformresult/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/sixthform.png" alt="Card image cap"></a>
 
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="http://chemguide.co.uk/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/chemguide.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  
</div>

<!--second row--->
<div class="row portal">
  <div class="col-sm-2">
    <div class="card">
  <a href="https://open.umn.edu/opentextbooks/textbooks/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/opentext.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://igcsebookshop.co.uk" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/igcse.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://www.classdojo.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/dojo.png" alt="Card image cap"></a>
 
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://mail.google.com" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/gmail.png" alt="Card image cap"></a>
  
</div>
    
  </div>
   <div class="col-sm-2">
    <div class="card">
  <a href="https://calendar.google.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/calendar2.png" alt="Card image cap"></a>
 
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://chat.google.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/chats.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  
</div>
<!-- third row-->
<div class="row portal">
 
  <div class="col-sm-2">
    <div class="card">
  <a href="https://drive.google.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/drive1.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  
  <div class="col-sm-2">
    <div class="card">
  <a href="https://docs.google.com/spreadsheets/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/sheets1.png" alt="Card image cap"></a>
 
</div>
    
  </div>
  <div class="col-sm-2">
    <div class="card">
  <a href="https://meet.google.com/" target="_blank"><img class="card-img-top" src="<?php echo get_template_directory_uri(); ?>/img/portal/meets.png" alt="Card image cap"></a>
  
</div>
    
  </div>
  
</div>

</div>
<?php

get_footer(); 


?>