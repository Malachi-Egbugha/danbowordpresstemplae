<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<div class="col-lg-3">
  <div class="abright">
	<h4>Early Years</h4>
	<ul>
	  <li class="<?php if(is_page('welcome-message')){ echo 'active';}?>"><a href="<?php echo home_url('/welcome-message/'); ?>"><?php echo get_the_title(341); ?></a></li>
	  <li class="<?php if(is_page('curriculum')){ echo 'active';}?>"><a href="<?php echo home_url('/curriculum/'); ?>"><?php echo get_the_title(344); ?> </a></li>
	  <li class="<?php if(is_page('co-curricular-activities')){ echo 'active';}?>"><a href="<?php echo home_url('/co-curricular-activities/'); ?>"><?php echo get_the_title(350); ?></a> </li>
	  <li class="<?php if(is_page('program')){ echo 'active';}?>"><a href="<?php echo home_url('/program/'); ?>"><?php echo get_the_title(348); ?></a> </li>
	  <li class="<?php if(is_page('assessment-and-reporting')){ echo 'active';}?>"><a href="<?php echo home_url('/assessment-and-reporting/'); ?>"><?php echo get_the_title(355); ?></a> </li>
	    <li class="<?php if(is_page('school-times-schedule')){ echo 'active';}?>"><a href="<?php echo home_url('/school-times-schedule/'); ?>"><?php echo get_the_title(358); ?></a> </li>
	    <li class="<?php if(is_page('our-facilities')){ echo 'active';}?>"><a href="<?php echo home_url('/our-facilities/'); ?>"><?php echo get_the_title(361); ?></a> </li>
	  <li class="<?php if(is_page('events-special-days')){ echo 'active';}?>"><a href="<?php echo home_url('/events-special-days/'); ?>"><?php echo get_the_title(364); ?></a> </li>
	  <li class="<?php if(is_page('admission-process')){ echo 'active';}?>"><a href="<?php echo home_url('/admission-process/'); ?>"><?php echo get_the_title(368); ?></a> </li>
	  
	</ul>
  </div>
</div>
