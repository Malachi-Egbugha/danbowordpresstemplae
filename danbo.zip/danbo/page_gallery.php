<?php
/**
 * Template Name: Gallery
 */

get_header(); ?>
<main> 
  
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">GALLERY</h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
  <!-- Our gallery -->
  <div class="gallery">
    <div class="container-fluid">
      <div class="maxw">
        <div id="filters" class="galleryFilterBtn button-group">
          <button class="btn is-checked" data-filter="*">All</button>
		  
		  <?php 
			$wcatTerms = get_terms('gallery_cat', array('hide_empty' => 0, 'number' => 6,'parent' =>0)); 
			foreach($wcatTerms as $wcatTerm) :
		  ?>
		  
		  <button class="btn" data-filter=".<?php echo $wcatTerm->slug; ?>"><?php echo $wcatTerm->name; ?></button>
		  
		   <?php endforeach ;  ?>
		  
        </div>
        <div class="grid galleryGrid row no-gutters">
          
		  
		  <?php 
				$wcatTerms1 = get_terms('gallery_cat', array('hide_empty' => 0, 'number' => 6, 'order' =>'asc', 'parent' =>0));
				foreach($wcatTerms1 as $wcatTerm1) : 
			?>
			<?php
                    $args = array(
                        'post_type' => 'galleries',
                        'order' => 'ASC',
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'gallery_cat',
                                'field' => 'slug',
                                'terms' => $wcatTerm1->slug,
                            )
                        ),
                        'posts_per_page' => -1
                    );
                    $loop = new WP_Query( $args );
                    while ( $loop->have_posts() ) : $loop->the_post();
                    $imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
                    $title=get_the_title($loop->post->ID);
					
					$showHide=get_field('show__hide',$loop->post->ID);
					$youTube=get_field('youtube_link',$loop->post->ID);
					$File=get_field('video_file',$loop->post->ID);
                ?>
		  
		  
				  <div class="col-md-4 grid-item <?php echo $wcatTerm1->slug; ?>">
				  <?php if($showHide==1){?>
					<div class="item"> 
						<iframe width="560" height="315" src="<?php echo $youTube;?>" frameborder="0" allow="accelerometer; autoplay=0; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
					</div>
				  <?php } else if($showHide==2) { ?>
				  <div class="item"> 
					<video width="400" controls>
					  <source src="<?php echo $File;?>" type="video/mp4">
					</video>
					</div>
				  <?php } else { ?>
				  <div class="item"> 
						<img src="<?php echo $imgurl;?>" alt="" class="img-fluid"> 
						<a class="lightBox fancybox" rel="ligthbox" href="<?php echo $imgurl;?>">
						<i class="fa fa-search"></i> </a> 
					</div>
				  
				  <?php } ?>
				  
				  </div>
		  
		  
		  <?php endwhile; wp_reset_postdata(); ?> 
			
			<?php endforeach;  ?>   
		  
		  
        </div>
      </div>
    </div>
  </div>
  <!-- end Our gallery --> 
  
   <!-- Our Join  -->
  <div class="join">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-3 col-md-4">
            <h3><?php echo get_field('join_with_us',20);?></h3>
          </div>
          <div class="col-lg-7 col-md-6">
            <p><?php echo get_field('join_with_us_content',20);?></p>
          </div>
          <div class="col-lg-2 col-md-2"> <a href="<?php echo get_field('join_with_us_link',20);?>" class="joinus">Join us</a> </div>
        </div>
      </div>
    </div>
  </div>
</main>
<?php get_footer(); ?>
<?php


//get_footer(); ?>
<!--<footer> 
  
  <div class="footer">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 col-md-8">
            <h4>Get in touch</h4>
            <div class="foot-a"><samp><i class="fa fa-map-marker" aria-hidden="true"></i> </samp><?php the_field('address','option'); ?> 
              <div class="clearfix"></div>
            </div>
            <div class="foot-a"><samp><i class="fa fa-phone" aria-hidden="true"></i> </samp><span><strong><?php the_field('phone','option'); ?></strong></span> <span><strong><?php the_field('phone_number','option'); ?> </strong></span>
              <div class="clearfix"></div>
            </div>
            <div class="foot-a"><samp><i class="fa fa-envelope-o" aria-hidden="true"></i> </samp><span><a href="mailto:<?php the_field('email_id','option'); ?> "><?php the_field('email_id','option'); ?> </a> | <a href="mailto:<?php the_field('email_2','option'); ?> "><?php the_field('email_2','option'); ?> </a></span>
              <div class="clearfix"></div>
            </div>
          </div>
          <div class="col-lg-3 col-md-4 col-sm-6">
            <h4>Quicklinks</h4>
            <ul>
              <li class="active"><a href="<?php echo home_url('');?>">Home</a></li>
              <li><a href="<?php echo home_url('/about-us');?>">About Us</a></li>
              <li><a href="<?php echo home_url('/kaduna-school');?>">Our School</a></li>
              <li><a href="<?php echo home_url('/school-life');?>">School Life</a></li>
              <li><a href="<?php echo home_url('/addmision');?>">Admissions</a></li>
            </ul>
            <ul>
              <li><a href="<?php echo home_url('/dis-portal');?>">Dis Portal</a></li>
              <li><a href="<?php echo home_url('/community');?>">Community</a></li>
              <li><a href="<?php echo home_url('/school-shop');?>">School Shop</a></li>
              <li><a href="<?php echo home_url('/gallery');?>">Gallery</a></li>
              <li><a href="<?php echo home_url('/blog');?>">Blog</a></li>
            </ul>
          </div>
          <div class="col-lg-3 col-sm-6">
            <h4>Find us</h4>
            <div class="map">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3923.357920332942!2d7.432675114798159!3d10.472424792528258!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104d35890d3dc4a5%3A0x2a20f7bcaad3f26d!2s28%20Kubani%20Crescent%2C%20Barnawa%2C%20Kaduna%2C%20Nigeria!5e0!3m2!1sen!2sin!4v1593407222042!5m2!1sen!2sin" width="100%" height="190px" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
            <div class="social">
               <ul>
				  <?php if( have_rows('social','option') ): ?>
					<?php 
					while( have_rows('social','option') ): the_row(); 

					// vars
					$logo = get_sub_field('social_logo');
					$link = get_sub_field('social_link');

					?>
                <li><a href="<?php echo $link;?>" target="_blank"><i class="fa fa-<?php echo $logo;?>" aria-hidden="true"></i></a></li>
				  <?php endwhile; ?>
					<?php endif; ?>

              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="copy">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-12">
            <h6><a href="#">Danbo International Schools ICT</a> © 2020</h6>
          </div>
        </div>
      </div>
    </div>
  </div>
  
</footer>--!>

<!-- Bootstrap core JavaScript
    ================================================== --> 
<!-- Placed at the end of the document so the pages load faster --> 

<!-- Gallery Isotop --> 
<!--<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/js/isotope.pkgd.min.js"></script> 
<script>
  jQuery(document).ready(function($){
    
    var $grid = $('.grid').isotope({
      itemSelector: '.grid-item',
      percentPosition: true,
      masonry: {
        //columnWidth: 100,
        // use outer width of grid—size; for columnWidth
        columnWidth: '.grid-item',
        gutter: 0
        }
  });

  // filter functions
  var filterFns = {
    // show if number is greater than 50
    numberGreaterThan50: function() {
      var number = $(this).find('.number').text();
      return parseInt( number, 10 ) > 50;
    },
    // show if name ends with -ium
    ium: function() {
      var name = $(this).find('.name').text();
      return name.match( /ium$/ );
    }
  };

  // bind filter button click
  $('#filters').on( 'click', 'button', function() {
    var filterValue = $( this ).attr('data-filter');
    // use filterFn if matches value
    filterValue = filterFns[ filterValue ] || filterValue;
    $grid.isotope({ filter: filterValue });
  });

  $('.galleryFilterBtn button').click(function(){
      $('.galleryFilterBtn button').removeClass("is-checked");
      $(this).addClass("is-checked");
  });
})
</script> --!
<!-- End Gallery Isotop --> 


<!--<script src="<?php echo get_template_directory_uri(); ?>/js/grid-gallery.min.js"></script> 
<script>
    gridGallery({
      selector: ".dark",
      darkMode: true
    });
    
    </script> -->


</body>
</html>
