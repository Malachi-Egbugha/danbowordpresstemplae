<?php
/**
 * Template Name: Why choose us
 */

get_header(); ?>
<main> 
  
  <!-- about -->
 
    
<?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
            
			
			 <?php include('sidebar-about.php'); ?>
			
			
            <div class="col-lg-9">
              <div class="abarea clearfix">
                <h3>Why choose us</h3>
               <div class="choose p-0">
        
		
		
		<?php
			$args = array( 'post_type' => 'why_choose_us', 'posts_per_page' => -1, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$p = 1;
			while ( $loop->have_posts() ) : $loop->the_post(); global $product;
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
		  
       
		<style>
		.choose .exper-<?php echo $p; ?>{ background:url(<?php echo $imgurl;?>) no-repeat 0px 0px; transition:all .3s ease-in-out;}

.choose .exper:hover .exper-<?php echo $p; ?>{ background:url(<?php echo $imgurl;?>) no-repeat; transition:all .3s ease-in-out;}
		</style>
		
		 <div class="exper wow fadeInLeft" data-wow-duration="2s" data-wow-delay="1.5s">
          <div class="exper-<?php echo $p; ?>"></div>
          <h4><?php echo $title;?></h4>
          <p><?php echo $getcontent;?></p>
        </div>
		 <?php $p++; endwhile; wp_reset_postdata(); ?> 
		
        
		
		
     </div>
              </div>
            </div>
			
			
			
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php get_footer(); ?>
