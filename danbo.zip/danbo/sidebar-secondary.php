<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
?>

<div class="col-lg-3">
  <div class="abright">
	<h4>Secondary</h4>
	<ul>
	  <li class="<?php if(is_page(683)){ echo 'active';}?>">
		<a href="<?php echo home_url('/secondary-header1/'); ?>">Header 1</a>
	  </li>
	  
	  <li class="<?php if(is_page(685)){ echo 'active';}?>">
		<a href="<?php echo home_url('/secondary-header2/'); ?>">Header 2</a>
	  </li>
	  
	  <li class="<?php if(is_page(687)){ echo 'active';}?>">
		<a href="<?php echo home_url('/secondary-header3/'); ?>">Header 3</a>
	  </li>
	  
	  </ul>
  </div>
</div>
