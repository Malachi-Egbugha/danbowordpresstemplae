<?php


 ?>
 
 
 <!-- Our Admission -->
  <div class="admission abbmiss" id="applynow">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row pl-5 pr-5">
          <div class="col-lg-5 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo get_template_directory_uri(); ?>/img/admission.jpg"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-5 pt-5 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <h3>We educate children in a pioneering and exciting environment </h3>
            <p>Danbo International School 2020/2021 admission process is now open!!! We are now accepting online applications forms.</p>
            <a href="#" class="apply" data-toggle="modal" data-target="#myModal">Apply Now</a> </div>
        </div>
      </div>
    </div>
  </div>
  
  
  
  
  
  
  
  
<!-- The Modal -->
<div class="modal admissionfrom clearfix" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content"> 
      
      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
      <!-- Modal body -->
      <div class="modal-body admiss">
        <div class="admiss">
          <h3>Begin Your Registration for the 2020/2021 entrance examination </h3>
          <?php echo $msg;?>
		  <form id="form1" action="<?php echo get_page_link(388);?>" method="post" enctype="multipart/form-data">
		   <input type="hidden" name="register" value="Register">
            <div class="form-group fild2">
              <input type="text" class="form-control fild3" name="FirstName1" placeholder="First Name">
            </div>
            <div class="form-group fild2 fild4">
              <input type="text" class="form-control fild3" name="LastName" placeholder="Last Name">
            </div>
            <div class="form-group fild2">
              <input type="text" class="form-control fild3" name="phone_no" placeholder="Phone">
            </div>
            <div class="form-group fild2 fild4">
              <input type="email" class="form-control fild3" name="temail" placeholder="Email">
            </div>
            <!--<div class="form-group">
              <textarea class="form-control fild5" rows="3" name="address" placeholder="Message"></textarea>
            </div>-->
			<div class="form-group" style="display:none;" >
					<label for="password" class="text-info">APPID:</label><br>
					<input type="text" name="appid" value="<?php echo "DIS/APPID/2020/".rand(1000, 9999) . rand(1000, 9999);?>" id="password" class="form-control">
				</div>
				
				 <div class="form-group" style="display:none;">
					<label for="password" class="text-info">Password:</label><br>
					<input type="password" name="_password" value="<?php echo(rand());?>" id="password" class="form-control">
				</div>
            <button type="submit" class="btn btn-default submit">BEGIN REGISTRATION</button>
          </form>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
</div>  











<div class="modal admissionfrom clearfix" id="myModal2">
  <div class="modal-dialog">
    <div class="modal-content"> 
      
    
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      
     
      <div class="modal-body admiss">
        <div class="admiss">
          <h3>Welcome</h3>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
</div> 
















  

 