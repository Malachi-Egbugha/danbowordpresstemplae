<?php
/**
 * Template Name: Admission
 */

get_header(); 

?>
<main> 
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
 <?php include('applyNowSide.php');?>
<?php
          while ( have_posts() ) : the_post();
		$image=wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full'); 
         ?> 
  <!-- Our Curriculum Framework -->
  <div class="frame">
    <div class="row">
      <div class="col-lg-5">
        <div class="framel">
          <?php the_content();?>
          <div class="clearfix"></div>
        </div>
      </div>
      <div class="col-lg-7 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
        <div class="frame-img" style="background:url(<?php echo $image[0]; ?>);"></div>
      </div>
    </div>
  </div>
  <!-- end Our Curriculum Framework --> 
 	<?php endwhile;  ?>  
</main>

<?php get_footer(); ?>