<?php
/**
 * Template Name: Student Register
 */
acf_form_head();
get_header(); 

$msg='';

//$reg_status = 'as';
$_SESSION['reg_status'] = "";
if(isset($_POST['register']) && $_POST['register']=='Register') {
	global $wpdb;
	$name = $wpdb->escape($_REQUEST['FirstName']);
	$lastname = $wpdb->escape($_REQUEST['LastName']);
	$email = $wpdb->escape($_REQUEST['temail']);
	$class = $wpdb->escape($_REQUEST['myclass']);
	
	$password = $wpdb->escape($_REQUEST['_password']);
	$exists = email_exists( $email );
	if ( !$exists ) {
		$userdata = array(
			'first_name'  =>  $name,
    		'user_email'  =>  $email,
			'user_login'  =>  $email,
			'uploader'    => 'basic',
    		'user_pass'   =>  $password,
			'last_name'   =>  $lastname,
			'role'	 	  => 'student'
			
		);
		
		
		$user_id = wp_insert_user( $userdata ) ;
		//On success
		//update_post_meta($user_id, 'field_5f3120b16ed01', $class );
		
		//update_field('field_5f3120b16ed01', $_POST['field_5f3120b16ed01'], $userdata );
		//add_post_meta( $user_id, 'school_class', $class);
		add_user_meta( $user_id, 'student_class', $class);
		
		// Image upload query
		if ( ! function_exists( 'wp_handle_upload' ) ) 
		{
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
			require_once( ABSPATH . 'wp-admin/includes/media.php' );
		}  
		
		// if($_FILES['simage']['name'] != ''){
          // $uploadedfile = $_FILES['simage'];
          // $upload_overrides = array( 'test_form' => false );

          // $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );

          // $imageurl = "";
          // if ( $movefile && ! isset( $movefile['error'] ) ) {
             // $imageurl = $movefile['url'];
             // $file_upload_path = $imageurl;
          // }
      // }
	  // add_user_meta( $user_id, 'simage', $file_upload_path);
	  
	  
	  $attachment_id = media_handle_upload( 'imagestyu', $user_id );
     
    if ( is_wp_error( $attachment_id ) ) {
       //There was an error uploading the image.
    } else {
      // echo "success"; 
	   add_user_meta( $user_id, 'imagestyu', $attachment_id);
    }
		
		//end query
		
		
		if ( ! is_wp_error( $user_id ) ) {
			 $_SESSION['reg_status'] = "success";
   		 $msg= "<h4 class='mesg'>Registration Successfull </h4>";	
		header( 'Location:' . home_url('/my-account/'));
		
		}


	}else{
		 $msg= "<h4 class='mesg'>That E-mail doesn't belong to any registered users on this site</h4>";	
	}

		
//wp_redirect('/my-account/');		
}


















?>
<style>
.mesg{color: #fff;margin-left: 89px;}
</style>





<main>
 <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
   <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
	<?php } else {?>
	 <div class="about-bg" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>
        <!-- about -->
       
            <div class="container">
                <div class="row">
                    <div class="col-md-7"></div>
                    <div id="login-column" class="col-md-5">
                        <div id="login-box" class="col-md-12">
                            <?php echo $msg;?>
						 
				<form action="" method="post" enctype="multipart/form-data" class="form">   
			   <input type="hidden" name="register" value="Register">
                                <h3 class="text-center text-info">Student Register</h3>
                                <div class="form-group">
                                    <label for="username" class="text-info">Image</label><br>
                                    <input type="file" name="imagestyu" id="imagestyu" class="form-control">
                                </div>
								
								<div class="form-group">
                                    <label for="username" class="text-info">First Name:</label><br>
                                    <input type="text" name="FirstName" id="username" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="dob" class="text-info">Last Name:</label><br>
                                    <input type="text" name="LastName" id="dob" class="form-control">
                                </div>
								<div class="form-group">
								  <label for="sel1">Select Class:</label>
								  <select class="form-control" id="sel1" name="student_class">
									<option value="V">V</option>
									<option value="VI">VI</option>
									<option value="VII">VII</option>
									<option value="VIII">VIII</option>
									<option value="IX">IX</option>
									<option value="X">X</option>
									<option value="XI">XI</option>
									<option value="XII">XII</option>
								  </select>
								</div>
                                <div class="form-group">
                                    <label for="email" class="text-info">Email Address:</label><br>
                                    <input type="email" name="temail" id="email" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="password" class="text-info">Password:</label><br>
                                    <input type="password" name="_password" id="password" class="form-control">
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="submit" class="btn btn-info btn-md" value="Register">
                                </div>
                                <div id="register-link" class="text-right">
                                    <a href="<?php echo home_url('/login/'); ?>" class="text-info">Already have account ? Log in</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end about -->



    </main>


<?php


get_footer(); ?>