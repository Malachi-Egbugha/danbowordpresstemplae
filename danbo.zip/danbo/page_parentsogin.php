<?php
/**
 * Template Name: Parents Login
 */

get_header();


$msg='';
if(isset($_POST['submit']) && $_POST['submit']=='Login')
{

global $wpdb;
$username = $wpdb->escape($_REQUEST['username']);
$password = $wpdb->escape($_REQUEST['password']);

$creds = array();
$creds['user_login'] = $username;
$creds['user_password'] =$password;

$user = wp_signon( $creds, false );

if ( is_wp_error($user) ){
$err=$user->get_error_message();
$msg= "Username or password error try again!";
}
else{
//print_r($user);	

$user_meta=get_userdata($user->ID);

$user_roles=$user_meta->roles;
//print_r($user_roles);
if($user_roles[0]=='parent'){
$_SESSION['parent_id']=$user->ID;
	
echo "<script type='text/javascript'>window.location.href='".home_url('/parent-dashboard/')."'</script>";  

}

//header( 'Location:' . home_url().'blog');// this will redirect to Home Page	
//wp_redirect( 'https://example.com/some/page' );  					
//exit();
}

}





// if($_POST) 
// {  
   
    // global $wpdb;  
   
   
    // $username = $wpdb->escape($_REQUEST['username']);  
    // $password = $wpdb->escape($_REQUEST['password']);  
    // $remember = $wpdb->escape($_REQUEST['rememberme']);  
   
    // if($remember) $remember = "true";  
    // else $remember = "false";  
   
    // $login_data = array();  
    // $login_data['user_login'] = $username;  
    // $login_data['user_password'] = $password;  
    // $login_data['remember'] = $remember;  
   
    // $user_verify = wp_signon( $login_data, false );   
   
    // if ( is_wp_error($user_verify) )   
    // {  
        // echo "Invalid login details";  
        
     // } else
    // {    
       // echo "<script type='text/javascript'>window.location.href='". home_url() ."'</script>";  
       // exit();  
     // }  
   
// } else 
// {  
   
    
   
// } 

















 ?>
<main> 
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/about-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">DIS Portal</h3>
        </div>
      </div>
    </div>
  </div>
	<?php } else {?>
	<div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s">DIS Portal</h3>
        </div>
      </div>
    </div>
  </div>
	<?php } ?>
  <!-- end about --> 
  <!-- Parents login -->
  <div class="admission parents">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-5 mr-2 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admissimg"><img src="<?php echo get_template_directory_uri(); ?>/img/admission1.jpg"  alt=" "></div>
          </div>
          <div class="col-lg-6 ml-2 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="admiss">
              <h3>Parents login</h3>
				<?php
				if ( $_SESSION['parent_id']!='' ) { ?>
   
				<a href="<?php echo home_url('/parent-dashboard/'); ?>"> Dashboard</a>
				<?php
				} else {
			  ?>
			    
			
               <p style="color:red"><?php echo $msg; ?></p>
			  <form method="post" action="">
                <div class="form-group">
                  <input type="email" class="form-control fild6"  name="username" placeholder="Email">
                </div>
                <div class="form-group">
                  <input type="password" class="form-control fild6" name="password" placeholder="Password">
                </div>
                <!--<button type="submit" class="btn btn-default submit">LOGIN</button>-->
				<input type="submit" name="submit" class="btn btn-default submit" value="<?php _e('Login'); ?>"/>
                <button type="submit" class="btn btn-default forgot">Forgot your password?</button>
              </form>
			  
				<?php } ?>
				<div id="register-link" class="text-right">
				<a href="<?php echo home_url('/parents-register/'); ?>" class="text-info">Create a account ? Sign up</a>
			</div>
              <div class="clearfix"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Parents login --> 
  
   <!-- DIS Portal -->
  <div class="dis app">
    <div class="container-fluid">
      <div class="maxw">
        <h3 class=" wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s"> Our staff</h3>
        <div class="row">
          
		 <?php
			$args = array( 'post_type' => 'our_staff', 'posts_per_page' => -1, 'order' => 'DESC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			
			while ( $loop->have_posts() ) : $loop->the_post(); 
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

		?>
		<div class="col-lg-3 col-md-3 col-sm-4 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <div class="staff">
            <div class="staffimg"><img src="<?php echo $imgurl;?>" alt=" "></div>
            <h4><?php echo $title;?></h4>
            <h6> <?php echo $getcontent;?></h6>
            </div>
          </div>
		  
			<?php  endwhile; wp_reset_postdata(); ?> 
		
		
		  
         
          
          
          
        </div>
      </div>
    </div>
  </div>
  <!-- end DIS Portal --> 
  
</main>

<?php


get_footer(); ?>


<script>



</script>





