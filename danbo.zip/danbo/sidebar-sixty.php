<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<div class="col-lg-3">
<div class="abright">
<h4>Sixth Form</h4>
<ul>
	<li class="<?php if(is_page(750)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(750); ?>"><?php echo "Welcome Message "; ?></a>
	</li>
	
	<li class="<?php if(is_page(759)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(759); ?>"><?php echo "Sixth Form Programmes"; ?></a>
	</li>
	
		<li class="<?php if(is_page(756)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(756); ?>"><?php echo "Curriculum Overview and Subjects "; ?></a>
	</li>
		<li class="<?php if(is_page(765)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(765); ?>"><?php echo "Co-curricular and Extra-curricular activities"; ?></a>
	</li>
	
	<li class="<?php if(is_page(752)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(752); ?>"><?php echo "Why Choose Danbo SixthForm?"; ?></a>
	</li>
	
	<li class="<?php if(is_page(768)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(768); ?>"><?php echo "Career Guidance and Counselling "; ?></a>
	</li>
	<li class="<?php if(is_page(777)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(777); ?>"><?php echo "Assessment and Reporting"; ?></a>
	</li>
	<li class="<?php if(is_page(774)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(774); ?>"><?php echo "Events/Special Days"; ?></a>
	</li>
	
	<li class="<?php if(is_page(771)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(771); ?>"><?php echo "Facilities "; ?></a>
	</li>
	<!--
	<li class="<?php if(is_page(941)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(941); ?>"><?php echo get_the_title(941); ?></a>
	</li>
	
	<li class="<?php if(is_page(784)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(784); ?>"><?php echo get_the_title(784); ?></a>
	</li>
	-->

  
</ul>
</div>
</div>