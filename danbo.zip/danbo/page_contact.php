<?php
/**
 * Template Name: Contact
 */

get_header(); ?>
<main> 
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about contact" style="background:url(<?php echo get_template_directory_uri(); ?>/img/contact-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">CONTACT US</h2>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	<div class="about contact" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">CONTACT US</h2>
        </div>
      </div>
    </div>
  </div>
	<?php } ?>
  
  <!-- Our Welcome -->
  <div class="contbg">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 col-md-7 wow fadeInRight" data-wow-duration="2s" data-wow-delay=".5s">
            <h4>Find Us Easy Way</h4>
            <div class="phone">
              <h5><i class="fa fa-mobile" aria-hidden="true"></i>Phone</h5>
              <h6><?php the_field('phone','option'); ?></h6>
              <h6><?php the_field('phone_number','option'); ?></h6>
              <div class="clearfix"></div>
            </div>
            <div class="phone">
              <h5><i class="fa fa-map-marker" aria-hidden="true"></i>Address</h5>
              <h6><?php the_field('address','option'); ?></h6>
              <div class="clearfix"></div>
            </div>
            <div class="phone">
              <h5><i class="fa fa-envelope-o" aria-hidden="true"></i>Email</h5>
              <h6><a href="mailto:<?php the_field('email_id','option'); ?>"><?php the_field('email_id','option'); ?></a> | <a href="mailto:<?php the_field('email_2','option'); ?>"><?php the_field('email_2','option'); ?></a></h6>
              <div class="clearfix"></div>
            </div>
          </div>
          <div class="col-lg-6 col-md-5 wow fadeInLeft" data-wow-duration="2s" data-wow-delay=".5s">
            <h4>Get In Touch</h4>
			  <?php echo do_shortcode('[contact-form-7 id="6" title="Contact form 1"]');?> 
<!--             <form> -->
<!--               <div class="form-group">
                <input type="text" class="form-control fild"  placeholder="Your Name">
              </div>
              <div class="form-group">
                <input type="email" class="form-control fild"  placeholder="Your Email">
              </div>
              <div class="form-group">
                <input type="text" class="form-control fild"  placeholder="Subject">
              </div>
              <div class="form-group">
                <textarea class="form-control fild1" rows="3" placeholder="How Can I Help You?"></textarea>
              </div>
              <button type="submit" class="btn btn-default send">Send Message</button> -->
<!--             </form> -->
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Welcome --> 
  
</main>
<?php


get_footer(); ?>