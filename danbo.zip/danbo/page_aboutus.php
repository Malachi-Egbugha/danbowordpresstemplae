<?php
/**
 * Template Name: About
 */

get_header(); ?>
<main> 
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
  <!-- Our Welcome -->
  <div class="awelcome">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6">
            <div class="aboutimg"><img src="<?php the_field('awards_and_laurels_image',13); ?>"  alt=" "></div>
          </div>
          <div class="col-lg-6 pl-5">
            <h3><?php the_field('welcome_to',13); ?></h3>
            <?php the_field('international_school_content',13); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Welcome --> 
  
  <!-- educational approach -->
  <div class="appro">
    <div class="container-fluid">
      <div class="maxw">
        <?php the_field('as_a_school_with_360',13); ?>
        <div class="row">
			<?php if( have_rows('our_curriculum_strategically',13) ): ?>
			<?php 
			while( have_rows('our_curriculum_strategically',13) ): the_row(); 

			// vars
			$title = get_sub_field('title');
			$image = get_sub_field('images');
			?>			
          <div class="col-lg-3 col-md-6 col-sm-6">
            <div class="our">
              <div class="ourimg"><img src="<?php echo $image;?>"  alt=" "></div>
              <h6><?php echo $title;?></h6>
            </div>
          </div>
			<?php endwhile; ?>
			<?php endif; ?>
			

			
			
        </div>
      </div>
    </div>
  </div>
  <!-- end educational approach --> 
  
  <!-- Our Sixthform -->
  <div class="sixth">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
          <div class="col-lg-6 pr-5">
            <?php the_field('after_our_curriculum_content',13); ?> 
          </div>
          <div class="col-lg-6">
            <div class="sixthimg"><img src="<?php the_field('after_our_curriculum_image',13); ?> "  alt=" "></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Sixthform --> 
  
  <!-- Our A Glance -->
  <div class="glance">
    <div class="container-fluid">
      <div class="maxw">
        <h3> <?php the_field('our_school_at_a_glance_title',13); ?> </h3>
        <div class="row">
        
		<?php if( have_rows('our_school_at_a_glance',13) ): ?>
			<?php 
			while( have_rows('our_school_at_a_glance',13) ): the_row(); 

			// vars
			$title1 = get_sub_field('our_school');
			$image1 = get_sub_field('our_school_image');
			$num = get_sub_field('our_school_number');
			?>			
          <div class="col-lg-3 col-md-3 col-sm-6 col-6">
            <div class="glan">
              <div class="glanimg"><img src="<?php echo $image1;?>" alt=" "></div>
              <h4><?php echo $num;?></h4>
              <h4><?php echo $title1;?></h4>
            </div>
          </div>
			<?php endwhile; ?>
			<?php endif; ?>
		
		
		
		  
          
		 
		  
		  
        </div>
      </div>
    </div>
  </div>
  <!-- end Our A Glance --> 
  
  <!-- Our Awards -->
  <div class="values">
    <div class="row">
      <div class="col-lg-5">
        <div class="valul-img" style="background:url(<?php the_field('international_school_image',13); ?> "></div>
      </div>
      <div class="col-lg-7">
        <div class="valul">
          <h3>Awards And Laurels</h3>
          <ul>
			  <?php if( have_rows('awards_and_laurels',13) ): ?>
			  <?php 
			  while( have_rows('awards_and_laurels',13) ): the_row(); 

			  // vars
			  $content = get_sub_field('content');

			  ?>
            <li><?php echo $content;?></li>
			<?php endwhile; ?>
			<?php endif; ?>

          </ul>
          <div class="clearfix"></div>
        </div>
      </div>
    </div>
  </div>
  <!-- end Our Awards --> 
  
  <!-- Our Parents Say -->
  <div class="parent">
    <div class="container-fluid">
      <div class="maxw">
        <h3>What Our Parents Say</h3>
        <div id="testimonial-slider" class="owl-carousel">
			<?php
			$args = array( 'post_type' => 'our_parents', 'posts_per_page' => 3, 'order' => 'ASC','orderby' => 'ID','product_cat' => '' );
			$loop = new WP_Query( $args );
			$p=1;
			while ( $loop->have_posts() ) : $loop->the_post();
			$imgurl = get_the_post_thumbnail_url( get_the_ID(), 'full' );
			$title=get_the_title();
			$getcontent=get_the_content();

			?>
			<?php if($p==1){?>
          <div class="testimonial">
            <p class="description"> <?php echo $getcontent;?></p>
            <h3 class="title"><?php echo $title;?></h3>
          </div>
		  
			<?php } else { ?>
			<div class="testimonial">
            <p class="description"> <?php echo $getcontent;?></p>
            <h3 class="title"><?php echo $title;?></h3>
          </div>
			
			<?php } ?>
		  
		  
			<?php  $p++; endwhile; wp_reset_postdata(); ?> 

        </div>
      </div>
    </div>
  </div>
  <!-- end Our Parents Say --> 
  
</main>

<?php get_footer(); ?>

