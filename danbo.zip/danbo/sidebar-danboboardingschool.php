<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
?>

<div class="col-lg-3">
  <div class="abright">
	<h4 id="boarding">Danbo Boarding School</h4>
	<ul>		   
	  <li class="<?php if(is_page(734)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(734); ?>"><?php echo get_the_title(734); ?></a>
	  </li>
	  
	  <li class="<?php if(is_page(736)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(736); ?>"><?php echo get_the_title(736); ?></a>
	  </li>
	   
	  <li class="<?php if(is_page(738)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(738); ?>"><?php echo get_the_title(738); ?></a>
	  </li>
	  
	  <li class="<?php if(is_page(1089)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1089); ?>"><?php echo get_the_title(1089); ?></a>
	  </li>
	  <li class="<?php if(is_page(1091)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1091); ?>"><?php echo get_the_title(1091); ?></a>
	  </li>
	  <li class="<?php if(is_page(1093)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1093); ?>"><?php echo get_the_title(1093); ?></a>
	  </li>
	   <!--
	  <li class="<?php if(is_page(1095)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1095); ?>"><?php echo get_the_title(1095); ?></a>
	  </li>
	 
	  <li class="<?php if(is_page(1097)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1097); ?>"><?php echo get_the_title(1097); ?></a>
	  </li>
	   
	  <li class="<?php if(is_page(1099)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1099); ?>"><?php echo get_the_title(1099); ?></a>
	  </li>
	 
	  <li class="<?php if(is_page(1101)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(1101); ?>"><?php echo get_the_title(1101); ?></a>
	  </li>
	  -->
	  
	  </ul>
  </div>
</div>
