<?php
/*
Template Name: Staff Access
*/
get_header();?>
<?php
if ( !is_user_logged_in() ) {
   echo "<script type='text/javascript'>window.location.href='". home_url('/staff-login/') ."'</script>";
} 
?>


 <main>
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <!-- about -->
  <div class="about" style="background:url(<?php echo get_template_directory_uri(); ?>/img/kaduna-bg.jpg);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	<?php } else {?>
	
	<!-- about -->
  <div class="about" style="background:url(<?php echo $bannerImage;?>);">
    <div class="container-fluid">
      <div class="maxw">
        <div class="abtext">
          <h2 class="wow fadeInDown" data-wow-duration="2s" data-wow-delay=".5s">DANBO INTERNATIONAL SCHOOL</h2>
          <h3 class="wow fadeInUp" data-wow-duration="2s" data-wow-delay=".5s"><?php the_title(); ?></h3>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
	
	<?php } ?>
  
 <!-- DIS Portal -->
  <div class="dis staffacces">
    <div class="container-fluid">
      <div class="maxw">
        <div class="row">
            <?php if( have_rows('staff_access',461) ): ?>
					<?php 
					$p=1;
					while( have_rows('staff_access',461) ): the_row(); 

					$title = get_sub_field('title');
					$content = get_sub_field('content');
					$images = get_sub_field('images');
					
					?>
          <div class="<?php if($p==1){ echo 'col-lg-6';} else if($p==2){echo 'col-lg-6 order-lg-1';} else if($p==3){echo 'col-lg-6 order-lg-2';}?>">
            <div class="aboutimg shadow"><img src="<?php echo $images;?>"  alt=" "></div>
          </div>
          <div class="<?php if($p==1){echo 'col-lg-6';} else if($p==2){echo 'col-lg-6 order-lg-0';} else if($p==3){echo 'col-lg-6 order-lg-3';}?>">
            <div class="stafftxt">
              <h3><?php echo $title;?></h3>
              <p><?php echo $content;?></p>
            </div>
          </div>
        
         
          <?php  $p++; endwhile; ?>
		<?php endif; ?>
          <!--<div class="col-lg-6 order-lg-2">-->
          <!--  <div class="aboutimg shadow"><img src="<?php echo get_template_directory_uri(); ?>/img/collage-img3.jpg"  alt=" "></div>-->
          <!--</div>-->
          <!--<div class="col-lg-6 order-lg-3">-->
          <!--  <div class="stafftxt">-->
          <!--    <h3>Instructional Policies for Teachers</h3>-->
          <!--    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in auctor leo, at maximus tellus. Vivamus vitae nisi in nibh congue pharetra quis ut massa.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in auctor leo, at maximus tellus. Vivamus vitae nisi in nibh congue pharetra quis ut massa.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in auctor leo, at maximus tellus. Vivamus vitae nisi in nibh congue pharetra quis ut massa.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed in auctor leo, at maximus tellus. Vivamus vitae nisi in nibh congue pharetra quis ut massa.</p>-->
          <!--  </div>-->
          <!--</div>-->
          
          
        </div>
      </div>
    </div>
  </div>
  <!-- end DIS Portal --> 
 
</main>
<?php get_footer(); ?>