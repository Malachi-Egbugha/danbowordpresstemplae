<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
 
?>

<div class="col-lg-3">
  <div class="abright">
	<h4>Secondary</h4>
	<ul>	
	<li class="<?php if(is_page(878)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(878); ?>"><?php echo "Welcome Message "; ?></a>
	  </li>
	  
	   <li class="<?php if(is_page(704)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(704); ?>"><?php echo "Secondary Programmes"; ?></a>
	  </li>
	  
	   <li class="<?php if(is_page(722)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(722); ?>"><?php echo "Curriculum and Subjects"; ?></a>
	  </li>
	  
	  <li class="<?php if(is_page(719)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(719); ?>"><?php echo "Co-curricular and Extra-curricular activities"; ?></a>
	  </li>
	  
	   <li class="<?php if(is_page(710)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(710); ?>"><?php echo "The Secondary Vision"; ?></a>
	  </li>
	   <li class="<?php if(is_page(730)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(730); ?>"><?php echo "Assessment and Reporting"; ?></a>
	  </li>
	   <li class="<?php if(is_page(701)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(701); ?>"><?php echo "Events/Special Days"; ?></a>
	  </li>
	  <li class="<?php if(is_page(716)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(716); ?>"><?php echo "Facilities"; ?></a>
	  </li>
	  
	    <li class="<?php if(is_page(713)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(713); ?>"><?php echo "Admission"; ?></a>
	  </li>  
	  
	 
	  
    
	  
	  
	 
      <!-- <li class="<?php if(is_page(725)){ echo 'active';}?>">
		<a href="<?php echo get_permalink(725); ?>"><?php echo get_the_title(725); ?></a>
	  </li> -->
     
      
	  </ul>
  </div>
</div>
