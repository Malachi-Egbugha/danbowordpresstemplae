<?php
/**
 * Template Name: Faq
 */

get_header(); ?>
<main> 
  
  <?php 
	$bannerImage=get_field('banner_image');
	if($bannerImage==""){
  ?>
  <div class="about-bg" style="background:url(<?php echo get_template_directory_uri(); ?>/img/banner.jpg);">
	<?php } else {?>
	
	 <div class="about" style="background:url(<?php echo $bannerImage;?>);">
	<?php } ?>	 
	
	
	<div class="aboutin">
      <div class="container-fluid">
        <div class="maxw">
          <div class="row">
             <?php include('sidebar-about.php'); ?>
            <div class="col-lg-9">
              <div class="abarea">
                <h3>Frequently asked questions</h3>
                <div id="accordion" class="panel-group">
					<?php if( have_rows('faq',28) ): ?>
					<?php 
					$p=1;
					while( have_rows('faq',28) ): the_row(); 

					// vars
					$title = get_sub_field('title');
					$content = get_sub_field('content');

					?>
					
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay=".2s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBody<?php echo $p;?>" class="accordion-toggle" data-toggle="collapse" data-parent="#accordion"><?php echo $title;?></a> </h4>
                    </div>
                    <div id="panelBody<?php echo $p;?>" class="panel-collapse collapse in">
                      <div class="panel-body">
                        <?php echo $content;?>
                      </div>
                    </div>
                  </div>
					<?php $p++;endwhile; ?>
					<?php endif; ?>
					
<!--                   <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay=".4ss">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyTwo" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">What are your school hours?</a> </h4>
                    </div>
                    <div id="panelBodyTwo" class="panel-collapse collapse">
                      <div class="panel-body">
                        <ul>
                          <li>Early Years</li>
                          <li>Primary</li>
                          <li>Secondary</li>
                          <li>SENS</li>
                          <li>Sixth Form</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay=".6ss">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyThree" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">Is there before and after school provision?</a> </h4>
                    </div>
                    <div id="panelBodyThree" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Yes. Morning begins 7:00am – 7:45am. Afternoon begins 2.45pm – 6:00pm. We also have vacation care - 7:00am – 6:00pm. (Timing can be reconfirmed )</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay=".8s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyfour" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">What kind of extra-curricular activities are available at Danbo?</a> </h4>
                    </div>
                    <div id="panelBodyfour" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Danbo students participate in a range of activities that enhance their physical, social and emotional development. (Link to the extra-curricular activities page can be provided here)</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="1.0s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyfive" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">What are your class sizes?</a> </h4>
                    </div>
                    <div id="panelBodyfive" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>This varies from class to class but most classes are between:<br>
                          Danbo Kaduna: 20 - 25 students per class. </p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="1.2s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyseven" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">Do you take the students overseas (Excursion / Leadership Training)?</a> </h4>
                    </div>
                    <div id="panelBodyseven" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Yes</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="1.4s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyeight" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">Does Danbo offer transportation servicesto and from school?</a> </h4>
                    </div>
                    <div id="panelBodyeight" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Yes, this is an optional service, at a separate cost and depending on the routes</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="1.6s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodynine" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">Does the school have meal programs?</a> </h4>
                    </div>
                    <div id="panelBodynine" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Yes, the school has meal programs</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="1.8s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyten" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">Does your school have boarding facilitiesfor Primary and Secondary?</a> </h4>
                    </div>
                    <div id="panelBodyten" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Yes, boarding facilities are available for  Primary and Secondary in Kaduna.</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="2.0s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyeleven" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">How do I make an application for a school place?</a> </h4>
                    </div>
                    <div id="panelBodyeleven" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Please make an application by visiting our admission page (Link to the admission page can be provided here)</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="2.2s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodytwelve" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">What is the minimum age requirement for enrolling children in your schools?</a> </h4>
                    </div>
                    <div id="panelBodytwelve" class="panel-collapse collapse">
                      <div class="panel-body">
                        <ul>
                          <li>Early Years:12 months and above (Crèche: 4months)</li>
                          <li>Primary :5 – 6 years </li>
                          <li>Secondary: 10years</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="2.4s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodythirteen" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">Does the school charge an admission fee / admission deposit?</a> </h4>
                    </div>
                    <div id="panelBodythirteen" class="panel-collapse collapse">
                      <div class="panel-body">
                        <p>Yes (Link to the admission page can be provided here)</p>
                      </div>
                    </div>
                  </div>
                  <div class="panel wow fadeInDown" data-wow-duration="2s" data-wow-delay="2.6s">
                    <div class="panel-heading">
                      <h4 class="panel-title"> <a href="#panelBodyfourteen" class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion">What if my question is not answered here?</a> </h4>
                    </div>
                    <div id="panelBodyfourteen" class="panel-collapse collapse">
                      <div class="panel-body">
                        <ul>
                          <li>Kindly contact us on any of our direct lines………………</li>
                          <li>or send us an email info@danboschools.com/info@danboschoolsabuja.com</li>
                        </ul>
                      </div>
                    </div>
                  </div> -->
					
					
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- end about --> 
  
</main>
<?php get_footer(); ?>