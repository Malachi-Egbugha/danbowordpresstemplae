<?php
/**
 * The template for the sidebar containing the main widget area
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<div class="col-lg-3">
<div class="abright">
<h4>About Us</h4>
<ul>


  <li class="<?php if(is_page( 'founders-welcome-message' )){echo 'active';}?>"><a href="<?php echo home_url('/founders-welcome-message/');?>">Founder's Welcome Message</a></li>
  
  <li class="<?php if(is_page( 'history' )){echo 'active';}?>"><a href="<?php echo home_url('/history/');?>">History</a> </li>
  <li class="<?php if(is_page( 'mission' )){echo 'active';}?>"><a href="<?php echo home_url('/mission/');?>">Vision, Mission & Our Values </a> </li>
  <li class="<?php if(is_page( 'quality-assurance-statement' )){echo 'active';}?>"><a href="<?php echo home_url('/quality-assurance-statement/');?>">Our promise to you - QA Statement</a> </li>
  <li class="<?php if(is_page( 'faq' )){echo 'active';}?>"><a href="<?php echo home_url('/faq/');?>">Frequently asked questions</a> </li>
  <li class="<?php if(is_page( 'why-choose-us' )){echo 'active';}?>"><a href="<?php echo home_url('/why-choose-us/');?>">Why Choose Us</a> </li>
  <li class="<?php if(is_page( 'our-partners' )){echo 'active';}?>"><a href="<?php echo home_url('/our-partners/');?>">Our Partners</a> </li>
  <li class="<?php if(is_page( 'e-learning' )){echo 'active';}?>"><a href="<?php echo home_url('/e-learning/');?>">E-Learning</a> </li>
  <li class="<?php if(is_page( 'contact' )){echo 'active';}?>"><a href="<?php echo home_url('/contact/');?>">Contact us</a> </li>
</ul>
</div>
</div>